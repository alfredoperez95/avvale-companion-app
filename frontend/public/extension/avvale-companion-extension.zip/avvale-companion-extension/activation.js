/**
 * URLs y codificación para envío a activaciones (compartido: popup + content script).
 */
(function () {
  const ACTIVATION_PATH = '/launcher/activations/activate/new';
  /** Origen de la SPA Companion (sin ruta), para launcher y enlaces internos. */
  const COMPANION_ORIGINS = {
    dev: 'http://localhost:3000',
    pro: 'https://www.avvalecompanion.app',
  };
  const ENV_URLS = {
    dev: COMPANION_ORIGINS.dev + ACTIVATION_PATH,
    pro: COMPANION_ORIGINS.pro + ACTIVATION_PATH,
  };

  function toBase64Url(obj) {
    const json = JSON.stringify(obj);
    const base64 = btoa(unescape(encodeURIComponent(json)));
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  /** @param {'dev'|'pro'} env */
  function getActivationBaseUrl(env) {
    return ENV_URLS[env === 'pro' ? 'pro' : 'dev'];
  }

  /** @param {'dev'|'pro'} env */
  function getCompanionOrigin(env) {
    return COMPANION_ORIGINS[env === 'pro' ? 'pro' : 'dev'];
  }

  globalThis.AvvaleActivation = {
    COMPANION_ORIGINS: COMPANION_ORIGINS,
    ENV_URLS: ENV_URLS,
    toBase64Url: toBase64Url,
    getActivationBaseUrl: getActivationBaseUrl,
    getCompanionOrigin: getCompanionOrigin,
  };
})();
