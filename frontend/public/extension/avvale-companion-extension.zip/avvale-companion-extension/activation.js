/**
 * URLs y codificación para envío a activaciones (compartido: popup + content script).
 */
(function () {
  const ACTIVATION_PATH = '/launcher/activations/activate/new';
  const ENV_URLS = {
    dev: 'http://localhost:3000' + ACTIVATION_PATH,
    pro: 'https://www.avvalecompanion.app' + ACTIVATION_PATH,
  };

  function toBase64Url(obj) {
    const json = JSON.stringify(obj);
    const base64 = btoa(unescape(encodeURIComponent(json)));
    return base64.replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  /** @param {'dev'|'pro'} env */
  function getActivationBaseUrl(env) {
    return ENV_URLS[env === 'pro' ? 'pro' : 'dev'];
  }

  globalThis.AvvaleActivation = {
    ENV_URLS: ENV_URLS,
    toBase64Url: toBase64Url,
    getActivationBaseUrl: getActivationBaseUrl,
  };
})();
