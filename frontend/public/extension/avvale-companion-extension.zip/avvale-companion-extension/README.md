# Avvale Companion – Extensión Chrome para HubSpot

Extensión Chrome (Manifest V3) que extrae datos de páginas de HubSpot CRM y los envía a tu backend Avvale Companion.

## Estructura del proyecto

```
hubspot-companion-extension/
├── manifest.json
├── background.js
├── content.js
├── popup.html
├── popup.js
├── styles.css
├── README.md
└── icons/
    ├── icon16.png
    ├── icon48.png
    └── icon128.png
```

## Cómo instalar la extensión en Chrome

1. Abre Chrome y ve a `chrome://extensions/`.
2. Activa **Modo desarrollador** (Developer mode) en la esquina superior derecha.
3. Pulsa **Cargar descomprimida** (Load unpacked).
4. Selecciona la carpeta `hubspot-companion-extension` (la que contiene `manifest.json`).
5. Comprueba que la extensión aparece sin errores.
6. Navega a `https://app.hubspot.com/` (con sesión iniciada). Deberías ver el botón flotante **Send to Avvale Companion** en la esquina inferior derecha.
7. Pulsa el botón para extraer datos, abre el popup de la extensión (icono en la barra de Chrome), revisa o edita los campos y pulsa **Create Activation** para enviar a tu API.

## Uso

- **En HubSpot**: el content script se inyecta en `https://app.hubspot.com/*`. Los selectores actuales son placeholders (`.company-name`, `.contact-name`, etc.); cuando tengas los selectores reales del DOM de HubSpot, actualízalos en `content.js` (objeto `SELECTORS`).
- **Botón flotante**: "Send to Avvale Companion" extrae los datos del DOM, los guarda en la extensión y muestra un toast. Luego abre el popup para revisar y enviar.
- **Popup**: campos editables (Company, Contact, Email, Deal, Subject, HubSpot URL) y botón **Create Activation** que hace `POST` a `http://localhost:4000/api/activations`.

## Backend y CORS

Tu API debe aceptar peticiones desde el origen de la extensión. En el backend (por ejemplo Express), configura CORS para permitir el origen `chrome-extension://<ID_DE_LA_EXTENSION>`. El ID lo ves en `chrome://extensions/` al pasar el ratón sobre la extensión. Para desarrollo local, asegúrate de que `http://localhost:4000` esté permitido si lo usas.

## Iconos

Los archivos en `icons/` son placeholders. Puedes sustituirlos por iconos en PNG de 16×16, 48×48 y 128×128 píxeles para la barra de extensiones y la ficha de la extensión.

## Funcionalidades futuras (preparadas en el código)

- **JWT**: en `popup.js`, `getAuthToken()` lee `authToken` de `chrome.storage.local`; si existe, se envía el header `Authorization: Bearer <token>` en el fetch.
- **Tipo de página**: en `content.js`, `detectPageType()` devuelve `contact`, `company`, `deal` o `unknown` según la URL; el objeto guardado en storage incluye `pageType`.
- **Selectores**: el objeto `SELECTORS` en `content.js` se puede más adelante cargar desde `chrome.storage` para mapeo dinámico de campos.
