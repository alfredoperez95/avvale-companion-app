/**
 * Formato del texto de vista previa (popup + botón flotante en HubSpot).
 */
(function () {
  function formatLog(data) {
    const lines = [
      '[Nombre del proyecto *]',
      data.projectName || '(vacío)',
      '',
      '[Código de oferta *]',
      data.offerCode || '(vacío)',
      '',
      '[Project Manager Email]',
      data.projectManagerEmail || '(vacío)',
      '',
      '[Importe]',
      data.amount || '(vacío)',
      '',
      '[URL HubSpot *]',
      data.hubspotUrl || '(vacío)',
      '',
      '[Cliente]',
      data.client || '(vacío)',
      '',
      '[Consultoría / Software]',
      data.serviceType || '(vacío)',
      '',
      '[Adjuntos]',
    ];
    const urls = data.attachmentUrls || [];
    const names = data.attachmentNames || [];
    if (urls.length === 0) {
      lines.push('(ninguno)');
    } else {
      urls.forEach(function (url, i) {
        const name = names[i];
        if (name) {
          lines.push((i + 1) + '. ' + name);
          lines.push('   ' + url);
        } else {
          lines.push((i + 1) + '. ' + url);
        }
      });
    }
    return lines.join('\n');
  }

  globalThis.AvvaleFormatLog = formatLog;
})();
