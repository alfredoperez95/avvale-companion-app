/**
 * Avvale Companion - Content Script (HubSpot)
 * Botón flotante: Recopilar → Enviar a activación en vistas de record.
 */
(function () {
  const STORAGE_KEY_LAST_RECOPILATED = 'lastRecopilatedData';
  const STORAGE_KEY_ACTIVATION_ENV = 'activationEnvironment';
  const STORAGE_KEY_SHOW_LOG_PREVIEW = 'showRecopilateLogPreview';
  const BTN_ID = 'avvale-companion-floating-recopilar';
  const NEWDEAL_ID = 'avvale-companion-floating-newdeal';
  const FROM_OFFER_ID = 'avvale-companion-top-from-offer';
  const LEFT_BAR_ID = 'avvale-companion-floating-left-bar';
  const PDF_ID = 'avvale-companion-floating-pdf';
  const RIGHT_SIDEBAR_SELECTOR = '[data-scroll-trackable-container="right-sidebar"]';
  let lastCompanyAssociationQueryForDeal = '';

  /** Sugerencias Project Manager Email (solo Deal 0-3) */
  const PM_EMAIL_PANEL_ID = 'avvale-companion-pm-suggest';
  const PM_EMAIL_SELECTOR = 'textarea[data-selenium-test="property-input-project_manager_email"]';
  const PM_SUGGEST_EMAILS = [
    'aaron.villar@avvale.com',
    'adolfo.pecci@avvale.com',
    'adrian.miguel@avvale.com',
    'adrian.milan@avvale.com',
    'adrian.sanchez@avvale.com',
    'adrian.tesoro@avvale.com',
    'agustin.figueredo@avvale.com',
    'agustina.samper@avvale.com',
    'airon.benito@avvale.com',
    'aitor.clemente@avvale.com',
    'aitor.sanchez@avvale.com',
    'alan.dimaria@avvale.com',
    'alba.barriguete@avvale.com',
    'albert.sanchez@avvale.com',
    'alberto.aguilera@avvale.com',
    'alberto.arenas@avvale.com',
    'alberto.canovas@avvale.com',
    'alberto.carretero@avvale.com',
    'alberto.gonzalez@avvale.com',
    'alberto.hernandez@avvale.com',
    'alberto.hurtado@avvale.com',
    'alberto.morais@avvale.com',
    'alberto.polaino@avvale.com',
    'alberto.rodriguez@avvale.com',
    'alberto.romero@avvale.com',
    'alberto.sanchez@avvale.com',
    'alberto.torregrosa@avvale.com',
    'alejandra.castedo@avvale.com',
    'alejandra.vazquez@avvale.com',
    'alejandro.alvarez@avvale.com',
    'alejandro.cabrera@avvale.com',
    'alejandro.caro@avvale.com',
    'alejandro.delgado@avvale.com',
    'alejandro.dorado@avvale.com',
    'alejandro.garcia@avvale.com',
    'alejandro.gomez@avvale.com',
    'alejandro.martinez@avvale.com',
    'alejandro.palomares@avvale.com',
    'alejandro.pascual@avvale.com',
    'alejandro.roman@avvale.com',
    'alejandro.rubens@avvale.com',
    'alejandro.valle@avvale.com',
    'alex.cuesta@avvale.com',
    'alexander.eusse@avvale.com',
    'alexandre.diaz@avvale.com',
    'alfonso.dominguez@avvale.com',
    'alfonso.garciav@avvale.com',
    'alfonso.martinez@avvale.com',
    'alfonso.romero@avvale.com',
    'alfredo.carrion@avvale.com',
    'alfredo.castilla@avvale.com',
    'alfredo.perez@avvale.com',
    'alicia.lopez@avvale.com',
    'alicia.rodriguez@avvale.com',
    'alicia.vela@avvale.com',
    'alma.estefania@avvale.com',
    'alvaro.arbaiza@avvale.com',
    'alvaro.arteche@avvale.com',
    'alvaro.carmona@avvale.com',
    'alvaro.gomez@avvale.com',
    'alvaro.leon@avvale.com',
    'alvaro.membrive@avvale.com',
    'alvaro.ortega@avvale.com',
    'alvaro.rubio@avvale.com',
    'alvaro.villacastin@avvale.com',
    'alvaro.villadangos@avvale.com',
    'alvaro.zorrilla@avvale.com',
    'amalia.garcia@avvale.com',
    'ana.carmona@avvale.com',
    'ana.dominguez@avvale.com',
    'ana.elizechea@avvale.com',
    'anabeatriz.perez@avvale.com',
    'anabel.mota@avvale.com',
    'anabella.famiglietti@avvale.com',
    'andres.martinez@avvale.com',
    'angel.cid@avvale.com',
    'angel.gordo@avvale.com',
    'angel.lobo@avvale.com',
    'angel.perales@avvale.com',
    'angelmanuel.boullosa@avvale.com',
    'anna.fuentes@avvale.com',
    'antonio.guzman@avvale.com',
    'antonio.rodriguez@avvale.com',
    'antonio.sanz@avvale.com',
    'ariadna.jimenez@avvale.com',
    'augusto.hernandez@avvale.com',
    'aurelio.alonso@avvale.com',
    'aurelio.martinez@avvale.com',
    'beatriz.arraez@avvale.com',
    'belen.cano@avvale.com',
    'belen.mateos@avvale.com',
    'bianca.florido@avvale.com',
    'blanca.alvarez@avvale.com',
    'blas.leiva@avvale.com',
    'borja.garcia@avvale.com',
    'bosco.fernandez@avvale.com',
    'brian.arias@avvale.com',
    'brian.munoz@avvale.com',
    'caio.pastore@avvale.com',
    'camila.piuma@avvale.com',
    'carlos.castillo@avvale.com',
    'carlos.castrillon@avvale.com',
    'carlos.gomez@avvale.com',
    'carlos.huertas@avvale.com',
    'carlos.laguna@avvale.com',
    'carlos.mari@avvale.com',
    'carlos.mateo@avvale.com',
    'carlos.medina@avvale.com',
    'carlos.medina_spn@avvale.com',
    'carlos.muzo@avvale.com',
    'carlos.navarro@avvale.com',
    'carlos.orozco@avvale.com',
    'carlos.rodriguez@avvale.com',
    'carlos.vega@avvale.com',
    'carlota.corominas@avvale.com',
    'carmen.baquerizo@avvale.com',
    'carmen.romero@avvale.com',
    'carmen.tolentino@avvale.com',
    'catalina.salomon@avvale.com',
    'cesar.fernandez@avvale.com',
    'cesar.santamaria@avvale.com',
    'clara.madrigal@avvale.com',
    'clara.rodriguez@avvale.com',
    'conchita.coya@avvale.com',
    'cristina.martin@avvale.com',
    'cristina.masia@avvale.com',
    'cristina.redondo@avvale.com',
    'cruz.luna@avvale.com',
    'daniel.castellano@avvale.com',
    'daniel.feliciano@avvale.com',
    'daniel.fernandez@avvale.com',
    'daniel.lafuente@avvale.com',
    'daniel.lopez@avvale.com',
    'daniel.marchante@avvale.com',
    'daniel.marcos@avvale.com',
    'daniel.navarro@avvale.com',
    'daniel.parra@avvale.com',
    'daniel.rivero@avvale.com',
    'daniel.sanjose@avvale.com',
    'daniela.gargoles@avvale.com',
    'daniela.gonzalez@avvale.com',
    'daniela.grimaldo@avvale.com',
    'dante.diaz@avvale.com',
    'dario.megias@avvale.com',
    'david.alonso@avvale.com',
    'david.barja@avvale.com',
    'david.diaz@avvale.com',
    'david.fuertes@avvale.com',
    'david.garcia@avvale.com',
    'david.gomez@avvale.com',
    'david.gonzalezp@avvale.com',
    'david.hurtado@avvale.com',
    'david.marcos@avvale.com',
    'david.martin@avvale.com',
    'david.mestre@avvale.com',
    'david.miguel@avvale.com',
    'david.orozco@avvale.com',
    'david.perez@avvale.com',
    'david.ramirez@avvale.com',
    'david.recio@avvale.com',
    'david.rodriguezb@avvale.com',
    'david.rubio@avvale.com',
    'davidvicente.saune@avvale.com',
    'diego.lopez@avvale.com',
    'diego.martin@avvale.com',
    'diego.poyo@avvale.com',
    'diego.rodriguez@avvale.com',
    'diego.sanchezcapitan@avvale.com',
    'dionisio.garcia@avvale.com',
    'edgar.gomez@avvale.com',
    'edgar.silva@avvale.com',
    'eduardo.lallo@avvale.com',
    'eduardo.navarro@avvale.com',
    'elena.hernanz@avvale.com',
    'elena.isidro@avvale.com',
    'elena.torres@avvale.com',
    'elena.valverde@avvale.com',
    'eloy.delmoral@avvale.com',
    'elsa.ferreras@avvale.com',
    'emilio.garcia@avvale.com',
    'emilio.sanchez@avvale.com',
    'enrique.carretero@avvale.com',
    'enrique.corrales@avvale.com',
    'enrique.garcia@avvale.com',
    'enrique.godoy@avvale.com',
    'enrique.jimenez@avvale.com',
    'enrique.nicolas@avvale.com',
    'enrique.sanchez@avvale.com',
    'enrique.stampa@avvale.com',
    'enrique.torres@avvale.com',
    'erika.iglesias@avvale.com',
    'erin.garcia@avvale.com',
    'es-it@avvale.com',
    'esmeralda.cano@avvale.com',
    'esperanza.nogales@avvale.com',
    'estefania.garcia@avvale.com',
    'estefania.ribagorda@avvale.com',
    'ester.escudero@avvale.com',
    'esther.perulero@avvale.com',
    'estrella.estar@avvale.com',
    'eva.barba@avvale.com',
    'eva.masdeu@avvale.com',
    'eva.sanchez@avvale.com',
    'evelyn.lora@avvale.com',
    'ezequiel.clivio@avvale.com',
    'fabio.caroli@avvale.com',
    'fabio.rengifo@avvale.com',
    'fabiola.donate@avvale.com',
    'fareh.romero@avvale.com',
    'fernando.roa@avvale.com',
    'fernando.rojo@avvale.com',
    'francisco.cerezo@avvale.com',
    'francisco.garcia@avvale.com',
    'francisco.gonzalezb@avvale.com',
    'francisco.gonzalezu@avvale.com',
    'francisco.martin@avvale.com',
    'francisco.merchan@avvale.com',
    'francisco.morato@avvale.com',
    'francisco.perez@avvale.com',
    'francisco.piuma@avvale.com',
    'francisco.solis@avvale.com',
    'francisco.sousa@avvale.com',
    'franciscojavier.dominguez@avvale.com',
    'franco.rodriguez@avvale.com',
    'frank.namicela@avvale.com',
    'franziska.wagner@avvale.com',
    'gabriel.dones@avvale.com',
    'gabriel.escardo@avvale.com',
    'gabriel.lopez@avvale.com',
    'gema.beato@avvale.com',
    'gerard.pg@avvale.com',
    'gerard.prats@avvale.com',
    'gerardo.martin@avvale.com',
    'gerardo.will@avvale.com',
    'german.carrasco@avvale.com',
    'german.umbarila@avvale.com',
    'giovanny.buitrago@avvale.com',
    'gonzalo.ferrer@avvale.com',
    'gonzalo.mora@avvale.com',
    'gonzalo.villamizar@avvale.com',
    'gregoria.romero@avvale.com',
    'gregorio.coll@avvale.com',
    'guillermo.matilla@avvale.com',
    'guillermo.moreno@avvale.com',
    'guillermo.navarro@avvale.com',
    'guillermo.truan@avvale.com',
    'guillermo.vicente@avvale.com',
    'guiomar.fernandez@avvale.com',
    'habib.abdul@avvale.com',
    'hector.nogales@avvale.com',
    'hector.varela@avvale.com',
    'hendys.perez@avvale.com',
    'hugo.sloot@avvale.com',
    'ignacio.corcuera@avvale.com',
    'ignacio.hidalgo@avvale.com',
    'inmaculada.sanchez@avvale.com',
    'irene.dieguez@avvale.com',
    'irene.jorquera@avvale.com',
    'isabel.ceballos@avvale.com',
    'isabella.santoro@avvale.com',
    'ismael.bermejo@avvale.com',
    'ismael.mateo@avvale.com',
    'issam.elalaoui@avvale.com',
    'ivan.caamano@avvale.com',
    'ivan.gabella@avvale.com',
    'ivan.radoslavov@avvale.com',
    'ivan.redondo@avvale.com',
    'ivan.romon@avvale.com',
    'jacob.casal@avvale.com',
    'jaime.pancorbo@avvale.com',
    'janelys.martinez@avvale.com',
    'javier.arozarena@avvale.com',
    'javier.ausin@avvale.com',
    'javier.carrasco@avvale.com',
    'javier.cazorla@avvale.com',
    'javier.dematias@avvale.com',
    'javier.garciasanchez@avvale.com',
    'javier.gonzalez@avvale.com',
    'javier.gonzalezg@avvale.com',
    'javier.llaguno@avvale.com',
    'javier.lopez@avvale.com',
    'javier.marzo@avvale.com',
    'javier.mesa@avvale.com',
    'javier.munoz@avvale.com',
    'javier.rigal@avvale.com',
    'javier.romera@avvale.com',
    'jennyfer.heredia@avvale.com',
    'jessica.bach@avvale.com',
    'jesus.martin@avvale.com',
    'jesus.prieto@avvale.com',
    'jesusalberto.ortiz@avvale.com',
    'jhemili.desouza@avvale.com',
    'jhonnyjavier.caicedo@avvale.com',
    'joanandreu.blade@avvale.com',
    'joaquim.camps@avvale.com',
    'joaquin.ruiz@avvale.com',
    'johanenrique.fagundez@avvale.com',
    'jon.aguinaga@avvale.com',
    'jonander.ibanez@avvale.com',
    'jonathan.buitrago@avvale.com',
    'jonathan.gallego@avvale.com',
    'jonathan.garrido@avvale.com',
    'jonathan.iapalucci@avvale.com',
    'jonathan.martin@avvale.com',
    'jordi.campos@avvale.com',
    'jordi.ramon@avvale.com',
    'jorge.aliacar@avvale.com',
    'jorge.bea@avvale.com',
    'jorge.custodio@avvale.com',
    'jorge.delaserna@avvale.com',
    'jorge.garcia@avvale.com',
    'jorge.gonzalez@avvale.com',
    'jorge.munoz@avvale.com',
    'jorge.ocampos@avvale.com',
    'jorge.perez@avvale.com',
    'jorge.plata@avvale.com',
    'jorge.rodriguez@avvale.com',
    'jose.gutierrez@avvale.com',
    'jose.hernandez@avvale.com',
    'jose.leal@avvale.com',
    'jose.perez@avvale.com',
    'jose.pesquera@avvale.com',
    'jose.vallega@avvale.com',
    'joseangel.sevilla@avvale.com',
    'joseantonio.palomo@avvale.com',
    'joseluis.lloret@avvale.com',
    'joseluis.medina@avvale.com',
    'josemanuel.balsera@avvale.com',
    'josemanuel.enriquez@avvale.com',
    'josemanuel.nieto@avvale.com',
    'josemanuel.prieto@avvale.com',
    'josemanuel.romero@avvale.com',
    'josemanuel.sanchezseco@avvale.com',
    'joseramon.dominguez@avvale.com',
    'joseruben.diez@avvale.com',
    'juan.julian@avvale.com',
    'juan.lirio@avvale.com',
    'juan.lorca@avvale.com',
    'juan.martos@avvale.com',
    'juan.sanchez@avvale.com',
    'juan.sanmartin@avvale.com',
    'juanantonio.jimenez@avvale.com',
    'juancarlos.arcos@avvale.com',
    'juancarlos.diaz@avvale.com',
    'juancarlos.fuentes@avvale.com',
    'juancarlos.gago@avvale.com',
    'juancarlos.mouledous@avvale.com',
    'juancarlos.sanchez@avvale.com',
    'juancarlos.vidaller@avvale.com',
    'juandaniel.barroso@avvale.com',
    'juandaniel.garcia@avvale.com',
    'juandiego.matiaci@avvale.com',
    'juanignacio.almeida@avvale.com',
    'juanita.zapata@avvale.com',
    'juanjose.cruz@avvale.com',
    'juanpablo.guichon@avvale.com',
    'juanpablo.jacome@avvale.com',
    'julian.rincon@avvale.com',
    'julio.alvarez@avvale.com',
    'julio.cariajano@avvale.com',
    'laia.jimenez@avvale.com',
    'laia.zueras@avvale.com',
    'laura.alean@avvale.com',
    'laura.grazioso@avvale.com',
    'laura.luque@avvale.com',
    'laura.martin@avvale.com',
    'laura.martinez@avvale.com',
    'laura.sanchez@avvale.com',
    'lauraximena.diaz@avvale.com',
    'leidy.egusquiza@avvale.com',
    'leire.bragado@avvale.com',
    'leonardo.alvarez@avvale.com',
    'leonor.uzcategui@avvale.com',
    'leopoldo.calleja@avvale.com',
    'leticia.aguilar@avvale.com',
    'lidia.sacristan@avvale.com',
    'lidia.vicente@avvale.com',
    'liliana.gutierrez@avvale.com',
    'lionel.carballo@avvale.com',
    'lisis.rodriguez@avvale.com',
    'lissette.rodriguez@avvale.com',
    'lourdes.martin@avvale.com',
    'lucas.salvatore@avvale.com',
    'lucas.schiavone@avvale.com',
    'lucia.delucas@avvale.com',
    'lucia.peinado@avvale.com',
    'ludovica.luciani@avvale.com',
    'luis.blanco@avvale.com',
    'luis.deir-kaspar@avvale.com',
    'luis.dieguez@avvale.com',
    'luis.garcia@avvale.com',
    'luis.zarzo@avvale.com',
    'luisfernando.sanz@avvale.com',
    'manuel.almagro@avvale.com',
    'manuel.casado@avvale.com',
    'manuel.gomes@avvale.com',
    'manuel.justicia@avvale.com',
    'manuel.pacheco@avvale.com',
    'manuel.portal@avvale.com',
    'manuel.rodriguez@avvale.com',
    'manuel.torres@avvale.com',
    'manuelangel.garcia@avvale.com',
    'marc.estevez@avvale.com',
    'marc.jimenez@avvale.com',
    'marc.pla@avvale.com',
    'marcial.carreras@avvale.com',
    'marco.martinez@avvale.com',
    'marcos.carro@avvale.com',
    'marcos.guillen@avvale.com',
    'marcospaulo.oliveira@avvale.com',
    'maria.burgos@avvale.com',
    'maria.carella@avvale.com',
    'maria.estar@avvale.com',
    'maria.gonzalez@avvale.com',
    'maria.puig@avvale.com',
    'maria.sanchez@avvale.com',
    'mariabelen.ballesteros@avvale.com',
    'mariaelena.riera@avvale.com',
    'mariajose.garcia@avvale.com',
    'marian.lopez@avvale.com',
    'mariana.baez@avvale.com',
    'mariavictoria.checa@avvale.com',
    'mariavictoria.sanz@avvale.com',
    'marina.fabuel@avvale.com',
    'marina.herrera@avvale.com',
    'marina.villalobos@avvale.com',
    'mario.castill@avvale.com',
    'mario.cortes@avvale.com',
    'mario.cortesf@avvale.com',
    'mario.dorado@avvale.com',
    'mario.morillo@avvale.com',
    'marta.aguirre@avvale.com',
    'marta.carreras@avvale.com',
    'marta.guirao@avvale.com',
    'marta.munoz@avvale.com',
    'martin.lopez@avvale.com',
    'martina.zanardo@avvale.com',
    'miguel.delacalle@avvale.com',
    'miguel.fernandez@avvale.com',
    'miguel.maldonado@avvale.com',
    'miguel.pena@avvale.com',
    'miguel.rodriguez@avvale.com',
    'miguel.rosso@avvale.com',
    'mikel.maeso@avvale.com',
    'mikel.moreno@avvale.com',
    'miriam.barroso@avvale.com',
    'miriam.garcia@avvale.com',
    'mohamed.arazouk@avvale.com',
    'montserrat.rospide@avvale.com',
    'morella.santoro@avvale.com',
    'nathalia.espindola@avvale.com',
    'nerea.gomez@avvale.com',
    'nestor.anton@avvale.com',
    'noelia.escalera@avvale.com',
    'noelia.mantecon@avvale.com',
    'nuria.gonzalez@avvale.com',
    'nuria.lopez@avvale.com',
    'nuria.lucas@avvale.com',
    'olga.blanco@avvale.com',
    'oriol.fernandez@avvale.com',
    'oscar.alonso@avvale.com',
    'oscar.estaran@avvale.com',
    'oscar.garcia@avvale.com',
    'oscar.martin@avvale.com',
    'pablo.asenjo@avvale.com',
    'pablo.delhoyo@avvale.com',
    'pablo.encinas@avvale.com',
    'pablo.fernandez@avvale.com',
    'pablo.lindez@avvale.com',
    'pablo.virseda@avvale.com',
    'pascual.sanchez@avvale.com',
    'patricia.mendez@avvale.com',
    'patricia.suarez@avvale.com',
    'paula.gil@avvale.com',
    'paula.jimenez@avvale.com',
    'pedro.toledano@avvale.com',
    'pedro.villamandos@avvale.com',
    'pedrorafael.mata@avvale.com',
    'pere.utreras@avvale.com',
    'piedad.marquez@avvale.com',
    'pilar.martinez@avvale.com',
    'pol.muste@avvale.com',
    'pridon.babuadze@avvale.com',
    'rafael.caston@avvale.com',
    'rafael.fernandez@avvale.com',
    'rafael.garcia@avvale.com',
    'rafael.lopez@avvale.com',
    'rafael.ruiz@avvale.com',
    'raquel.martinperales@avvale.com',
    'raquel.mera@avvale.com',
    'raquel.nuno@avvale.com',
    'raul.isidro@avvale.com',
    'raul.vazquez@avvale.com',
    'rebeca.ayguade@avvale.com',
    'ricard.gonzalez@avvale.com',
    'ricardo.eusse@avvale.com',
    'ricardo.garcia@avvale.com',
    'ricardo.ortiz@avvale.com',
    'ricardo.salles@avvale.com',
    'ricardo.santamaria@avvale.com',
    'roberto.fernandez@avvale.com',
    'roberto.ruano@avvale.com',
    'rocco.busacco@avvale.com',
    'rocio.lopez@avvale.com',
    'rodrigo.fernandez@avvale.com',
    'rodrigo.lazaro@avvale.com',
    'roger.ortega@avvale.com',
    'rosa.sanchez@avvale.com',
    'rrhh.es@avvale.com',
    'ruben.briongos@avvale.com',
    'ruben.jimenez@avvale.com',
    'ruben.molina@avvale.com',
    'ruben.velasco@avvale.com',
    'rudy.gonzalez@avvale.com',
    'samuel.lopez@avvale.com',
    'samuel.stenson@avvale.com',
    'sandeep.singh@avvale.com',
    'sandra.gonzalezm@avvale.com',
    'sandra.pol@avvale.com',
    'santiago.bardanca@avvale.com',
    'santiago.dearriba@avvale.com',
    'santiago.perez@avvale.com',
    'santiago.porras@avvale.com',
    'sara.aranda@avvale.com',
    'saul.vilor@avvale.com',
    'sean.rolly@avvale.com',
    'sergio.acevedo@avvale.com',
    'sergio.arrogante@avvale.com',
    'sergio.defrutos@avvale.com',
    'sergio.elena@avvale.com',
    'sergio.garcia@avvale.com',
    'sergio.gonzalez@avvale.com',
    'sergio.marquerie@avvale.com',
    'sergio.martin@avvale.com',
    'sergio.matesanz@avvale.com',
    'sergio.pascual@avvale.com',
    'silvestra.spinale@avvale.com',
    'silvia.garcia@avvale.com',
    'silvia.rodriguez@avvale.com',
    'sonia.amatlle@avvale.com',
    'sonia.serna@avvale.com',
    'tamara.pardino@avvale.com',
    'tamara.peira@avvale.com',
    'tania.carmona@avvale.com',
    'teresa.ortiz@avvale.com',
    'teresa.vicente@avvale.com',
    'tomas.fernandez@avvale.com',
    'valeria.valencia@avvale.com',
    'vanesa.domenech@avvale.com',
    'vasile.pop@avvale.com',
    'veronica.criado@avvale.com',
    'veronica.gomez@avvale.com',
    'veronica.viveros@avvale.com',
    'vicente.munoz@avvale.com',
    'vicente.peris@avvale.com',
    'vicente.rodriguez@avvale.com',
    'victor.dominguez@avvale.com',
    'victor.rey@avvale.com',
    'virginia.deandrade@avvale.com',
    'xavier.tor@avvale.com',
    'xavier.vila@avvale.com',
    'xiran.zhao@avvale.com',
    'yeray.dasilva@avvale.com',
  ];
  let activePmEmailTextarea = null;
  let pmEmailBlurCloseTimer = null;

  function isPageReload() {
    try {
      const nav = performance.getEntriesByType('navigation')[0];
      if (nav && nav.type === 'reload') return true;
    } catch (_) {}
    try {
      if (performance.navigation && performance.navigation.type === 1) return true;
    } catch (_) {}
    return false;
  }

  if (isPageReload()) {
    chrome.storage.local.remove(STORAGE_KEY_LAST_RECOPILATED);
  }

  const TOAST_ID = 'avvale-companion-toast';
  const LOG_PANEL_ID = 'avvale-companion-log-panel';
  const LOADING_ID = 'avvale-companion-loading';
  const SECONDARY_CLASS = 'avvale-companion-floating-btn--secondary';

  function showLoadingSpinner() {
    hideLoadingSpinner();
    const wrap = document.createElement('div');
    wrap.id = LOADING_ID;
    wrap.className = 'avvale-companion-loading';
    wrap.setAttribute('role', 'status');
    wrap.setAttribute('aria-live', 'polite');
    const spin = document.createElement('span');
    spin.className = 'avvale-companion-loading__spinner';
    spin.setAttribute('aria-hidden', 'true');
    const label = document.createElement('span');
    label.textContent = 'Recopilando…';
    wrap.appendChild(spin);
    wrap.appendChild(label);
    document.documentElement.appendChild(wrap);

    // Posicionar "Recopilando…" justo encima del botón Recopilar/Enviar.
    const recopilarBtn = document.getElementById(BTN_ID);
    if (recopilarBtn) {
      const r = recopilarBtn.getBoundingClientRect();
      const gap = 10;
      wrap.style.left = `${Math.max(8, Math.round(r.left))}px`;
      wrap.style.right = 'auto';
      wrap.style.bottom = `${Math.max(8, Math.round(window.innerHeight - r.top + gap))}px`;
      wrap.style.maxWidth = `${Math.round(r.width)}px`;
    } else {
      wrap.style.left = '';
      wrap.style.right = '';
      wrap.style.bottom = '';
      wrap.style.maxWidth = '';
    }
  }

  function hideLoadingSpinner() {
    document.getElementById(LOADING_ID)?.remove();
  }

  function isRecordViewUrl(href) {
    try {
      const u = new URL(href);
      if (u.hostname !== 'app.hubspot.com') return false;
      const p = u.pathname.split('/').filter(Boolean);
      return (
        p.length >= 5
        && p[0] === 'contacts'
        && p[2] === 'record'
        && /^\d+-\d+$/.test(p[3])
        && /^\d+$/.test(p[4])
      );
    } catch {
      return false;
    }
  }

  function getRecordTypeFromUrl(href) {
    try {
      const u = new URL(href);
      const p = u.pathname.split('/').filter(Boolean);
      if (p.length >= 5 && p[0] === 'contacts' && p[2] === 'record') return p[3];
    } catch (_) {}
    return null;
  }

  function isCompanyRecordUrl(href) {
    return getRecordTypeFromUrl(href) === '0-2';
  }

  function isDealRecordUrl(href) {
    return getRecordTypeFromUrl(href) === '0-3';
  }

  function sameRecordPage(storedHubspotUrl, currentHref) {
    try {
      const a = new URL(storedHubspotUrl);
      const b = new URL(currentHref);
      return a.pathname === b.pathname;
    } catch {
      return false;
    }
  }

  function removeFloatingLogPanel() {
    document.getElementById(LOG_PANEL_ID)?.remove();
  }

  function removeToast() {
    document.getElementById(TOAST_ID)?.remove();
  }

  function removeFloatingButton() {
    document.getElementById(BTN_ID)?.remove();
    document.getElementById(NEWDEAL_ID)?.remove();
    document.getElementById(FROM_OFFER_ID)?.remove();
    document.getElementById(PDF_ID)?.remove();
    document.getElementById(LEFT_BAR_ID)?.remove();
    removeFloatingLogPanel();
    removeToast();
    hideLoadingSpinner();
    hidePmEmailSuggestPanel();
  }

  function setNativeValue(element, value) {
    if (!element) return;
    const proto = element.constructor && element.constructor.prototype;
    const desc = proto ? Object.getOwnPropertyDescriptor(proto, 'value') : null;
    const setter = desc && typeof desc.set === 'function' ? desc.set : null;
    if (setter) {
      setter.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function getOrCreatePmEmailSuggestPanel() {
    let panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = PM_EMAIL_PANEL_ID;
    panel.className = 'avvale-companion-pm-suggest';
    panel.setAttribute('role', 'listbox');
    panel.setAttribute('aria-label', 'Correos sugeridos');
    panel.hidden = true;
    document.documentElement.appendChild(panel);
    return panel;
  }

  function positionPmEmailSuggestPanel(panel, anchorEl) {
    const r = anchorEl.getBoundingClientRect();
    const gap = 4;
    const minW = 280;
    const w = Math.max(r.width, minW);
    let left = r.left;
    if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
    panel.style.top = `${Math.round(r.bottom + gap)}px`;
    panel.style.left = `${Math.round(left)}px`;
    panel.style.width = `${Math.round(w)}px`;
  }

  function hidePmEmailSuggestPanel() {
    if (pmEmailBlurCloseTimer) {
      clearTimeout(pmEmailBlurCloseTimer);
      pmEmailBlurCloseTimer = null;
    }
    const panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (panel) {
      panel.hidden = true;
      panel.innerHTML = '';
    }
    activePmEmailTextarea = null;
  }

  function getFilteredPmEmails(query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return PM_SUGGEST_EMAILS.slice();
    return PM_SUGGEST_EMAILS.filter((email) => email.toLowerCase().includes(q));
  }

  function renderPmEmailSuggestItems(panel, textarea, emails) {
    panel.innerHTML = '';
    if (emails.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'avvale-companion-pm-suggest__empty';
      empty.textContent = 'Sin coincidencias';
      panel.appendChild(empty);
      return;
    }
    emails.forEach((email) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'avvale-companion-pm-suggest__item';
      btn.setAttribute('role', 'option');
      btn.dataset.email = email;
      btn.textContent = email;
      btn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (activePmEmailTextarea) setNativeValue(activePmEmailTextarea, email);
        hidePmEmailSuggestPanel();
        try {
          textarea.focus();
        } catch (_) {}
      });
      panel.appendChild(btn);
    });
  }

  function updatePmEmailSuggestPanel(textarea) {
    if (!textarea || textarea.tagName !== 'TEXTAREA') return;
    if (pmEmailBlurCloseTimer) {
      clearTimeout(pmEmailBlurCloseTimer);
      pmEmailBlurCloseTimer = null;
    }
    const panel = getOrCreatePmEmailSuggestPanel();
    activePmEmailTextarea = textarea;
    const emails = getFilteredPmEmails(textarea.value);
    renderPmEmailSuggestItems(panel, textarea, emails);
    positionPmEmailSuggestPanel(panel, textarea);
    panel.hidden = false;
  }

  function onPmEmailTextareaFocusIn(e) {
    if (!isDealRecordUrl(location.href)) return;
    updatePmEmailSuggestPanel(e.currentTarget);
  }

  function onPmEmailTextareaInput(e) {
    if (!isDealRecordUrl(location.href)) return;
    updatePmEmailSuggestPanel(e.currentTarget);
  }

  function onPmEmailTextareaBlur() {
    if (pmEmailBlurCloseTimer) clearTimeout(pmEmailBlurCloseTimer);
    pmEmailBlurCloseTimer = setTimeout(() => {
      pmEmailBlurCloseTimer = null;
      const panel = document.getElementById(PM_EMAIL_PANEL_ID);
      if (!panel || panel.hidden) return;
      hidePmEmailSuggestPanel();
    }, 180);
  }

  function onPmSuggestDocumentKeydown(e) {
    if (e.key !== 'Escape') return;
    const panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (!panel || panel.hidden) return;
    e.preventDefault();
    hidePmEmailSuggestPanel();
  }

  function onPmSuggestDocumentPointerDown(e) {
    const panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (!panel || panel.hidden) return;
    const t = e.target;
    if (panel.contains(t)) return;
    if (t && t.closest && t.closest(PM_EMAIL_SELECTOR)) return;
    hidePmEmailSuggestPanel();
  }

  function ensurePmEmailSuggestOnDeal() {
    if (!isDealRecordUrl(location.href)) {
      hidePmEmailSuggestPanel();
      return;
    }
    const list = document.querySelectorAll(PM_EMAIL_SELECTOR);
    list.forEach((ta) => {
      if (ta.dataset.avvalePmSuggestBound === '1') return;
      ta.dataset.avvalePmSuggestBound = '1';
      ta.addEventListener('focusin', onPmEmailTextareaFocusIn);
      ta.addEventListener('input', onPmEmailTextareaInput);
      ta.addEventListener('blur', onPmEmailTextareaBlur);
    });
  }

  document.addEventListener('keydown', onPmSuggestDocumentKeydown, true);
  document.addEventListener('pointerdown', onPmSuggestDocumentPointerDown, true);

  function pad2(n) {
    return String(n).padStart(2, '0');
  }

  function formatDateDDMMYYYY(d) {
    return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
  }

  function addOneMonth(date) {
    const d = new Date(date.getTime());
    const day = d.getDate();
    d.setMonth(d.getMonth() + 1);
    if (d.getDate() !== day) d.setDate(0);
    return d;
  }

  function normalizeAmount(v) {
    if (v == null) return '';
    if (typeof v === 'number' && Number.isFinite(v)) return String(v);
    const s = String(v).trim();
    if (!s) return '';
    // Quitar moneda/espacios y separadores comunes, dejar dígitos.
    const digits = s.replace(/[^\d]/g, '');
    return digits;
  }

  function getObjectBuilderIframeDoc() {
    const iframe =
      document.querySelector('iframe#object-builder-ui')
      || document.querySelector('iframe[data-test-id="object-builder-ui-iframe"]')
      || document.querySelector('iframe[data-selenium-test="associate-panel-iframe"]');
    if (!iframe) return null;
    try {
      return iframe.contentDocument || iframe.contentWindow?.document || null;
    } catch (_) {
      // Si HubSpot cambia a cross-origin en algún flujo, esto lanzará.
      return null;
    }
  }

  function normalizeText(s) {
    return String(s || '')
      .replace(/\u200b/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function normalizeAssociationQuery(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';

    // Preferimos URL completa si existe (el usuario pidió URL de empresa).
    try {
      if (/^https?:\/\//i.test(s)) {
        const u = new URL(s);
        const proto = u.protocol.toLowerCase() === 'https:' ? 'https:' : 'http:';
        const host = u.hostname.replace(/^www\./i, '');
        return `${proto}//${host}`;
      }
    } catch (_) {}

    // Si viene como texto tipo "diagroup.com", normalizar a URL http://
    const host = s
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '')
      .replace(/\/.*$/, '')
      .trim();
    if (!host) return '';
    return `http://${host}`;
  }

  function getCompanyDomainFromHighlight() {
    // Caso típico: <span data-test-id="highlight-property-display-domain"><a href="http://diagroup.com">diagroup.com</a>
    const a =
      document.querySelector('[data-test-id="highlight-property-display-domain"] a')
      || document.querySelector('[data-test-id="highlight-property-item-domain"] a');
    if (!a) return '';
    const href = a.getAttribute('href') || '';
    const text = (a.innerText || a.textContent || '').trim();
    return normalizeAssociationQuery(href) || normalizeAssociationQuery(text);
  }

  function getDealTypeLabel(rootDoc) {
    const btn = rootDoc?.querySelector?.('button[data-test-id="dealtype-input"]');
    if (!btn) return '';
    const t = normalizeText(btn.innerText || btn.textContent || '');
    return t;
  }

  function getReactSelectLabelByTestId(rootDoc, testId) {
    const btn = rootDoc?.querySelector?.(`button[data-test-id="${testId}"]`);
    if (!btn) return '';
    return normalizeText(btn.innerText || btn.textContent || '');
  }

  function findAndClickOptionByText(searchDoc, wanted) {
    if (!searchDoc) return false;
    const wantedN = normalizeText(wanted);
    if (!wantedN) return false;

    // 1) Prefer role="option"
    const opts = searchDoc.querySelectorAll('[role="option"]');
    for (let i = 0; i < opts.length; i++) {
      const el = opts[i];
      const txt = normalizeText(el.innerText || el.textContent || '');
      if (txt === wantedN) {
        try {
          el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } catch (_) {
          el.click();
        }
        return true;
      }
    }

    // 2) Prefer data-option-text blocks
    const optTexts = searchDoc.querySelectorAll('[data-option-text="true"]');
    for (let i = 0; i < optTexts.length; i++) {
      const el = optTexts[i];
      const txt = normalizeText(el.innerText || el.textContent || '');
      if (txt === wantedN) {
        const target = el.closest('[role="option"]') || el.closest('button') || el;
        try {
          target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          target.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } catch (_) {
          target.click();
        }
        return true;
      }
    }

    // 3) Fallback: any element inside abstractdropdown-content-* that matches
    const dropdownRoots = searchDoc.querySelectorAll('[id^="abstractdropdown-content-"]');
    for (let r = 0; r < dropdownRoots.length; r++) {
      const root = dropdownRoots[r];
      const els = root.querySelectorAll('button,[role="option"],div,span');
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const txt = normalizeText(el.innerText || el.textContent || '');
        if (txt === wantedN) {
          const target = el.closest('button') || el.closest('[role="option"]') || el;
          try {
            target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
            target.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          } catch (_) {
            target.click();
          }
          return true;
        }
      }
    }

    return false;
  }

  function setDealTypeReactSelect(rootDoc, dealType) {
    if (!rootDoc || !dealType) return;
    const btn = rootDoc.querySelector('button[data-test-id="dealtype-input"]');
    if (!btn) return;

    const desired = String(dealType).trim();
    if (!desired) return;

    // Ya está seleccionado
    const current = getDealTypeLabel(rootDoc);
    if (current && current === normalizeText(desired)) return;

    // Abrir dropdown
    try {
      btn.click();
    } catch (_) {}

    // Las opciones pueden renderizarse en el iframe o en el documento padre.
    const docsToSearch = [rootDoc, document];

    let tries = 0;
    function tryPick() {
      tries += 1;
      for (let i = 0; i < docsToSearch.length; i++) {
        const ok = findAndClickOptionByText(docsToSearch[i], desired);
        if (ok) {
          return;
        }
      }
      if (tries < 8) requestAnimationFrame(tryPick);
    }
    requestAnimationFrame(tryPick);
  }

  function setReactSelectByTestId(rootDoc, testId, desiredLabel) {
    if (!rootDoc || !testId || !desiredLabel) return;
    const btn = rootDoc.querySelector(`button[data-test-id="${testId}"]`);
    if (!btn) return;

    const desired = String(desiredLabel).trim();
    if (!desired) return;

    const current = getReactSelectLabelByTestId(rootDoc, testId);
    if (current && current === normalizeText(desired)) return;

    try {
      btn.click();
    } catch (_) {}

    const docsToSearch = [rootDoc, document];
    let tries = 0;
    function tryPick() {
      tries += 1;
      for (let i = 0; i < docsToSearch.length; i++) {
        const ok = findAndClickOptionByText(docsToSearch[i], desired);
        if (ok) {
          return;
        }
      }
      if (tries < 10) requestAnimationFrame(tryPick);
    }
    requestAnimationFrame(tryPick);
  }

  function fillAssociationDomain(rootDoc, domain) {
    const d = normalizeAssociationQuery(domain);
    if (!rootDoc || !d) return;

    // Importante: evitar colisiones con otros selects. El selector de asociaciones incluye data-fnd-select-multi-value="t".
    const btn =
      rootDoc.querySelector('button[data-test-id="association-input-0-1-index-0"][data-fnd-select-multi-value="t"]')
      || rootDoc.querySelector('button[data-test-id="association-input-0-1-index-0"]');
    if (!btn) return;

    const ownsId = btn.getAttribute('aria-owns') || '';
    try {
      btn.click();
    } catch (_) {}

    let tries = 0;
    function tryFill() {
      tries += 1;
      const iframeContainer = ownsId ? rootDoc.getElementById(ownsId) : null;
      const topContainer = ownsId ? document.getElementById(ownsId) : null;
      const container = iframeContainer || topContainer || null;

      // Preferimos el input dentro del dropdown concreto del botón "Asociar registros"
      const input =
        (container && (
          container.querySelector('input[type="search"][role="combobox"]')
          || container.querySelector('input[role="combobox"][type="search"]')
          || container.querySelector('input[type="search"]')
          || container.querySelector('input[role="combobox"]')
        ))
        || rootDoc.querySelector('input[type="search"][role="combobox"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[role="combobox"][type="search"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[type="search"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[role="combobox"][placeholder="Buscar"]');

      if (input) {
        try {
          input.focus?.();
        } catch (_) {}
        setNativeValue(input, d);
        // Ayuda a algunos React-select/typeahead que reaccionan a key events además de input/change.
        try {
          input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a' }));
          input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
        } catch (_) {}
        return;
      }

      if (tries < 12) requestAnimationFrame(tryFill);
    }
    requestAnimationFrame(tryFill);
  }

  function fillDealFields(fields) {
    if (!fields || typeof fields !== 'object') return;

    const rootDoc = getObjectBuilderIframeDoc() || document;

    const dealNameEl = rootDoc.querySelector('textarea[data-test-id="dealname-input"], textarea[data-selenium-test="property-input-dealname"]');
    const amountEl = rootDoc.querySelector('input[data-test-id="amount-input"], input[data-selenium-test="property-input-amount"]');
    const closeDateEl = rootDoc.querySelector('div[data-test-id="closedate-input"] input, div[data-selenium-test="property-input-closedate"] input');

    const dealnameFinal = typeof fields.dealname_final === 'string' ? fields.dealname_final.trim() : '';
    if (dealNameEl && dealnameFinal) setNativeValue(dealNameEl, dealnameFinal);

    if (typeof fields.deal_type === 'string' && fields.deal_type.trim()) {
      setDealTypeReactSelect(rootDoc, fields.deal_type);
    }

    // Deal Source: forzar siempre "Account Management"
    setReactSelectByTestId(rootDoc, 'deal_source-input', 'Account Management');

    // Asociar registros: autocompletar dominio de la empresa (sin seleccionar nada)
    if (lastCompanyAssociationQueryForDeal) {
      fillAssociationDomain(rootDoc, lastCompanyAssociationQueryForDeal);
    }

    const amount = normalizeAmount(fields.valor);
    if (amountEl && amount) setNativeValue(amountEl, amount);

    const dateStr =
      (typeof fields.fecha_cierre === 'string' && fields.fecha_cierre.trim())
      ? fields.fecha_cierre.trim()
      : formatDateDDMMYYYY(addOneMonth(new Date()));
    if (closeDateEl && dateStr) setNativeValue(closeDateEl, dateStr);
  }

  globalThis.fillDealFields = fillDealFields;

  /**
   * Vista previa en página (mismo texto que el log del popup) si el ajuste lo permite.
   */
  function showFloatingLogPanel(data) {
    removeFloatingLogPanel();
    if (!data || typeof globalThis.AvvaleFormatLog !== 'function') return;

    const wrap = document.createElement('div');
    wrap.id = LOG_PANEL_ID;
    wrap.className = 'avvale-companion-log-panel';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('aria-label', 'Vista previa de datos recopilados');

    const header = document.createElement('div');
    header.className = 'avvale-companion-log-panel__header';
    const title = document.createElement('span');
    title.className = 'avvale-companion-log-panel__title';
    title.textContent = 'Datos recopilados';
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'avvale-companion-log-panel__close';
    closeBtn.setAttribute('aria-label', 'Cerrar vista previa');
    closeBtn.textContent = '×';
    closeBtn.addEventListener('click', removeFloatingLogPanel);

    header.appendChild(title);
    header.appendChild(closeBtn);

    const pre = document.createElement('pre');
    pre.className = 'avvale-companion-log-panel__pre';
    pre.textContent = globalThis.AvvaleFormatLog(data);

    wrap.appendChild(header);
    wrap.appendChild(pre);
    document.documentElement.appendChild(wrap);
  }

  function showToast(message, isError) {
    let el = document.getElementById(TOAST_ID);
    if (!el) {
      el = document.createElement('div');
      el.id = TOAST_ID;
      el.className = 'avvale-companion-toast';
      el.setAttribute('role', 'status');
      document.documentElement.appendChild(el);
    }
    const escapeHtml = (s) =>
      String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    if (typeof message === 'string' && message.startsWith('Recopilado.')) {
      const rest = message.slice('Recopilado.'.length);
      el.innerHTML = `<strong>Recopilado.</strong>${escapeHtml(rest)}`;
    } else {
      el.textContent = message;
    }
    el.classList.toggle('avvale-companion-toast--error', !!isError);

    // Posicionar el toast justo encima del botón Recopilar/Enviar (barra izquierda)
    const recopilarBtn = document.getElementById(BTN_ID);
    if (recopilarBtn) {
      const r = recopilarBtn.getBoundingClientRect();
      const gap = 10;
      el.style.left = `${Math.max(8, Math.round(r.left))}px`;
      el.style.right = 'auto';
      el.style.bottom = `${Math.max(8, Math.round(window.innerHeight - r.top + gap))}px`;
      el.style.maxWidth = `${Math.round(r.width)}px`;
    } else {
      // fallback a estilos por CSS (esquina inferior derecha)
      el.style.left = '';
      el.style.right = '';
      el.style.bottom = '';
      el.style.maxWidth = '';
    }

    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => {
      el?.remove();
    }, 4500);
  }

  function ensureLeftBar() {
    if (!isRecordViewUrl(location.href)) return null;
    let bar = document.getElementById(LEFT_BAR_ID);
    if (bar) return bar;
    bar = document.createElement('div');
    bar.id = LEFT_BAR_ID;
    bar.className = 'avvale-companion-floating-bar-left';
    document.documentElement.appendChild(bar);
    return bar;
  }

  function ensureFromOfferTopButton() {
    if (!isRecordViewUrl(location.href)) return;
    let btn = document.getElementById(FROM_OFFER_ID);
    if (btn) return;
    btn = document.createElement('button');
    btn.id = FROM_OFFER_ID;
    btn.type = 'button';
    btn.className = 'avvale-companion-floating-btn avvale-companion-floating-btn--left avvale-companion-floating-btn--from-offer';
    btn.textContent = 'Desde oferta';
    btn.setAttribute('aria-label', 'Desde oferta');
    btn.addEventListener('click', () => {
      if (typeof globalThis.initPDFAnalyzer !== 'function') {
        showToast('Error interno: módulo PDF no cargado.', true);
        return;
      }
      try {
        globalThis.initPDFAnalyzer();
      } catch (e) {
        showToast(e.message || 'Error al abrir el analizador de PDF.', true);
      }
    });
    document.documentElement.appendChild(btn);
  }

  function findRightSidebarAddButton() {
    const sidebar = document.querySelector(RIGHT_SIDEBAR_SELECTOR) || document;

    // 1) Prefer: "Negocios" card wrapper (avoid Contactos/Empresas, etc.)
    const cardTitles = sidebar.querySelectorAll('[data-selenium-test="crm-card-title"], [data-test-id="crm-card-title"]');
    for (let i = 0; i < cardTitles.length; i++) {
      const t = cardTitles[i];
      const titleText = (t.innerText || t.textContent || '').trim().toLowerCase();
      if (!titleText.includes('negocios')) continue;

      const cardWrapper =
        t.closest('[data-test-id^="card-wrapper-"]')
        || t.closest('[data-test-id^="card-wrapper-"][id^="card-wrapper-"]')
        || t.closest('[id^="card-wrapper-"]')
        || t.closest('[data-test-id^="card-wrapper"]');

      if (!cardWrapper) continue;

      // Find "Agregar" button inside that card's header toolbar/actions
      const addBtn =
        cardWrapper.querySelector('button svg[data-icon-name="Add"]')?.closest('button')
        || cardWrapper.querySelector('button:has(svg[data-icon-name="Add"])');

      if (addBtn) {
        const btnText = (addBtn.innerText || addBtn.textContent || '').trim().toLowerCase();
        if (btnText.includes('agregar')) return addBtn;
      }
    }

    // 2) Fallback: exact markup: text container with Add icon + "Agregar"
    const textContainers = sidebar.querySelectorAll('span.PrivateButton__StyledButtonTextContainer-gKiNOa');
    for (let i = 0; i < textContainers.length; i++) {
      const c = textContainers[i];
      const hasAddIcon = !!c.querySelector('svg[data-icon-name="Add"]');
      if (!hasAddIcon) continue;
      const label = (c.querySelector('span')?.innerText || c.textContent || '').trim();
      if (!label.toLowerCase().includes('agregar')) continue;
      const btn = c.closest('button');
      if (btn) return btn;
    }

    // Fallback 1: any button with Add icon and "Agregar" text in right sidebar
    const candidates = sidebar.querySelectorAll('button');
    for (let i = 0; i < candidates.length; i++) {
      const b = candidates[i];
      const text = (b.innerText || b.textContent || '').trim();
      if (!text || !text.toLowerCase().includes('agregar')) continue;
      const hasAddIcon = !!b.querySelector('svg[data-icon-name="Add"]');
      if (hasAddIcon) return b;
    }

    // Fallback 2: data-attributes comunes en HubSpot
    return (
      (document.querySelector(`${RIGHT_SIDEBAR_SELECTOR} button[data-selenium-test="build-object-button"]`))
      || (document.querySelector(`${RIGHT_SIDEBAR_SELECTOR} button[data-test-id="build-object-button"]`))
      || null
    );
  }

  function ensureNewDealButton() {
    if (!isRecordViewUrl(location.href)) return;
    let btn = document.getElementById(NEWDEAL_ID);
    if (btn) return;

    const bar = ensureLeftBar();
    btn = document.createElement('button');
    btn.id = NEWDEAL_ID;
    btn.type = 'button';
    btn.className = 'avvale-companion-floating-btn';
    btn.textContent = 'Nuevo Deal';
    btn.setAttribute('aria-label', 'Nuevo Deal');
    btn.addEventListener('click', () => {
      ensureFromOfferTopButton();
      // Capturar dominio de la empresa (0-2) para usarlo luego en el builder (Asociar registros)
      lastCompanyAssociationQueryForDeal = getCompanyDomainFromHighlight();

      const addBtn = findRightSidebarAddButton();
      if (!addBtn) {
        showToast('No se encontró el botón “Agregar” en “Negocios”.', true);
        return;
      }
      try {
        addBtn.click();
        showToast('Abriendo creación…');
      } catch (e) {
        showToast(e.message || 'No se pudo hacer click en “Agregar”.', true);
      }
    });
    (bar || document.documentElement).appendChild(btn);
  }

  function setFloatingButtonMode(btn, mode) {
    if (!btn) return;
    const prev = btn.dataset.avvaleMode;
    if (prev === mode) return;
    btn.dataset.avvaleMode = mode;
    if (mode === 'enviar') {
      btn.textContent = 'Enviar activación';
      btn.setAttribute('aria-label', 'Enviar datos a activación en Avvale Companion');
      btn.classList.add(SECONDARY_CLASS);
    } else {
      btn.textContent = 'Recopilar';
      btn.setAttribute('aria-label', 'Recopilar datos para Avvale Companion');
      btn.classList.remove(SECONDARY_CLASS);
    }
  }

  function applyFloatingStateFromStorage(btn) {
    chrome.storage.local.get(
      { [STORAGE_KEY_LAST_RECOPILATED]: null },
      (data) => {
        if (!document.getElementById(BTN_ID)) return;
        const payload = data[STORAGE_KEY_LAST_RECOPILATED];
        if (
          payload
          && typeof payload === 'object'
          && payload.hubspotUrl
          && sameRecordPage(payload.hubspotUrl, location.href)
        ) {
          setFloatingButtonMode(btn, 'enviar');
        } else {
          setFloatingButtonMode(btn, 'recopilar');
          removeFloatingLogPanel();
        }
      }
    );
  }

  function onEnviarClick(btn) {
    if (!btn || btn.disabled) return;
    if (!globalThis.AvvaleActivation) {
      showToast('Error interno: módulo de activación no cargado.', true);
      return;
    }
    btn.disabled = true;
    chrome.storage.local.get(
      {
        [STORAGE_KEY_ACTIVATION_ENV]: 'pro',
        [STORAGE_KEY_LAST_RECOPILATED]: null,
      },
      (data) => {
        if (chrome.runtime.lastError) {
          btn.disabled = false;
          showToast(chrome.runtime.lastError.message || 'Error al leer datos.', true);
          return;
        }
        const payload = data[STORAGE_KEY_LAST_RECOPILATED];
        const env = data[STORAGE_KEY_ACTIVATION_ENV] === 'pro' ? 'pro' : 'dev';
        if (!payload || typeof payload !== 'object') {
          btn.disabled = false;
          showToast('No hay datos para enviar. Pulsa Recopilar.', true);
          setFloatingButtonMode(btn, 'recopilar');
          return;
        }
        if (!sameRecordPage(payload.hubspotUrl, location.href)) {
          btn.disabled = false;
          showToast('Los datos no corresponden a esta página. Recopila de nuevo.', true);
          setFloatingButtonMode(btn, 'recopilar');
          return;
        }
        let activationUrl;
        try {
          const base = globalThis.AvvaleActivation.getActivationBaseUrl(env);
          activationUrl = base + '#' + globalThis.AvvaleActivation.toBase64Url(payload);
        } catch (e) {
          btn.disabled = false;
          showToast(e.message || 'Error al preparar la URL.', true);
          return;
        }
        chrome.runtime.sendMessage(
          { type: 'OPEN_URL', url: activationUrl },
          (response) => {
            btn.disabled = false;
            if (chrome.runtime.lastError) {
              showToast(chrome.runtime.lastError.message || 'No se pudo abrir la pestaña.', true);
              return;
            }
            if (!response || !response.ok) {
              showToast((response && response.error) || 'No se pudo abrir la pestaña.', true);
              return;
            }
            showToast(`Pestaña abierta (${env === 'pro' ? 'PRO' : 'DEV'}).`);
          }
        );
      }
    );
  }

  function onRecopilarClick(btn) {
    if (!btn || btn.disabled) return;
    if (typeof globalThis.extractInPageAfterSidebarPrep !== 'function') {
      showToast('Error interno: no se pudo cargar la extracción.', true);
      return;
    }
    btn.disabled = true;
    showLoadingSpinner();
    globalThis
      .extractInPageAfterSidebarPrep()
      .then((data) => {
        hideLoadingSpinner();
        if (!data) {
          showToast('No se obtuvieron datos.', true);
          btn.disabled = false;
          return;
        }
        chrome.storage.local.set({ [STORAGE_KEY_LAST_RECOPILATED]: data }, () => {
          btn.disabled = false;
          if (chrome.runtime.lastError) {
            showToast(chrome.runtime.lastError.message || 'Error al guardar.', true);
            return;
          }
          chrome.storage.local.get(
            { [STORAGE_KEY_SHOW_LOG_PREVIEW]: true },
            (s) => {
              const showPreview = !!s[STORAGE_KEY_SHOW_LOG_PREVIEW];
              if (showPreview) {
                showFloatingLogPanel(data);
              } else {
                removeFloatingLogPanel();
                showToast('Recopilado. Pulsa Enviar activación.');
              }
              setFloatingButtonMode(btn, 'enviar');
            }
          );
        });
      })
      .catch((e) => {
        hideLoadingSpinner();
        btn.disabled = false;
        showToast(e.message || 'Error al recopilar.', true);
      });
  }

  function onFloatingButtonClick() {
    const btn = document.getElementById(BTN_ID);
    if (!btn || btn.disabled) return;
    if (btn.dataset.avvaleMode === 'enviar') {
      onEnviarClick(btn);
    } else {
      onRecopilarClick(btn);
    }
  }

  function ensureFloatingButton() {
    if (!isRecordViewUrl(location.href)) {
      removeFloatingButton();
      return;
    }

    if (isDealRecordUrl(location.href)) {
      // En Deals (0-3) ocultamos "Nuevo Deal" y "Desde oferta"; mantenemos Recopilar/Enviar.
      document.getElementById(NEWDEAL_ID)?.remove();
      document.getElementById(FROM_OFFER_ID)?.remove();
    }

    if (isCompanyRecordUrl(location.href)) {
      // En Empresas (0-2) ocultamos Recopilar/Enviar y limpiamos UI asociada.
      document.getElementById(BTN_ID)?.remove();
      removeFloatingLogPanel();
      removeToast();
      hideLoadingSpinner();

      ensureLeftBar();
      ensureNewDealButton();
      document.getElementById(PDF_ID)?.remove();
      return;
    }

    ensureLeftBar();
    document.getElementById(PDF_ID)?.remove();
    // Orden visual en la barra izquierda: primero "Nuevo Deal", luego "Recopilar/Enviar"
    if (!isDealRecordUrl(location.href)) ensureNewDealButton();
    let btn = document.getElementById(BTN_ID);
    if (!btn) {
      btn = document.createElement('button');
      btn.id = BTN_ID;
      btn.type = 'button';
      btn.className = 'avvale-companion-floating-btn';
      btn.dataset.avvaleMode = 'recopilar';
      btn.textContent = 'Recopilar';
      btn.setAttribute('aria-label', 'Recopilar datos para Avvale Companion');
      btn.addEventListener('click', onFloatingButtonClick);
      const bar = document.getElementById(LEFT_BAR_ID);
      (bar || document.documentElement).appendChild(btn);
    }
    applyFloatingStateFromStorage(btn);
  }

  function sync() {
    ensureFloatingButton();
    ensurePmEmailSuggestOnDeal();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY_SHOW_LOG_PREVIEW]) return;
    if (changes[STORAGE_KEY_SHOW_LOG_PREVIEW].newValue === false) {
      removeFloatingLogPanel();
    }
  });

  sync();
  setInterval(sync, 800);
  window.addEventListener('popstate', sync);
})();
