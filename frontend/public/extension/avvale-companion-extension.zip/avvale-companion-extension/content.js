/**
 * Avvale Companion - Content Script (HubSpot)
 * Botón flotante: Recopilar → Enviar a activación en vistas de record.
 */
(function () {
  const STORAGE_KEY_LAST_RECOPILATED = 'lastRecopilatedData';
  const STORAGE_KEY_ACTIVATION_ENV = 'activationEnvironment';
  const STORAGE_KEY_SHOW_LOG_PREVIEW = 'showRecopilateLogPreview';
  const BTN_ID = 'avvale-companion-floating-recopilar';
  const NEWDEAL_ID = 'avvale-companion-floating-newdeal';
  const FROM_OFFER_ID = 'avvale-companion-top-from-offer';
  const LEFT_BAR_ID = 'avvale-companion-floating-left-bar';
  const PDF_ID = 'avvale-companion-floating-pdf';
  const PREVIEW_FILL_BTN_ID = 'avvale-companion-preview-fill-btn';
  const FILL_FLOAT_WRAP_ID = 'avvale-companion-floating-fill-wrap';
  /** Prefijos data-table-external-id (vista lista deals 0-3). */
  const HS_CELL_COUNT_SCHEDULE_PREFIX = 'cell-0-3-count_of_schedule';
  const HS_CELL_GOLIVE_PREFIX = 'cell-0-3-golive_date';
  const RIGHT_SIDEBAR_SELECTOR = '[data-scroll-trackable-container="right-sidebar"]';
  let lastCompanyAssociationQueryForDeal = '';

  /** Sugerencias correo PM: ficha deal, y en vista lista cualquier celda editable `framework-data-table-editable-cell-input` */
  const PM_EMAIL_PANEL_ID = 'avvale-companion-pm-suggest';
  const PM_EMAIL_SELECTOR = 'textarea[data-selenium-test="property-input-project_manager_email"]';
  const PM_INLINE_TABLE_TEXTAREA_SELECTOR = 'textarea[data-selenium-test="framework-data-table-editable-cell-input"]';
  /** Contactos CC desde API Companion (misma clave que avvale-api-client.js). */
  const STORAGE_KEY_AVVALE_CC_CONTACTS = 'avvaleCcContacts';
  let pmSuggestContactsCache = [];

  function refreshPmContactsCache(callback) {
    chrome.storage.local.get({ [STORAGE_KEY_AVVALE_CC_CONTACTS]: null }, (data) => {
      const raw = data[STORAGE_KEY_AVVALE_CC_CONTACTS];
      pmSuggestContactsCache = Array.isArray(raw) ? raw : [];
      if (typeof callback === 'function') callback();
    });
  }

  refreshPmContactsCache();

  try {
    chrome.storage.onChanged.addListener((changes, areaName) => {
      if (areaName !== 'local' || !changes[STORAGE_KEY_AVVALE_CC_CONTACTS]) return;
      refreshPmContactsCache();
    });
  } catch (_) {}

  let activePmEmailTextarea = null;
  /** Diferir actualización del panel tras input para no competir con el input controlado de HubSpot (React). */
  let pmSuggestInputDeferTimer = null;
  const PM_SUGGEST_INPUT_DEBOUNCE_MS = 120;
  let lastPmSuggestListSig = '';
  let lastPmSuggestTextareaEl = null;
  /** Tras elegir un correo, evitar que focus/input vuelvan a abrir el listado al instante. */
  let pmSuggestSuppressOpenUntil = 0;
  /** Índice del correo resaltado con flechas (-1 = ninguno; Enter usa el primero). */
  let pmSuggestHighlightIndex = -1;

  function isPmSuggestSuppressed() {
    return Date.now() < pmSuggestSuppressOpenUntil;
  }

  function isPageReload() {
    try {
      const nav = performance.getEntriesByType('navigation')[0];
      if (nav && nav.type === 'reload') return true;
    } catch (_) {}
    try {
      if (performance.navigation && performance.navigation.type === 1) return true;
    } catch (_) {}
    return false;
  }

  if (isPageReload()) {
    chrome.storage.local.remove(STORAGE_KEY_LAST_RECOPILATED);
  }

  const TOAST_ID = 'avvale-companion-toast';
  const LOG_PANEL_ID = 'avvale-companion-log-panel';
  const LOADING_ID = 'avvale-companion-loading';
  const SECONDARY_CLASS = 'avvale-companion-floating-btn--secondary';

  function showLoadingSpinner() {
    hideLoadingSpinner();
    const wrap = document.createElement('div');
    wrap.id = LOADING_ID;
    wrap.className = 'avvale-companion-loading';
    wrap.setAttribute('role', 'status');
    wrap.setAttribute('aria-live', 'polite');
    const spin = document.createElement('span');
    spin.className = 'avvale-companion-loading__spinner';
    spin.setAttribute('aria-hidden', 'true');
    const label = document.createElement('span');
    label.textContent = 'Recopilando…';
    wrap.appendChild(spin);
    wrap.appendChild(label);
    document.documentElement.appendChild(wrap);

    // Posicionar "Recopilando…" justo encima del botón Recopilar/Enviar.
    const recopilarBtn = document.getElementById(BTN_ID);
    if (recopilarBtn) {
      const r = recopilarBtn.getBoundingClientRect();
      const gap = 10;
      wrap.style.left = `${Math.max(8, Math.round(r.left))}px`;
      wrap.style.right = 'auto';
      wrap.style.bottom = `${Math.max(8, Math.round(window.innerHeight - r.top + gap))}px`;
      wrap.style.maxWidth = `${Math.round(r.width)}px`;
    } else {
      wrap.style.left = '';
      wrap.style.right = '';
      wrap.style.bottom = '';
      wrap.style.maxWidth = '';
    }
  }

  function hideLoadingSpinner() {
    document.getElementById(LOADING_ID)?.remove();
  }

  function isRecordViewUrl(href) {
    try {
      const u = new URL(href);
      if (u.hostname !== 'app.hubspot.com') return false;
      const p = u.pathname.split('/').filter(Boolean);
      return (
        p.length >= 5
        && p[0] === 'contacts'
        && p[2] === 'record'
        && /^\d+-\d+$/.test(p[3])
        && /^\d+$/.test(p[4])
      );
    } catch {
      return false;
    }
  }

  function getRecordTypeFromUrl(href) {
    try {
      const u = new URL(href);
      const p = u.pathname.split('/').filter(Boolean);
      if (p.length >= 5 && p[0] === 'contacts' && p[2] === 'record') return p[3];
    } catch (_) {}
    return null;
  }

  function isCompanyRecordUrl(href) {
    return getRecordTypeFromUrl(href) === '0-2';
  }

  function isDealRecordUrl(href) {
    return getRecordTypeFromUrl(href) === '0-3';
  }

  /** Ficha de deal o vista lista/tabla de deals (0-3), p. ej. …/objects/0-3/views/…/list */
  function isDeal0_3HubSpotUrl(href) {
    if (isDealRecordUrl(href)) return true;
    try {
      return /\/objects\/0-3\//.test(new URL(href).pathname);
    } catch {
      return false;
    }
  }

  /** Solo vista tabla/lista (/objects/0-3/…), no ficha record (evita solapar botón Fill con Recopilar). */
  function isDealObjectsTableUrl(href) {
    try {
      return /\/objects\/0-3\//.test(new URL(href).pathname);
    } catch {
      return false;
    }
  }

  function sameRecordPage(storedHubspotUrl, currentHref) {
    try {
      const a = new URL(storedHubspotUrl);
      const b = new URL(currentHref);
      return a.pathname === b.pathname;
    } catch {
      return false;
    }
  }

  function removeFloatingLogPanel() {
    document.getElementById(LOG_PANEL_ID)?.remove();
  }

  function removeToast() {
    document.getElementById(TOAST_ID)?.remove();
  }

  function removeFloatingButton() {
    document.getElementById(BTN_ID)?.remove();
    document.getElementById(NEWDEAL_ID)?.remove();
    document.getElementById(FROM_OFFER_ID)?.remove();
    document.getElementById(PDF_ID)?.remove();
    document.getElementById(LEFT_BAR_ID)?.remove();
    removeFloatingLogPanel();
    removeToast();
    hideLoadingSpinner();
    /* No cerrar el panel PM aquí: en vista lista (/objects/0-3/…) isRecordViewUrl es false y
       sync() llamaba removeFloatingButton cada 800ms y mataba el desplegable. Cierre vía ensurePmEmailSuggestOnDeal. */
  }

  function setNativeValue(element, value) {
    if (!element) return;
    const proto = element.constructor && element.constructor.prototype;
    const desc = proto ? Object.getOwnPropertyDescriptor(proto, 'value') : null;
    const setter = desc && typeof desc.set === 'function' ? desc.set : null;
    if (setter) {
      setter.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function getOrCreatePmEmailSuggestPanel() {
    let panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (panel) return panel;
    panel = document.createElement('div');
    panel.id = PM_EMAIL_PANEL_ID;
    panel.className = 'avvale-companion-pm-suggest';
    panel.setAttribute('role', 'listbox');
    panel.setAttribute('aria-label', 'Correos sugeridos');
    panel.hidden = true;
    document.documentElement.appendChild(panel);
    return panel;
  }

  function positionPmEmailSuggestPanel(panel, anchorEl) {
    const r = anchorEl.getBoundingClientRect();
    const gap = 4;
    const minW = 280;
    const w = Math.max(r.width, minW);
    let left = r.left;
    if (left + w > window.innerWidth - 8) left = Math.max(8, window.innerWidth - w - 8);
    panel.style.top = `${Math.round(r.bottom + gap)}px`;
    panel.style.left = `${Math.round(left)}px`;
    panel.style.width = `${Math.round(w)}px`;
    panel.style.zIndex = '2147483647';
    panel.style.pointerEvents = 'auto';
  }

  function hidePmEmailSuggestPanel() {
    const panel = document.getElementById(PM_EMAIL_PANEL_ID);
    if (panel) {
      panel.hidden = true;
      panel.innerHTML = '';
    }
    activePmEmailTextarea = null;
    lastPmSuggestListSig = '';
    lastPmSuggestTextareaEl = null;
    pmSuggestHighlightIndex = -1;
  }

  function getPmSuggestEntries(query) {
    const q = String(query || '').trim().toLowerCase();
    const rows = pmSuggestContactsCache
      .map((c) => ({
        email: typeof c.email === 'string' ? c.email.trim() : '',
        name: typeof c.name === 'string' ? c.name.trim() : '',
      }))
      .filter((r) => r.email);
    let filtered = rows;
    if (q) {
      filtered = rows.filter(
        (r) =>
          r.email.toLowerCase().includes(q) ||
          (r.name && r.name.toLowerCase().includes(q)),
      );
    }
    return filtered.map((r) => ({
      email: r.email,
      label: r.name ? `${r.name} — ${r.email}` : r.email,
    }));
  }

  /** Siguiente campo rellenable en la misma fila de la tabla (vista lista HubSpot). */
  function focusNextEditableInTableRow(fromEl) {
    const row = fromEl.closest('tr') || fromEl.closest('[role="row"]');
    if (!row) return false;
    const sel = [
      'textarea:not([disabled])',
      'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([disabled])',
      'select:not([disabled])',
      '[contenteditable="true"]',
    ].join(',');
    const nodes = Array.from(row.querySelectorAll(sel)).filter((el) => {
      if (el.hasAttribute('readonly')) return false;
      const st = window.getComputedStyle(el);
      if (st.display === 'none' || st.visibility === 'hidden') return false;
      const r = el.getBoundingClientRect();
      if (r.width < 2 && r.height < 2) return false;
      return true;
    });
    const idx = nodes.indexOf(fromEl);
    if (idx < 0 || idx >= nodes.length - 1) return false;
    const next = nodes[idx + 1];
    try {
      next.focus({ preventScroll: false });
    } catch (_) {
      try {
        next.focus();
      } catch (_) {
        return false;
      }
    }
    return true;
  }

  function applyPmSuggestEmailSelection(textarea, email) {
    if (!textarea || !email) return;
    clearTimeout(pmSuggestInputDeferTimer);
    pmSuggestInputDeferTimer = null;
    pmSuggestSuppressOpenUntil = Date.now() + 600;
    setNativeValue(textarea, email);
    hidePmEmailSuggestPanel();
    setTimeout(() => {
      if (!textarea.isConnected) return;
      if (!focusNextEditableInTableRow(textarea)) {
        try {
          textarea.focus();
        } catch (_) {}
      }
    }, 0);
  }

  function getPmSuggestItemButtons(panel) {
    return panel.querySelectorAll('button.avvale-companion-pm-suggest__item[data-email]');
  }

  function setPmSuggestHighlight(panel, index) {
    const buttons = getPmSuggestItemButtons(panel);
    const n = buttons.length;
    if (n === 0) {
      pmSuggestHighlightIndex = -1;
      return;
    }
    let i = index;
    if (i < -1) i = -1;
    if (i >= n) i = n - 1;
    pmSuggestHighlightIndex = i;
    buttons.forEach((btn, j) => {
      const on = i >= 0 && j === i;
      btn.classList.toggle('avvale-companion-pm-suggest__item--active', on);
      btn.setAttribute('aria-selected', on ? 'true' : 'false');
    });
    if (i >= 0 && buttons[i]) {
      try {
        buttons[i].scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      } catch (_) {
        try {
          buttons[i].scrollIntoView({ block: 'nearest' });
        } catch (_) {}
      }
    }
  }

  function renderPmEmailSuggestItems(panel, textarea, entries) {
    panel.innerHTML = '';
    pmSuggestHighlightIndex = -1;
    if (entries.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'avvale-companion-pm-suggest__empty';
      const q = textarea && typeof textarea.value === 'string' ? textarea.value.trim() : '';
      if (pmSuggestContactsCache.length === 0 && !q) {
        empty.textContent =
          'Sincroniza los contactos desde el popup de la extensión (ajustes → Companion API).';
      } else {
        empty.textContent = 'Sin coincidencias';
      }
      panel.appendChild(empty);
      return;
    }
    entries.forEach((entry, itemIndex) => {
      const email = entry.email;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'avvale-companion-pm-suggest__item';
      btn.setAttribute('role', 'option');
      btn.dataset.email = email;
      btn.textContent = entry.label || email;
      btn.addEventListener('mousedown', (e) => {
        e.preventDefault();
        e.stopPropagation();
        pmSuggestHighlightIndex = itemIndex;
        applyPmSuggestEmailSelection(textarea, email);
      });
      panel.appendChild(btn);
    });
    setPmSuggestHighlight(panel, -1);
  }

  function updatePmEmailSuggestPanel(textarea) {
    if (!textarea || textarea.tagName !== 'TEXTAREA') return;
    if (isPmSuggestSuppressed()) return;
    const panel = getOrCreatePmEmailSuggestPanel();
    activePmEmailTextarea = textarea;
    const entries = getPmSuggestEntries(textarea.value);
    const listSig =
      textarea.value +
      '\x00' +
      entries.map((e) => e.email + '\x02' + (e.label || '')).join('\x01');
    const sameFiltered =
      lastPmSuggestTextareaEl === textarea && lastPmSuggestListSig === listSig;
    if (!sameFiltered) {
      lastPmSuggestListSig = listSig;
      lastPmSuggestTextareaEl = textarea;
      renderPmEmailSuggestItems(panel, textarea, entries);
    }
    positionPmEmailSuggestPanel(panel, textarea);
    panel.hidden = false;
  }

  function onPmEmailTextareaFocusIn(e) {
    if (!isDeal0_3HubSpotUrl(location.href)) return;
    if (isPmSuggestSuppressed()) return;
    const ta = e.currentTarget;
    clearTimeout(pmSuggestInputDeferTimer);
    pmSuggestInputDeferTimer = null;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (!ta.isConnected) return;
        updatePmEmailSuggestPanel(ta);
      });
    });
  }

  function onPmEmailTextareaInput(e) {
    if (!isDeal0_3HubSpotUrl(location.href)) return;
    if (e.isComposing) return;
    const ta = e.currentTarget;
    clearTimeout(pmSuggestInputDeferTimer);
    pmSuggestInputDeferTimer = setTimeout(() => {
      pmSuggestInputDeferTimer = null;
      if (!ta.isConnected) return;
      updatePmEmailSuggestPanel(ta);
    }, PM_SUGGEST_INPUT_DEBOUNCE_MS);
  }

  function onPmEmailTextareaCompositionEnd(e) {
    if (!isDeal0_3HubSpotUrl(location.href)) return;
    const ta = e.currentTarget;
    clearTimeout(pmSuggestInputDeferTimer);
    pmSuggestInputDeferTimer = null;
    if (!ta.isConnected) return;
    updatePmEmailSuggestPanel(ta);
  }

  function onPmEmailTextareaBlur() {
    clearTimeout(pmSuggestInputDeferTimer);
    pmSuggestInputDeferTimer = null;
  }

  function onPmSuggestDocumentKeydown(e) {
    const panel = document.getElementById(PM_EMAIL_PANEL_ID);
    const panelOpen = panel && !panel.hidden;

    if (e.key === 'Escape') {
      if (!panelOpen) return;
      e.preventDefault();
      hidePmEmailSuggestPanel();
      return;
    }

    if ((e.key === 'ArrowDown' || e.key === 'ArrowUp') && panelOpen) {
      const ta = activePmEmailTextarea;
      if (!ta || !ta.isConnected || e.target !== ta) return;
      const buttons = getPmSuggestItemButtons(panel);
      if (buttons.length === 0) return;
      e.preventDefault();
      e.stopPropagation();
      let next = pmSuggestHighlightIndex;
      if (e.key === 'ArrowDown') {
        next = next < 0 ? 0 : Math.min(buttons.length - 1, next + 1);
      } else {
        next = next <= 0 ? -1 : next - 1;
      }
      setPmSuggestHighlight(panel, next);
      return;
    }

    if (e.key === 'Enter' && panelOpen) {
      if (e.isComposing) return;
      const ta = activePmEmailTextarea;
      if (!ta || !ta.isConnected || e.target !== ta) return;
      const buttons = getPmSuggestItemButtons(panel);
      if (buttons.length === 0) return;
      let idx = pmSuggestHighlightIndex;
      if (idx < 0 || idx >= buttons.length) idx = 0;
      const chosen = buttons[idx];
      const email = chosen && chosen.dataset ? chosen.dataset.email : '';
      if (!email) return;
      e.preventDefault();
      e.stopPropagation();
      applyPmSuggestEmailSelection(ta, email);
    }
  }

  function ensurePmEmailSuggestOnDeal() {
    if (!isDeal0_3HubSpotUrl(location.href)) {
      hidePmEmailSuggestPanel();
      return;
    }
    const seen = new Set();
    document.querySelectorAll(PM_EMAIL_SELECTOR).forEach((ta) => {
      seen.add(ta);
    });
    document.querySelectorAll(PM_INLINE_TABLE_TEXTAREA_SELECTOR).forEach((ta) => {
      seen.add(ta);
    });
    seen.forEach((ta) => {
      if (ta.dataset.avvalePmSuggestBound === '1') return;
      ta.dataset.avvalePmSuggestBound = '1';
      ta.addEventListener('focusin', onPmEmailTextareaFocusIn);
      ta.addEventListener('input', onPmEmailTextareaInput);
      ta.addEventListener('compositionend', onPmEmailTextareaCompositionEnd);
      ta.addEventListener('blur', onPmEmailTextareaBlur);
    });
  }

  document.addEventListener('keydown', onPmSuggestDocumentKeydown, true);

  function pad2(n) {
    return String(n).padStart(2, '0');
  }

  function formatDateDDMMYYYY(d) {
    return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
  }

  function addOneMonth(date) {
    const d = new Date(date.getTime());
    const day = d.getDate();
    d.setMonth(d.getMonth() + 1);
    if (d.getDate() !== day) d.setDate(0);
    return d;
  }

  function normalizeAmount(v) {
    if (v == null) return '';
    if (typeof v === 'number' && Number.isFinite(v)) return String(v);
    const s = String(v).trim();
    if (!s) return '';
    // Quitar moneda/espacios y separadores comunes, dejar dígitos.
    const digits = s.replace(/[^\d]/g, '');
    return digits;
  }

  function getObjectBuilderIframeDoc() {
    const iframe =
      document.querySelector('iframe#object-builder-ui')
      || document.querySelector('iframe[data-test-id="object-builder-ui-iframe"]')
      || document.querySelector('iframe[data-selenium-test="associate-panel-iframe"]');
    if (!iframe) return null;
    try {
      return iframe.contentDocument || iframe.contentWindow?.document || null;
    } catch (_) {
      // Si HubSpot cambia a cross-origin en algún flujo, esto lanzará.
      return null;
    }
  }

  function normalizeText(s) {
    return String(s || '')
      .replace(/\u200b/g, '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function normalizeAssociationQuery(raw) {
    const s = String(raw || '').trim();
    if (!s) return '';

    // Preferimos URL completa si existe (el usuario pidió URL de empresa).
    try {
      if (/^https?:\/\//i.test(s)) {
        const u = new URL(s);
        const proto = u.protocol.toLowerCase() === 'https:' ? 'https:' : 'http:';
        const host = u.hostname.replace(/^www\./i, '');
        return `${proto}//${host}`;
      }
    } catch (_) {}

    // Si viene como texto tipo "diagroup.com", normalizar a URL http://
    const host = s
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '')
      .replace(/\/.*$/, '')
      .trim();
    if (!host) return '';
    return `http://${host}`;
  }

  function getCompanyDomainFromHighlight() {
    // Caso típico: <span data-test-id="highlight-property-display-domain"><a href="http://diagroup.com">diagroup.com</a>
    const a =
      document.querySelector('[data-test-id="highlight-property-display-domain"] a')
      || document.querySelector('[data-test-id="highlight-property-item-domain"] a');
    if (!a) return '';
    const href = a.getAttribute('href') || '';
    const text = (a.innerText || a.textContent || '').trim();
    return normalizeAssociationQuery(href) || normalizeAssociationQuery(text);
  }

  function getDealTypeLabel(rootDoc) {
    const btn = rootDoc?.querySelector?.('button[data-test-id="dealtype-input"]');
    if (!btn) return '';
    const t = normalizeText(btn.innerText || btn.textContent || '');
    return t;
  }

  function getReactSelectLabelByTestId(rootDoc, testId) {
    const btn = rootDoc?.querySelector?.(`button[data-test-id="${testId}"]`);
    if (!btn) return '';
    return normalizeText(btn.innerText || btn.textContent || '');
  }

  function findAndClickOptionByText(searchDoc, wanted) {
    if (!searchDoc) return false;
    const wantedN = normalizeText(wanted);
    if (!wantedN) return false;

    // 1) Prefer role="option"
    const opts = searchDoc.querySelectorAll('[role="option"]');
    for (let i = 0; i < opts.length; i++) {
      const el = opts[i];
      const txt = normalizeText(el.innerText || el.textContent || '');
      if (txt === wantedN) {
        try {
          el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          el.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } catch (_) {
          el.click();
        }
        return true;
      }
    }

    // 2) Prefer data-option-text blocks
    const optTexts = searchDoc.querySelectorAll('[data-option-text="true"]');
    for (let i = 0; i < optTexts.length; i++) {
      const el = optTexts[i];
      const txt = normalizeText(el.innerText || el.textContent || '');
      if (txt === wantedN) {
        const target = el.closest('[role="option"]') || el.closest('button') || el;
        try {
          target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
          target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
          target.dispatchEvent(new MouseEvent('click', { bubbles: true }));
        } catch (_) {
          target.click();
        }
        return true;
      }
    }

    // 3) Fallback: any element inside abstractdropdown-content-* that matches
    const dropdownRoots = searchDoc.querySelectorAll('[id^="abstractdropdown-content-"]');
    for (let r = 0; r < dropdownRoots.length; r++) {
      const root = dropdownRoots[r];
      const els = root.querySelectorAll('button,[role="option"],div,span');
      for (let i = 0; i < els.length; i++) {
        const el = els[i];
        const txt = normalizeText(el.innerText || el.textContent || '');
        if (txt === wantedN) {
          const target = el.closest('button') || el.closest('[role="option"]') || el;
          try {
            target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
            target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
            target.dispatchEvent(new MouseEvent('click', { bubbles: true }));
          } catch (_) {
            target.click();
          }
          return true;
        }
      }
    }

    return false;
  }

  function setDealTypeReactSelect(rootDoc, dealType) {
    if (!rootDoc || !dealType) return;
    const btn = rootDoc.querySelector('button[data-test-id="dealtype-input"]');
    if (!btn) return;

    const desired = String(dealType).trim();
    if (!desired) return;

    // Ya está seleccionado
    const current = getDealTypeLabel(rootDoc);
    if (current && current === normalizeText(desired)) return;

    // Abrir dropdown
    try {
      btn.click();
    } catch (_) {}

    // Las opciones pueden renderizarse en el iframe o en el documento padre.
    const docsToSearch = [rootDoc, document];

    let tries = 0;
    function tryPick() {
      tries += 1;
      for (let i = 0; i < docsToSearch.length; i++) {
        const ok = findAndClickOptionByText(docsToSearch[i], desired);
        if (ok) {
          return;
        }
      }
      if (tries < 8) requestAnimationFrame(tryPick);
    }
    requestAnimationFrame(tryPick);
  }

  function setReactSelectByTestId(rootDoc, testId, desiredLabel) {
    if (!rootDoc || !testId || !desiredLabel) return;
    const btn = rootDoc.querySelector(`button[data-test-id="${testId}"]`);
    if (!btn) return;

    const desired = String(desiredLabel).trim();
    if (!desired) return;

    const current = getReactSelectLabelByTestId(rootDoc, testId);
    if (current && current === normalizeText(desired)) return;

    try {
      btn.click();
    } catch (_) {}

    const docsToSearch = [rootDoc, document];
    let tries = 0;
    function tryPick() {
      tries += 1;
      for (let i = 0; i < docsToSearch.length; i++) {
        const ok = findAndClickOptionByText(docsToSearch[i], desired);
        if (ok) {
          return;
        }
      }
      if (tries < 10) requestAnimationFrame(tryPick);
    }
    requestAnimationFrame(tryPick);
  }

  function fillAssociationDomain(rootDoc, domain) {
    const d = normalizeAssociationQuery(domain);
    if (!rootDoc || !d) return;

    // Importante: evitar colisiones con otros selects. El selector de asociaciones incluye data-fnd-select-multi-value="t".
    const btn =
      rootDoc.querySelector('button[data-test-id="association-input-0-1-index-0"][data-fnd-select-multi-value="t"]')
      || rootDoc.querySelector('button[data-test-id="association-input-0-1-index-0"]');
    if (!btn) return;

    const ownsId = btn.getAttribute('aria-owns') || '';
    try {
      btn.click();
    } catch (_) {}

    let tries = 0;
    function tryFill() {
      tries += 1;
      const iframeContainer = ownsId ? rootDoc.getElementById(ownsId) : null;
      const topContainer = ownsId ? document.getElementById(ownsId) : null;
      const container = iframeContainer || topContainer || null;

      // Preferimos el input dentro del dropdown concreto del botón "Asociar registros"
      const input =
        (container && (
          container.querySelector('input[type="search"][role="combobox"]')
          || container.querySelector('input[role="combobox"][type="search"]')
          || container.querySelector('input[type="search"]')
          || container.querySelector('input[role="combobox"]')
        ))
        || rootDoc.querySelector('input[type="search"][role="combobox"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[role="combobox"][type="search"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[type="search"][placeholder="Buscar"]')
        || rootDoc.querySelector('input[role="combobox"][placeholder="Buscar"]');

      if (input) {
        try {
          input.focus?.();
        } catch (_) {}
        setNativeValue(input, d);
        // Ayuda a algunos React-select/typeahead que reaccionan a key events además de input/change.
        try {
          input.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a' }));
          input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a' }));
        } catch (_) {}
        return;
      }

      if (tries < 12) requestAnimationFrame(tryFill);
    }
    requestAnimationFrame(tryFill);
  }

  function fillDealFields(fields) {
    if (!fields || typeof fields !== 'object') return;

    const rootDoc = getObjectBuilderIframeDoc() || document;

    const dealNameEl = rootDoc.querySelector('textarea[data-test-id="dealname-input"], textarea[data-selenium-test="property-input-dealname"]');
    const amountEl = rootDoc.querySelector('input[data-test-id="amount-input"], input[data-selenium-test="property-input-amount"]');
    const closeDateEl = rootDoc.querySelector('div[data-test-id="closedate-input"] input, div[data-selenium-test="property-input-closedate"] input');

    const dealnameFinal = typeof fields.dealname_final === 'string' ? fields.dealname_final.trim() : '';
    if (dealNameEl && dealnameFinal) setNativeValue(dealNameEl, dealnameFinal);

    if (typeof fields.deal_type === 'string' && fields.deal_type.trim()) {
      setDealTypeReactSelect(rootDoc, fields.deal_type);
    }

    // Deal Source: forzar siempre "Account Management"
    setReactSelectByTestId(rootDoc, 'deal_source-input', 'Account Management');

    // Asociar registros: autocompletar dominio de la empresa (sin seleccionar nada)
    if (lastCompanyAssociationQueryForDeal) {
      fillAssociationDomain(rootDoc, lastCompanyAssociationQueryForDeal);
    }

    const amount = normalizeAmount(fields.valor);
    if (amountEl && amount) setNativeValue(amountEl, amount);

    const dateStr =
      (typeof fields.fecha_cierre === 'string' && fields.fecha_cierre.trim())
      ? fields.fecha_cierre.trim()
      : formatDateDDMMYYYY(addOneMonth(new Date()));
    if (closeDateEl && dateStr) setNativeValue(closeDateEl, dateStr);
  }

  globalThis.fillDealFields = fillDealFields;

  /**
   * Vista previa en página (mismo texto que el log del popup) si el ajuste lo permite.
   */
  function showFloatingLogPanel(data) {
    removeFloatingLogPanel();
    if (!data || typeof globalThis.AvvaleFormatLog !== 'function') return;

    const wrap = document.createElement('div');
    wrap.id = LOG_PANEL_ID;
    wrap.className = 'avvale-companion-log-panel';
    wrap.setAttribute('role', 'region');
    wrap.setAttribute('aria-label', 'Vista previa de datos recopilados');

    const header = document.createElement('div');
    header.className = 'avvale-companion-log-panel__header';
    const title = document.createElement('span');
    title.className = 'avvale-companion-log-panel__title';
    title.textContent = 'Datos recopilados';
    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'avvale-companion-log-panel__close';
    closeBtn.setAttribute('aria-label', 'Cerrar vista previa');
    closeBtn.textContent = '×';
    closeBtn.addEventListener('click', removeFloatingLogPanel);

    header.appendChild(title);
    header.appendChild(closeBtn);

    const pre = document.createElement('pre');
    pre.className = 'avvale-companion-log-panel__pre';
    pre.textContent = globalThis.AvvaleFormatLog(data);

    wrap.appendChild(header);
    wrap.appendChild(pre);
    document.documentElement.appendChild(wrap);
  }

  function showToast(message, isError) {
    let el = document.getElementById(TOAST_ID);
    if (!el) {
      el = document.createElement('div');
      el.id = TOAST_ID;
      el.className = 'avvale-companion-toast';
      el.setAttribute('role', 'status');
      document.documentElement.appendChild(el);
    }
    const escapeHtml = (s) =>
      String(s)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');

    if (typeof message === 'string' && message.startsWith('Recopilado.')) {
      const rest = message.slice('Recopilado.'.length);
      el.innerHTML = `<strong>Recopilado.</strong>${escapeHtml(rest)}`;
    } else {
      el.textContent = message;
    }
    el.classList.toggle('avvale-companion-toast--error', !!isError);

    // Posicionar el toast justo encima del botón Recopilar/Enviar (barra izquierda)
    const recopilarBtn = document.getElementById(BTN_ID);
    if (recopilarBtn) {
      const r = recopilarBtn.getBoundingClientRect();
      const gap = 10;
      el.style.left = `${Math.max(8, Math.round(r.left))}px`;
      el.style.right = 'auto';
      el.style.bottom = `${Math.max(8, Math.round(window.innerHeight - r.top + gap))}px`;
      el.style.maxWidth = `${Math.round(r.width)}px`;
    } else {
      // fallback a estilos por CSS (esquina inferior derecha)
      el.style.left = '';
      el.style.right = '';
      el.style.bottom = '';
      el.style.maxWidth = '';
    }

    clearTimeout(showToast._t);
    showToast._t = setTimeout(() => {
      el?.remove();
    }, 4500);
  }

  function ensureLeftBar() {
    if (!isRecordViewUrl(location.href)) return null;
    let bar = document.getElementById(LEFT_BAR_ID);
    if (bar) return bar;
    bar = document.createElement('div');
    bar.id = LEFT_BAR_ID;
    bar.className = 'avvale-companion-floating-bar-left';
    document.documentElement.appendChild(bar);
    return bar;
  }

  function ensureFromOfferTopButton() {
    if (!isRecordViewUrl(location.href)) return;
    let btn = document.getElementById(FROM_OFFER_ID);
    if (btn) return;
    btn = document.createElement('button');
    btn.id = FROM_OFFER_ID;
    btn.type = 'button';
    btn.className = 'avvale-companion-floating-btn avvale-companion-floating-btn--left avvale-companion-floating-btn--from-offer';
    btn.textContent = 'Desde oferta';
    btn.setAttribute('aria-label', 'Desde oferta');
    btn.addEventListener('click', () => {
      if (typeof globalThis.initPDFAnalyzer !== 'function') {
        showToast('Error interno: módulo PDF no cargado.', true);
        return;
      }
      try {
        globalThis.initPDFAnalyzer();
      } catch (e) {
        showToast(e.message || 'Error al abrir el analizador de PDF.', true);
      }
    });
    document.documentElement.appendChild(btn);
  }

  function findRightSidebarAddButton() {
    const sidebar = document.querySelector(RIGHT_SIDEBAR_SELECTOR) || document;

    // 1) Prefer: "Negocios" card wrapper (avoid Contactos/Empresas, etc.)
    const cardTitles = sidebar.querySelectorAll('[data-selenium-test="crm-card-title"], [data-test-id="crm-card-title"]');
    for (let i = 0; i < cardTitles.length; i++) {
      const t = cardTitles[i];
      const titleText = (t.innerText || t.textContent || '').trim().toLowerCase();
      if (!titleText.includes('negocios')) continue;

      const cardWrapper =
        t.closest('[data-test-id^="card-wrapper-"]')
        || t.closest('[data-test-id^="card-wrapper-"][id^="card-wrapper-"]')
        || t.closest('[id^="card-wrapper-"]')
        || t.closest('[data-test-id^="card-wrapper"]');

      if (!cardWrapper) continue;

      // Find "Agregar" button inside that card's header toolbar/actions
      const addBtn =
        cardWrapper.querySelector('button svg[data-icon-name="Add"]')?.closest('button')
        || cardWrapper.querySelector('button:has(svg[data-icon-name="Add"])');

      if (addBtn) {
        const btnText = (addBtn.innerText || addBtn.textContent || '').trim().toLowerCase();
        if (btnText.includes('agregar')) return addBtn;
      }
    }

    // 2) Fallback: exact markup: text container with Add icon + "Agregar"
    const textContainers = sidebar.querySelectorAll('span.PrivateButton__StyledButtonTextContainer-gKiNOa');
    for (let i = 0; i < textContainers.length; i++) {
      const c = textContainers[i];
      const hasAddIcon = !!c.querySelector('svg[data-icon-name="Add"]');
      if (!hasAddIcon) continue;
      const label = (c.querySelector('span')?.innerText || c.textContent || '').trim();
      if (!label.toLowerCase().includes('agregar')) continue;
      const btn = c.closest('button');
      if (btn) return btn;
    }

    // Fallback 1: any button with Add icon and "Agregar" text in right sidebar
    const candidates = sidebar.querySelectorAll('button');
    for (let i = 0; i < candidates.length; i++) {
      const b = candidates[i];
      const text = (b.innerText || b.textContent || '').trim();
      if (!text || !text.toLowerCase().includes('agregar')) continue;
      const hasAddIcon = !!b.querySelector('svg[data-icon-name="Add"]');
      if (hasAddIcon) return b;
    }

    // Fallback 2: data-attributes comunes en HubSpot
    return (
      (document.querySelector(`${RIGHT_SIDEBAR_SELECTOR} button[data-selenium-test="build-object-button"]`))
      || (document.querySelector(`${RIGHT_SIDEBAR_SELECTOR} button[data-test-id="build-object-button"]`))
      || null
    );
  }

  function ensureNewDealButton() {
    if (!isRecordViewUrl(location.href)) return;
    let btn = document.getElementById(NEWDEAL_ID);
    if (btn) return;

    const bar = ensureLeftBar();
    btn = document.createElement('button');
    btn.id = NEWDEAL_ID;
    btn.type = 'button';
    btn.className = 'avvale-companion-floating-btn';
    btn.textContent = 'Nuevo Deal';
    btn.setAttribute('aria-label', 'Nuevo Deal');
    btn.addEventListener('click', () => {
      ensureFromOfferTopButton();
      // Capturar dominio de la empresa (0-2) para usarlo luego en el builder (Asociar registros)
      lastCompanyAssociationQueryForDeal = getCompanyDomainFromHighlight();

      const addBtn = findRightSidebarAddButton();
      if (!addBtn) {
        showToast('No se encontró el botón “Agregar” en “Negocios”.', true);
        return;
      }
      try {
        addBtn.click();
        showToast('Abriendo creación…');
      } catch (e) {
        showToast(e.message || 'No se pudo hacer click en “Agregar”.', true);
      }
    });
    (bar || document.documentElement).appendChild(btn);
  }

  function setFloatingButtonMode(btn, mode) {
    if (!btn) return;
    const prev = btn.dataset.avvaleMode;
    if (prev === mode) return;
    btn.dataset.avvaleMode = mode;
    if (mode === 'enviar') {
      btn.textContent = 'Enviar activación';
      btn.setAttribute('aria-label', 'Enviar datos a activación en Avvale Companion');
      btn.classList.add(SECONDARY_CLASS);
    } else {
      btn.textContent = 'Recopilar';
      btn.setAttribute('aria-label', 'Recopilar datos para Avvale Companion');
      btn.classList.remove(SECONDARY_CLASS);
    }
  }

  function applyFloatingStateFromStorage(btn) {
    chrome.storage.local.get(
      { [STORAGE_KEY_LAST_RECOPILATED]: null },
      (data) => {
        if (!document.getElementById(BTN_ID)) return;
        const payload = data[STORAGE_KEY_LAST_RECOPILATED];
        if (
          payload
          && typeof payload === 'object'
          && payload.hubspotUrl
          && sameRecordPage(payload.hubspotUrl, location.href)
        ) {
          setFloatingButtonMode(btn, 'enviar');
        } else {
          setFloatingButtonMode(btn, 'recopilar');
          removeFloatingLogPanel();
        }
      }
    );
  }

  function onEnviarClick(btn) {
    if (!btn || btn.disabled) return;
    if (!globalThis.AvvaleActivation) {
      showToast('Error interno: módulo de activación no cargado.', true);
      return;
    }
    btn.disabled = true;
    chrome.storage.local.get(
      {
        [STORAGE_KEY_ACTIVATION_ENV]: 'pro',
        [STORAGE_KEY_LAST_RECOPILATED]: null,
      },
      (data) => {
        if (chrome.runtime.lastError) {
          btn.disabled = false;
          showToast(chrome.runtime.lastError.message || 'Error al leer datos.', true);
          return;
        }
        const payload = data[STORAGE_KEY_LAST_RECOPILATED];
        const env = data[STORAGE_KEY_ACTIVATION_ENV] === 'pro' ? 'pro' : 'dev';
        if (!payload || typeof payload !== 'object') {
          btn.disabled = false;
          showToast('No hay datos para enviar. Pulsa Recopilar.', true);
          setFloatingButtonMode(btn, 'recopilar');
          return;
        }
        if (!sameRecordPage(payload.hubspotUrl, location.href)) {
          btn.disabled = false;
          showToast('Los datos no corresponden a esta página. Recopila de nuevo.', true);
          setFloatingButtonMode(btn, 'recopilar');
          return;
        }
        let activationUrl;
        try {
          const base = globalThis.AvvaleActivation.getActivationBaseUrl(env);
          activationUrl = base + '#' + globalThis.AvvaleActivation.toBase64Url(payload);
        } catch (e) {
          btn.disabled = false;
          showToast(e.message || 'Error al preparar la URL.', true);
          return;
        }
        chrome.runtime.sendMessage(
          { type: 'OPEN_URL', url: activationUrl },
          (response) => {
            btn.disabled = false;
            if (chrome.runtime.lastError) {
              showToast(chrome.runtime.lastError.message || 'No se pudo abrir la pestaña.', true);
              return;
            }
            if (!response || !response.ok) {
              showToast((response && response.error) || 'No se pudo abrir la pestaña.', true);
              return;
            }
            showToast(`Pestaña abierta (${env === 'pro' ? 'PRO' : 'DEV'}).`);
          }
        );
      }
    );
  }

  function onRecopilarClick(btn) {
    if (!btn || btn.disabled) return;
    if (typeof globalThis.extractInPageAfterSidebarPrep !== 'function') {
      showToast('Error interno: no se pudo cargar la extracción.', true);
      return;
    }
    btn.disabled = true;
    showLoadingSpinner();
    globalThis
      .extractInPageAfterSidebarPrep()
      .then((data) => {
        hideLoadingSpinner();
        if (!data) {
          showToast('No se obtuvieron datos.', true);
          btn.disabled = false;
          return;
        }
        chrome.storage.local.set({ [STORAGE_KEY_LAST_RECOPILATED]: data }, () => {
          btn.disabled = false;
          if (chrome.runtime.lastError) {
            showToast(chrome.runtime.lastError.message || 'Error al guardar.', true);
            return;
          }
          chrome.storage.local.get(
            { [STORAGE_KEY_SHOW_LOG_PREVIEW]: true },
            (s) => {
              const showPreview = !!s[STORAGE_KEY_SHOW_LOG_PREVIEW];
              if (showPreview) {
                showFloatingLogPanel(data);
              } else {
                removeFloatingLogPanel();
                showToast('Recopilado. Pulsa Enviar activación.');
              }
              setFloatingButtonMode(btn, 'enviar');
            }
          );
        });
      })
      .catch((e) => {
        hideLoadingSpinner();
        btn.disabled = false;
        showToast(e.message || 'Error al recopilar.', true);
      });
  }

  function onFloatingButtonClick() {
    const btn = document.getElementById(BTN_ID);
    if (!btn || btn.disabled) return;
    if (btn.dataset.avvaleMode === 'enviar') {
      onEnviarClick(btn);
    } else {
      onRecopilarClick(btn);
    }
  }

  function ensureFloatingButton() {
    if (!isRecordViewUrl(location.href)) {
      removeFloatingButton();
      return;
    }

    if (isDealRecordUrl(location.href)) {
      // En Deals (0-3) ocultamos "Nuevo Deal" y "Desde oferta"; mantenemos Recopilar/Enviar.
      document.getElementById(NEWDEAL_ID)?.remove();
      document.getElementById(FROM_OFFER_ID)?.remove();
    }

    if (isCompanyRecordUrl(location.href)) {
      // En Empresas (0-2) ocultamos Recopilar/Enviar y limpiamos UI asociada.
      document.getElementById(BTN_ID)?.remove();
      removeFloatingLogPanel();
      removeToast();
      hideLoadingSpinner();

      ensureLeftBar();
      ensureNewDealButton();
      document.getElementById(PDF_ID)?.remove();
      return;
    }

    ensureLeftBar();
    document.getElementById(PDF_ID)?.remove();
    // Orden visual en la barra izquierda: primero "Nuevo Deal", luego "Recopilar/Enviar"
    if (!isDealRecordUrl(location.href)) ensureNewDealButton();
    let btn = document.getElementById(BTN_ID);
    if (!btn) {
      btn = document.createElement('button');
      btn.id = BTN_ID;
      btn.type = 'button';
      btn.className = 'avvale-companion-floating-btn';
      btn.dataset.avvaleMode = 'recopilar';
      btn.textContent = 'Recopilar';
      btn.setAttribute('aria-label', 'Recopilar datos para Avvale Companion');
      btn.addEventListener('click', onFloatingButtonClick);
      const bar = document.getElementById(LEFT_BAR_ID);
      (bar || document.documentElement).appendChild(btn);
    }
    applyFloatingStateFromStorage(btn);
  }

  /** Fecha tipo "16 de mar. de 2026" (mes abreviado ES). */
  function parseHubSpotEsDateLabel(raw) {
    const t = String(raw || '')
      .replace(/\u200b/g, '')
      .replace(/\s+/g, ' ')
      .trim();
    if (!t) return null;
    const re = /^(\d{1,2})\s+de\s+([a-záéíóúñ.]+)\s+de\s+(\d{4})$/i;
    const m = t.match(re);
    if (!m) return null;
    const day = parseInt(m[1], 10);
    const year = parseInt(m[3], 10);
    const monRaw = m[2].toLowerCase().replace(/\./g, '');
    const monKey = monRaw.length >= 3 ? monRaw.slice(0, 3) : monRaw;
    const monthMap = {
      ene: 0,
      feb: 1,
      mar: 2,
      abr: 3,
      may: 4,
      jun: 5,
      jul: 6,
      ago: 7,
      sep: 8,
      oct: 9,
      nov: 10,
      dic: 11,
    };
    const monthIdx = monthMap[monKey];
    if (monthIdx === undefined || day < 1 || day > 31 || year < 1900) return null;
    const d = new Date(year, monthIdx, day);
    if (d.getFullYear() !== year || d.getMonth() !== monthIdx || d.getDate() !== day) return null;
    return d;
  }

  /** Primer día del mes siguiente al de projectStart + countOfSchedule meses. */
  function computeGoLiveFromProjectStartAndCount(projectStartDate, countOfScheduleMonths) {
    const y = projectStartDate.getFullYear();
    const m = projectStartDate.getMonth();
    const base = new Date(y, m + 1, 1);
    const out = new Date(base.getTime());
    out.setMonth(out.getMonth() + countOfScheduleMonths);
    return out;
  }

  /** Mismo mes/año que Go live, día 30 o el último día del mes si hay menos de 30 días. */
  function computeContractEndFromGoLive(goLiveDate) {
    const y = goLiveDate.getFullYear();
    const m = goLiveDate.getMonth();
    const daysInMonth = new Date(y, m + 1, 0).getDate();
    const day = Math.min(30, daysInMonth);
    return new Date(y, m, day);
  }

  function readTruncatedCellLabel(td) {
    if (!td) return '';
    const inner =
      td.querySelector('[data-test-id="truncated-object-label"] span')
      || td.querySelector('[data-test-id="truncated-object-label"]');
    return (inner && (inner.textContent || '')).trim();
  }

  function findProjectStartCellInRow(row) {
    if (!row) return null;
    return (
      row.querySelector(`td[data-table-external-id*="project_start"]`)
      || row.querySelector('td[data-table-external-id*="start_date"]')
      || row.querySelector('td[data-table-external-id*="project_start_date"]')
    );
  }

  function findContractEndCellInRow(row) {
    if (!row) return null;
    return (
      row.querySelector('td[data-table-external-id*="contract_end"]')
      || row.querySelector('td[data-table-external-id*="contract_end_date"]')
    );
  }

  function rowHasGoliveCell(row) {
    return !!(row && row.querySelector(`td[data-table-external-id^="${HS_CELL_GOLIVE_PREFIX}"]`));
  }

  /** Todas las filas de negocio con checkbox (o fila) seleccionados. */
  function getSelectedDealTableRows() {
    const rows = [];
    const seen = new Set();

    function addRow(row) {
      if (!row || seen.has(row)) return;
      if (!rowHasGoliveCell(row)) return;
      seen.add(row);
      rows.push(row);
    }

    const checks = document.querySelectorAll(
      'tbody tr input[type="checkbox"]:checked, [role="rowgroup"] tr input[type="checkbox"]:checked, [role="row"] input[type="checkbox"]:checked',
    );
    for (let i = 0; i < checks.length; i += 1) {
      addRow(checks[i].closest('tr') || checks[i].closest('[role="row"]'));
    }
    const fallbackChecks = document.querySelectorAll('table tr input[type="checkbox"]:checked');
    for (let j = 0; j < fallbackChecks.length; j += 1) {
      const row = fallbackChecks[j].closest('tr');
      if (row && !row.closest('thead')) addRow(row);
    }
    if (rows.length === 0) {
      const ariaSel =
        document.querySelector('tbody tr[aria-selected="true"]')
        || document.querySelector('tr[aria-selected="true"]')
        || document.querySelector('[role="row"][aria-selected="true"]');
      if (ariaSel) addRow(ariaSel.closest('tr') || ariaSel);
    }
    return rows;
  }

  function waitMs(ms) {
    return new Promise((resolve) => {
      setTimeout(resolve, ms);
    });
  }

  /** Abre una celda de fecha en tabla (Go live, contract end, …) y escribe DD/MM/YYYY. */
  async function fillHubSpotTableDateCell(dateCellTd, valueDdMmYyyy) {
    if (!dateCellTd) return false;
    const activator = dateCellTd.querySelector('[data-editable-cell="true"]')
      || dateCellTd.querySelector('[role="button"]')
      || dateCellTd;
    try {
      activator.click();
    } catch (_) {
      dateCellTd.click();
    }
    await waitMs(80);

    let input = null;
    for (let attempt = 0; attempt < 28; attempt += 1) {
      input =
        dateCellTd.querySelector('[data-test-id="date-input"] input[type="text"]')
        || dateCellTd.querySelector('input[data-format="DD/MM/YYYY"]')
        || dateCellTd.querySelector('input[placeholder*="DD/MM"]')
        || dateCellTd.querySelector('input:not([type="hidden"]):not([type="checkbox"])')
        || dateCellTd.querySelector('textarea');
      if (input && input.offsetParent !== null) break;

      const focused = document.activeElement;
      if (
        focused
        && (focused.tagName === 'INPUT' || focused.tagName === 'TEXTAREA')
        && focused.type !== 'checkbox'
      ) {
        input = focused;
        break;
      }

      const portalInput = document.querySelector(
        '[data-floating-ui-portal] input[type="text"], [data-floating-ui-portal] input:not([type="hidden"])',
      );
      if (portalInput) {
        input = portalInput;
        break;
      }
      const dialogInput = document.querySelector('[role="dialog"] input[type="text"], [role="presentation"] input[type="text"]');
      if (dialogInput && attempt > 2) {
        input = dialogInput;
        break;
      }

      await waitMs(55);
    }

    if (!input) return false;

    setNativeValue(input, valueDdMmYyyy);
    try {
      input.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true }));
    } catch (_) {}
    try {
      input.blur();
    } catch (_) {}
    await waitMs(100);
    return true;
  }

  async function fillGoliveDateInCell(goliveTd, valueDdMmYyyy) {
    return fillHubSpotTableDateCell(goliveTd, valueDdMmYyyy);
  }

  async function onPreviewFillClick() {
    const fillBtn = document.getElementById(PREVIEW_FILL_BTN_ID);
    if (fillBtn) fillBtn.disabled = true;

    try {
      const rows = getSelectedDealTableRows();
      if (rows.length === 0) {
        showToast('Selecciona una o más filas en la tabla.', true);
        return;
      }

      let ok = 0;
      let fail = 0;
      const errors = [];

      for (let r = 0; r < rows.length; r += 1) {
        const row = rows[r];
        const label = `Fila ${r + 1}`;
        const projectTd = findProjectStartCellInRow(row);
        const countTd = row.querySelector(`td[data-table-external-id^="${HS_CELL_COUNT_SCHEDULE_PREFIX}"]`);
        const goliveTd = row.querySelector(`td[data-table-external-id^="${HS_CELL_GOLIVE_PREFIX}"]`);

        if (!projectTd || !countTd || !goliveTd) {
          fail += 1;
          errors.push(`${label}: faltan celdas requeridas`);
          continue;
        }

        const startRaw = readTruncatedCellLabel(projectTd);
        const projectStart = parseHubSpotEsDateLabel(startRaw);
        if (!projectStart) {
          fail += 1;
          errors.push(`${label}: fecha inicio no válida ("${startRaw}")`);
          continue;
        }

        const countRaw = readTruncatedCellLabel(countTd);
        const countNum = parseInt(String(countRaw).replace(/[^\d-]/g, ''), 10);
        if (!Number.isFinite(countNum) || countNum < 0) {
          fail += 1;
          errors.push(`${label}: count of schedule no válido ("${countRaw}")`);
          continue;
        }

        const goLive = computeGoLiveFromProjectStartAndCount(projectStart, countNum);
        const formattedGolive = formatDateDDMMYYYY(goLive);

        const goliveOk = await fillGoliveDateInCell(goliveTd, formattedGolive);
        if (!goliveOk) {
          fail += 1;
          errors.push(`${label}: no se pudo abrir el editor de Go live`);
          continue;
        }

        const contractTd = findContractEndCellInRow(row);
        if (contractTd) {
          const contractEnd = computeContractEndFromGoLive(goLive);
          const formattedContract = formatDateDDMMYYYY(contractEnd);
          const contractOk = await fillHubSpotTableDateCell(contractTd, formattedContract);
          if (!contractOk) {
            fail += 1;
            errors.push(`${label}: Go live OK; contract end no editado`);
            continue;
          }
        }

        ok += 1;
      }

      if (ok > 0 && fail === 0) {
        showToast(`Completado: ${ok} fila(s) (Go live + contract end).`);
      } else if (ok > 0 && fail > 0) {
        showToast(
          `${ok} fila(s) OK, ${fail} error(es). ${errors.slice(0, 3).join(' · ')}`,
          true,
        );
      } else {
        showToast(errors.length ? errors.slice(0, 4).join(' · ') : 'No se pudo rellenar Go live.', true);
      }
    } finally {
      if (fillBtn) fillBtn.disabled = false;
    }
  }

  /** Botón flotante naranja Fill (vista lista deals 0-3). */
  function ensurePreviewFillButton() {
    if (!isDealObjectsTableUrl(location.href)) {
      document.getElementById(FILL_FLOAT_WRAP_ID)?.remove();
      return;
    }
    if (document.getElementById(FILL_FLOAT_WRAP_ID) && document.getElementById(PREVIEW_FILL_BTN_ID)) {
      return;
    }
    document.getElementById(FILL_FLOAT_WRAP_ID)?.remove();

    const wrap = document.createElement('div');
    wrap.id = FILL_FLOAT_WRAP_ID;
    wrap.className = 'avvale-companion-floating-fill-wrap';

    const fill = document.createElement('button');
    fill.id = PREVIEW_FILL_BTN_ID;
    fill.type = 'button';
    fill.className = 'avvale-companion-floating-btn';
    fill.textContent = 'Fill';
    fill.setAttribute('aria-label', 'Rellenar Go live en las filas seleccionadas');
    fill.setAttribute('data-test-id', 'avvale-companion-fill-button');

    fill.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      void onPreviewFillClick();
    });

    wrap.appendChild(fill);
    document.documentElement.appendChild(wrap);
  }

  function sync() {
    ensureFloatingButton();
    ensurePmEmailSuggestOnDeal();
    ensurePreviewFillButton();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes[STORAGE_KEY_SHOW_LOG_PREVIEW]) return;
    if (changes[STORAGE_KEY_SHOW_LOG_PREVIEW].newValue === false) {
      removeFloatingLogPanel();
    }
  });

  sync();
  setInterval(sync, 800);
  window.addEventListener('popstate', sync);
})();
