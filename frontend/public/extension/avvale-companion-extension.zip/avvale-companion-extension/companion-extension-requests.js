/**
 * Puente Companion ↔ extensión (schemaVersion 1): descargas temporales sin carpeta Descargas.
 * Contrato: docs/BROWSER_EXTENSION_BRIDGE.md
 *
 * La SPA dispara `avvale-extension-request` (burbujea; composed: true si sale de shadow DOM).
 * Respondemos con `avvale-extension-response` en document (bubbles + composed).
 * GET_TEMP_FILES: el SW rellena data.files[].dataBase64 (no solo ArrayBuffer: MV3 puede vaciar buffers en detail hacia la página).
 * Listener en document[capture] (contrato: eventos en document; composed permite shadow DOM).
 *
 * No modificar: avvale-companion-ping / avvale-companion-pong (companion-yubiq-bridge.js).
 */
(function () {
  'use strict';

  var REQ = 'avvale-extension-request';
  var RES = 'avvale-extension-response';
  var MSG = 'COMPANION_EXTENSION_REQUEST';
  var LOG_PREFIX = '[AvvaleExtension]';
  var ALLOWED = {
    DOWNLOAD_FILES: true,
    GET_TEMP_FILES: true,
    CLEAR_TEMP_FILES: true,
  };

  function isDevBridgeLog() {
    try {
      if (/^(localhost|127\.0\.0\.1)$/.test(location.hostname)) return true;
      if (localStorage.getItem('avvale-extension-debug') === '1') return true;
    } catch (err) {}
    return false;
  }

  function logDev(message, data) {
    if (!isDevBridgeLog()) return;
    if (data !== undefined) {
      console.log(LOG_PREFIX, message, data);
    } else {
      console.log(LOG_PREFIX, message);
    }
  }

  function dispatchRes(d) {
    document.dispatchEvent(
      new CustomEvent(RES, {
        bubbles: true,
        composed: true,
        detail: d,
      }),
    );
  }

  function bridgeHandler(e) {
    var detail = e && e.detail;
    if (!detail || typeof detail !== 'object') {
      dispatchRes({
        schemaVersion: 1,
        requestId: '',
        source: 'avvale-companion-extension',
        type: 'DOWNLOAD_FILES',
        ok: false,
        error: 'invalid_payload',
      });
      return;
    }

    if (detail.schemaVersion !== 1 || detail.source !== 'avvale-companion-web') {
      dispatchRes({
        schemaVersion: 1,
        requestId: typeof detail.requestId === 'string' ? detail.requestId : '',
        source: 'avvale-companion-extension',
        type: typeof detail.type === 'string' ? detail.type : 'DOWNLOAD_FILES',
        ok: false,
        error: 'invalid_payload',
      });
      return;
    }

    if (typeof detail.requestId !== 'string' || !detail.requestId) {
      dispatchRes({
        schemaVersion: 1,
        requestId: '',
        source: 'avvale-companion-extension',
        type: typeof detail.type === 'string' ? detail.type : 'DOWNLOAD_FILES',
        ok: false,
        error: 'invalid_payload',
      });
      return;
    }

    if (typeof detail.type !== 'string' || !ALLOWED[detail.type]) {
      dispatchRes({
        schemaVersion: 1,
        requestId: detail.requestId,
        source: 'avvale-companion-extension',
        type: typeof detail.type === 'string' ? detail.type : 'DOWNLOAD_FILES',
        ok: false,
        error: 'invalid_payload',
      });
      return;
    }

    logDev('request', { requestId: detail.requestId, type: detail.type });

    chrome.runtime.sendMessage(
      {
        type: MSG,
        request: {
          schemaVersion: detail.schemaVersion,
          requestId: detail.requestId,
          source: detail.source,
          type: detail.type,
          payload: detail.payload,
        },
      },
      function (resp) {
        if (chrome.runtime.lastError) {
          logDev('sendMessage error', chrome.runtime.lastError.message);
          dispatchRes({
            schemaVersion: 1,
            requestId: detail.requestId,
            source: 'avvale-companion-extension',
            type: detail.type,
            ok: false,
            error: 'unknown',
          });
          return;
        }
        if (resp && typeof resp === 'object') {
          logDev('response', {
            requestId: resp.requestId,
            type: resp.type,
            ok: resp.ok,
            error: resp.error,
          });
          dispatchRes(resp);
        } else {
          dispatchRes({
            schemaVersion: 1,
            requestId: detail.requestId,
            source: 'avvale-companion-extension',
            type: detail.type,
            ok: false,
            error: 'unknown',
          });
        }
      },
    );
  }

  document.addEventListener(REQ, bridgeHandler, true);
})();
