/**
 * Lotes temporales descargados por la extensión (IndexedDB en el service worker).
 * Cargado con importScripts desde background.js — sin módulos ES.
 */
(function (global) {
  'use strict';

  var DB_NAME = 'avvaleCompanionTempFiles';
  var DB_VERSION = 1;
  var STORE = 'batches';

  function openDb() {
    return new Promise(function (resolve, reject) {
      var req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onerror = function () {
        reject(req.error);
      };
      req.onsuccess = function () {
        resolve(req.result);
      };
      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'batchId' });
        }
      };
    });
  }

  /**
   * @param {string} batchId
   * @param {Array<{ originalUrl: string, name: string, mimeType: string, arrayBuffer: ArrayBuffer }>} files
   * @returns {Promise<void>}
   */
  function tempFilesPutBatch(batchId, files) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        tx.oncomplete = function () {
          resolve();
        };
        tx.onerror = function () {
          reject(tx.error);
        };
        tx.objectStore(STORE).put({
          batchId: batchId,
          files: files,
          updatedAt: Date.now(),
        });
      });
    });
  }

  /**
   * @param {string} batchId
   * @returns {Promise<{ batchId: string, files: Array, updatedAt: number } | null>}
   */
  function tempFilesGetBatch(batchId) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readonly');
        var req = tx.objectStore(STORE).get(batchId);
        req.onsuccess = function () {
          resolve(req.result || null);
        };
        req.onerror = function () {
          reject(req.error);
        };
      });
    });
  }

  /**
   * @param {string} batchId
   * @returns {Promise<boolean>} true si el lote existía
   */
  function tempFilesDeleteBatch(batchId) {
    return openDb().then(function (db) {
      return new Promise(function (resolve, reject) {
        var tx = db.transaction(STORE, 'readwrite');
        var store = tx.objectStore(STORE);
        var getReq = store.get(batchId);
        getReq.onsuccess = function () {
          var had = !!getReq.result;
          var delReq = store.delete(batchId);
          delReq.onsuccess = function () {
            resolve(had);
          };
          delReq.onerror = function () {
            reject(delReq.error);
          };
        };
        getReq.onerror = function () {
          reject(getReq.error);
        };
      });
    });
  }

  global.tempFilesPutBatch = tempFilesPutBatch;
  global.tempFilesGetBatch = tempFilesGetBatch;
  global.tempFilesDeleteBatch = tempFilesDeleteBatch;
})(typeof self !== 'undefined' ? self : this);
