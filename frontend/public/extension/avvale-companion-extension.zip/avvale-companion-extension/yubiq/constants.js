/**
 * Yubiq autofill — constantes compartidas (sin dependencias HubSpot).
 */
(function () {
  'use strict';

  globalThis.AvvaleYubiqConstants = {
    LOG_PREFIX: '[Yubiq Autofill]',
    TARGET_YUBIQ_ADDNEW: 'yubiq_addnew',
    DEFAULT_TARGET_URL: 'https://avvale-aes-y5ui.yubiq.app/YUBIK/home#addnew',
    STORAGE_PENDING: 'yubiqPendingAutofill',
    STORAGE_LAST_RESULT: 'yubiqAutofillLastResult',
    /** Select2: ids del <select> nativo (según aria-controls del buscador). */
    SELECT2_IDS: {
      documentType: 'qr_TipoDocumento',
      company: 'qr_CFG_SOCIETA',
      segment: 'qr_CFG_SEGMENTO',
    },
  };
})();
