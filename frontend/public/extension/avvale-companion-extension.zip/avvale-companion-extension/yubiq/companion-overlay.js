/**
 * Overlay a pantalla completa durante el autofill Yubiq (entrada desde abajo, salida hacia abajo).
 */
(function () {
  'use strict';

  let overlayEl = null;
  const DURATION_IN_MS = 520;
  const DURATION_OUT_MS = 420;
  const STYLE_ID = 'avvale-companion-overlay-styles';
  const STATUS_INTERVAL_MS = 2200;
  const TERMINATING_PAUSE_MS = 600;

  /** Sin "Terminando": esa fase solo al cerrar. */
  const STATUS_MESSAGES = [
    'Conectando con Yubiq…',
    'Recibiendo información del Companion…',
    'Validando datos…',
    'Preparando el formulario…',
    'Rellenando formulario…',
    'Aplicando valores en pantalla…',
    'Sincronizando desplegables…',
    'Procesando campos adicionales…',
    'Casi listo…',
  ];

  function logoSrc() {
    try {
      if (typeof location !== 'undefined' && location.origin && /^https?:/i.test(location.origin)) {
        return `${location.origin}/YUBIK/css/img/avvale-logo-header.png`;
      }
    } catch (_) {}
    return 'https://avvale-aes-y5ui.yubiq.app/YUBIK/css/img/avvale-logo-header.png';
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function ensureOverlayStyles() {
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement('style');
    s.id = STYLE_ID;
    s.textContent = [
      '@keyframes avvaleCompanionSpin { to { transform: rotate(360deg); } }',
      '@keyframes avvaleCompanionFadeIn { from { opacity: 0; transform: translateY(12px); } to { opacity: 1; transform: translateY(0); } }',
      '@keyframes avvaleCompanionPulse { 0%, 100% { opacity: 0.55; } 50% { opacity: 1; } }',
      '.CompanionOverlay__inner {',
      '  display: flex;',
      '  flex-direction: column;',
      '  align-items: center;',
      '  justify-content: center;',
      '  gap: 18px;',
      '  padding: 32px;',
      '  text-align: center;',
      '  max-width: 92vw;',
      '  animation: avvaleCompanionFadeIn 0.45s ease-out 0.15s both;',
      '}',
      '.CompanionOverlay__logo {',
      '  display: block;',
      '  height: 36px;',
      '  width: auto;',
      '  max-width: min(240px, 85vw);',
      '  object-fit: contain;',
      '  opacity: 0.92;',
      '  filter: brightness(1.08);',
      '  user-select: none;',
      '  pointer-events: none;',
      '}',
      '.CompanionOverlay__spinner {',
      '  width: 48px;',
      '  height: 48px;',
      '  border: 3px solid rgba(255,255,255,0.12);',
      '  border-top-color: rgba(255,255,255,0.92);',
      '  border-radius: 50%;',
      '  animation: avvaleCompanionSpin 0.9s linear infinite;',
      '  flex-shrink: 0;',
      '}',
      '.CompanionOverlay__title {',
      '  margin: 0;',
      '  font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;',
      '  font-size: 17px;',
      '  font-weight: 600;',
      '  letter-spacing: 0.02em;',
      '  color: rgba(255,255,255,0.96);',
      '}',
      '.CompanionOverlay__hint {',
      '  margin: 0;',
      '  min-height: 1.35em;',
      '  font-family: system-ui, -apple-system, Segoe UI, Roboto, sans-serif;',
      '  font-size: 13px;',
      '  font-weight: 400;',
      '  color: rgba(255,255,255,0.55);',
      '  transition: opacity 0.25s ease;',
      '  animation: avvaleCompanionPulse 2.2s ease-in-out infinite;',
      '}',
    ].join('\n');
    document.head.appendChild(s);
  }

  function clearStatusRotation(el) {
    if (el && el._companionStatusTimer != null) {
      clearInterval(el._companionStatusTimer);
      el._companionStatusTimer = null;
    }
  }

  function startStatusRotation(hintEl) {
    let i = 0;
    hintEl.textContent = STATUS_MESSAGES[0];
    return setInterval(() => {
      i = (i + 1) % STATUS_MESSAGES.length;
      hintEl.textContent = STATUS_MESSAGES[i];
    }, STATUS_INTERVAL_MS);
  }

  function buildInner() {
    const inner = document.createElement('div');
    inner.className = 'CompanionOverlay__inner';

    const logo = document.createElement('img');
    logo.className = 'CompanionOverlay__logo';
    logo.src = logoSrc();
    logo.alt = '';
    logo.decoding = 'async';
    logo.draggable = false;

    const spinner = document.createElement('div');
    spinner.className = 'CompanionOverlay__spinner';
    spinner.setAttribute('aria-hidden', 'true');

    const title = document.createElement('p');
    title.className = 'CompanionOverlay__title';
    title.textContent = 'Avvale Companion Worker';

    const hint = document.createElement('p');
    hint.className = 'CompanionOverlay__hint';
    hint.setAttribute('aria-live', 'polite');

    inner.appendChild(logo);
    inner.appendChild(spinner);
    inner.appendChild(title);
    inner.appendChild(hint);

    return { inner, hint };
  }

  function showCompanionOverlay() {
    if (overlayEl && overlayEl.isConnected) return;

    ensureOverlayStyles();

    const el = document.createElement('div');
    el.className = 'CompanionOverlay CompanionOvelay';
    el.setAttribute('aria-hidden', 'true');
    el.setAttribute('aria-busy', 'true');
    el.style.cssText = [
      'display:flex',
      'align-items:center',
      'justify-content:center',
      'position:fixed',
      'top:0',
      'left:0',
      'bottom:0',
      'right:0',
      'background:#1c2d3e',
      'z-index:9999999999',
      'transform:translateY(100%)',
      'will-change:transform',
      'transition:transform ' + DURATION_IN_MS + 'ms cubic-bezier(0.22,1,0.36,1)',
      'pointer-events:auto',
    ].join(';');

    const { inner, hint } = buildInner();
    el.appendChild(inner);
    el._companionHintEl = hint;

    document.body.appendChild(el);
    overlayEl = el;

    el._companionStatusTimer = startStatusRotation(hint);

    void el.offsetHeight;
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (overlayEl === el) {
          el.style.transform = 'translateY(0)';
        }
      });
    });
  }

  function hideCompanionOverlay() {
    return (async () => {
      const el = overlayEl;
      if (!el || !el.isConnected) {
        overlayEl = null;
        return;
      }

      clearStatusRotation(el);

      const hint = el._companionHintEl || el.querySelector('.CompanionOverlay__hint');
      if (hint) {
        hint.style.animation = 'none';
        hint.style.color = 'rgba(255,255,255,0.75)';
        hint.textContent = 'Terminando…';
      }

      el.removeAttribute('aria-busy');

      await sleep(TERMINATING_PAUSE_MS);

      await new Promise((resolve) => {
        if (!el.isConnected) {
          overlayEl = null;
          resolve();
          return;
        }

        const finish = () => {
          if (el.isConnected) el.remove();
          if (overlayEl === el) overlayEl = null;
          el.style.willChange = '';
          resolve();
        };

        const onTransitionEnd = (e) => {
          if (e.propertyName !== 'transform') return;
          el.removeEventListener('transitionend', onTransitionEnd);
          finish();
        };

        el.addEventListener('transitionend', onTransitionEnd);
        el.style.willChange = 'transform';
        el.style.transition = 'transform ' + DURATION_OUT_MS + 'ms cubic-bezier(0.55,0.085,0.68,0.53)';
        el.style.transform = 'translateY(100%)';

        setTimeout(() => {
          el.removeEventListener('transitionend', onTransitionEnd);
          if (overlayEl === el && el.isConnected) finish();
        }, DURATION_OUT_MS + 150);
      });
    })();
  }

  globalThis.AvvaleCompanionOverlay = {
    showCompanionOverlay,
    hideCompanionOverlay,
  };
})();
