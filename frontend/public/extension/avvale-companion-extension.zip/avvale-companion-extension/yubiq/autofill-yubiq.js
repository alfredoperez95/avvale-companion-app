/**
 * Yubiq — Rellenar formulario desde payload.prefill (errores por campo).
 */
(function () {
  'use strict';

  const D = globalThis.AvvaleYubiqDom;
  const S2 = globalThis.AvvaleYubiqSelect2;
  const C = globalThis.AvvaleYubiqConstants;

  /** Document Type en Yubiq: el filtro Select2 espera el texto en inglés (p. ej. "Offer"). */
  const DOC_TYPE_SEARCH_TEXT = {
    offer: 'Offer',
    contract: 'Contrato',
    proposal: 'Propuesta',
    order: 'Pedido',
  };
  const COMPANY_SEARCH_TEXT = {
    espana: 'Espana',
    italia: 'Italia',
    france: 'Francia',
    germany: 'Alemania',
  };

  function searchTextForDocumentType(code) {
    const k = String(code ?? '').trim().toLowerCase();
    return DOC_TYPE_SEARCH_TEXT[k] || String(code ?? '').trim();
  }

  function searchTextForCompany(code) {
    const k = String(code ?? '').trim().toLowerCase();
    return COMPANY_SEARCH_TEXT[k] || String(code ?? '').trim();
  }

  function pushResult(results, field, ok, error) {
    results.push({ field, ok, ...(error ? { error: String(error) } : {}) });
  }

  /** Misma regla que background.js (validateYubiqPayload). */
  function isValidManualMargin(m) {
    return typeof m === 'number' && Number.isInteger(m) && m >= 0 && m <= 100;
  }

  const PREFILL_ACTORS_BUTTON_TEXT = 'Prefill actors';

  function findPrefillActorsButton() {
    const candidates = document.querySelectorAll('button.btn.btn-primary.float-end');
    for (let i = candidates.length - 1; i >= 0; i--) {
      const b = candidates[i];
      if (b.textContent.trim() !== PREFILL_ACTORS_BUTTON_TEXT) continue;
      if (D.isLayoutVisible(b)) return b;
    }
    for (let i = candidates.length - 1; i >= 0; i--) {
      const b = candidates[i];
      if (b.textContent.trim() === PREFILL_ACTORS_BUTTON_TEXT) return b;
    }
    return null;
  }

  async function clickPrefillActorsAfterMargin(results) {
    try {
      await D.sleep(150);
      const btn = findPrefillActorsButton();
      if (!btn) {
        pushResult(results, 'prefillActors', false, 'botón Prefill actors no encontrado');
        return;
      }
      if (typeof btn.focus === 'function') btn.focus();
      btn.click();
      pushResult(results, 'prefillActors', true);
    } catch (e) {
      pushResult(results, 'prefillActors', false, e?.message || 'error');
    }
  }

  async function fillInputField(results, selector, value, fieldName) {
    try {
      const el = D.querySelectorPreferVisible(selector);
      if (!el) {
        pushResult(results, fieldName, false, `no encontrado: ${selector}`);
        return;
      }
      if (typeof el.focus === 'function') el.focus();
      D.setNativeValue(el, value);
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      D.blurElement(el);
      pushResult(results, fieldName, true);
    } catch (e) {
      pushResult(results, fieldName, false, e?.message || 'error');
    }
  }

  async function fillTextareaField(results, selector, value, fieldName) {
    try {
      const el = D.querySelectorPreferVisible(selector);
      if (!el) {
        pushResult(results, fieldName, false, `no encontrado: ${selector}`);
        return;
      }
      if (typeof el.focus === 'function') el.focus();
      D.setNativeValue(el, value);
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      pushResult(results, fieldName, true);
    } catch (e) {
      pushResult(results, fieldName, false, e?.message || 'error');
    }
  }

  /**
   * @param {object} payload - objeto completo (schema Yubiq)
   * @returns {Promise<{ results: object[] }>}
   */
  async function autofillYubiqForm(payload) {
    const results = [];
    const pre = payload && payload.prefill && typeof payload.prefill === 'object' ? payload.prefill : {};
    const ids = C.SELECT2_IDS;

    await fillInputField(results, '#qr_TITLE', String(pre.title ?? ''), 'title');
    await fillTextareaField(results, '#qr_DESCRIPTION', String(pre.description ?? ''), 'description');

    const due = D.resolveToBeSignedDate(pre);
    await fillInputField(results, '#customdisplay_qr_AESDUEDATE', due.valueDisplay, 'toBeSignedDisplay');
    await fillInputField(results, '#qr_AESDUEDATE', due.valueHidden, 'toBeSignedHidden');

    const docType = String(pre.documentType ?? 'offer').trim() || 'offer';
    const docTypeSearch = searchTextForDocumentType(docType);
    try {
      const r = await S2.openSelect2AndSearch({
        selectId: ids.documentType,
        ariaControlsContains: 'qr_TipoDocumento',
        text: docTypeSearch,
        fieldLabel: 'documentType',
        nativeSelectName: 'qr_TipoDocumento',
      });
      pushResult(results, 'documentType', r.ok, r.ok ? undefined : r.error);
    } catch (e) {
      pushResult(results, 'documentType', false, e?.message || 'error');
    }

    await fillInputField(results, '#qr_CUSTOMER_NAME', String(pre.customerName ?? ''), 'customerName');

    const company = String(pre.company ?? 'espana').trim() || 'espana';
    const companySearch = searchTextForCompany(company);
    try {
      const r = await S2.openSelect2AndSearch({
        selectId: ids.company,
        ariaControlsContains: 'qr_CFG_SOCIETA',
        text: companySearch,
        fieldLabel: 'company',
        nativeSelectName: 'qr_CFG_SOCIETA',
      });
      pushResult(results, 'company', r.ok, r.ok ? undefined : r.error);
    } catch (e) {
      pushResult(results, 'company', false, e?.message || 'error');
    }

    const segment = String(pre.segment ?? '').trim();
    if (segment) {
      try {
        const r = await S2.openSelect2AndSearch({
          selectId: ids.segment,
          ariaControlsContains: 'qr_CFG_SEGMENTO',
          text: segment,
          fieldLabel: 'segment',
          nativeSelectName: 'qr_CFG_SEGMENTO',
        });
        pushResult(results, 'segment', r.ok, r.ok ? undefined : r.error);
      } catch (e) {
        pushResult(results, 'segment', false, e?.message || 'error');
      }
    } else {
      D.log('[segment] vacío — no se rellena el desplegable (revisión manual en Companion)');
      results.push({
        field: 'segment',
        ok: true,
        skipped: true,
        reason: 'segment vacío — revisión manual (payload Companion)',
      });
    }

    await fillInputField(results, '#qr_IMPORTO_OFFERTA', String(pre.revenue ?? ''), 'revenue');

    if (isValidManualMargin(payload.manualMargin)) {
      await fillInputField(results, '#qr_CFG_REVENUE_GROSS_MARGIN', String(payload.manualMargin), 'manualMargin');
      await clickPrefillActorsAfterMargin(results);
    }

    return { results };
  }

  globalThis.AvvaleYubiqAutofill = {
    autofillYubiqForm,
  };
})();
