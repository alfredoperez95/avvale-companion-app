/**
 * Microsoft SSO helper: cuando hay yubiqPendingAutofill, auto-selecciona el primer "tile" de cuenta.
 * Scope limitado: solo en login.microsoftonline.com y solo si existe pending válido para yubiq_addnew.
 */
(function () {
  'use strict';

  const STORAGE_PENDING = 'yubiqPendingAutofill';
  const TARGET_YUBIQ_ADDNEW = 'yubiq_addnew';
  const MAX_RUNTIME_MS = 20000;
  const TRY_EVERY_MS = 500;

  function isVisible(el) {
    try {
      if (!el) return false;
      const r = el.getBoundingClientRect();
      if (r.width <= 1 || r.height <= 1) return false;
      const st = window.getComputedStyle(el);
      if (!st || st.display === 'none' || st.visibility === 'hidden' || st.opacity === '0') return false;
      return true;
    } catch (_) {
      return false;
    }
  }

  function hasPending(cb) {
    try {
      chrome.storage.local.get([STORAGE_PENDING], (data) => {
        const pending = data && data[STORAGE_PENDING];
        const ok =
          !!pending
          && !!pending.payload
          && typeof pending.payload === 'object'
          && pending.payload.target === TARGET_YUBIQ_ADDNEW;
        cb(ok);
      });
    } catch (_) {
      cb(false);
    }
  }

  function isAccountPicker() {
    // Señales: tiles presentes y NO estamos en pantallas de introducir usuario/clave.
    const tilesHolder = document.querySelector('#tilesHolder');
    if (!tilesHolder || !isVisible(tilesHolder)) return false;
    const anyTile =
      tilesHolder.querySelector('.tile')
      || tilesHolder.querySelector('[role="button"]')
      || tilesHolder.querySelector('button')
      || tilesHolder.querySelector('a');
    if (!anyTile) return false;

    // Evitar false positive en pantallas de email/password.
    if (document.querySelector('input[name="loginfmt"], #i0116')) return false;
    if (document.querySelector('input[name="passwd"], #i0118')) return false;
    return true;
  }

  function clickFirstTile() {
    const root = document.querySelector('#tilesHolder') || document;
    const candidates = [
      // Estructura habitual (lo que pegaste): <div class="table" role="button" ...>
      '#tilesHolder .tile-container .row.tile .table[role="button"]',
      '#tilesHolder .row.tile .table[role="button"]',
      '#tilesHolder .tile-container [role="button"]',
      '#tilesHolder [role="button"]',
      '#tilesHolder .tile-container button[type="button"]',
      '#tilesHolder button[type="button"]',
      '#tilesHolder button',
      '#tilesHolder a',
    ];
    let target = null;
    for (let i = 0; i < candidates.length; i += 1) {
      const el = root.querySelector(candidates[i]);
      if (el && isVisible(el)) {
        target = el;
        break;
      }
    }
    if (!target) return false;

    try {
      if (typeof target.focus === 'function') target.focus();
    } catch (_) {}

    // Preferir click; si no funciona, eventos de ratón.
    try {
      target.click();
      return true;
    } catch (_) {}
    try {
      target.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      target.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
      target.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
      return true;
    } catch (_) {}
    return false;
  }

  function schedule() {
    const t0 = Date.now();
    let finished = false;
    let timer = null;

    function stop() {
      finished = true;
      if (timer) clearInterval(timer);
      timer = null;
    }

    function tick() {
      if (finished) return;
      if (Date.now() - t0 > MAX_RUNTIME_MS) {
        stop();
        return;
      }
      hasPending((ok) => {
        if (!ok) {
          stop();
          return;
        }
        if (!isAccountPicker()) return;
        const clicked = clickFirstTile();
        if (clicked) stop();
      });
    }

    tick();
    timer = setInterval(tick, TRY_EVERY_MS);
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    schedule();
  } else {
    window.addEventListener('DOMContentLoaded', schedule, { once: true });
  }
})();

