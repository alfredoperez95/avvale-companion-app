/**
 * Yubiq — Select2: abrir, buscar, Enter, validación ligera.
 */
(function () {
  'use strict';

  const D = globalThis.AvvaleYubiqDom;

  function log(...args) {
    D.log('[select2]', ...args);
  }

  /**
   * Select2 4: contenedor `#select2-<id>-container` o hermano del <select>.
   * Si los ids de Yubiq no coinciden, se busca por `ariaMarker` (p. ej. qr_TipoDocumento) en id del contenedor o del <select> previo.
   * @param {string} selectId
   * @param {string} [ariaMarker] - suele ser igual a selectId o al fragmento en aria-controls
   */
  function getSelect2ContainerForSelect(selectId, ariaMarker) {
    const marker = (ariaMarker || selectId || '').toLowerCase();
    const sid = (selectId || '').toLowerCase();

    const byConvention = document.getElementById('select2-' + selectId + '-container');
    if (byConvention && byConvention.classList && byConvention.classList.contains('select2-container')) {
      return byConvention;
    }

    const sel = document.getElementById(selectId);
    if (sel && sel.tagName === 'SELECT') {
      const next = sel.nextElementSibling;
      if (next && next.classList && next.classList.contains('select2-container')) return next;
      const wrap = sel.closest('.form-group, .mb-3, div');
      if (wrap) {
        const c = wrap.querySelector('.select2-container');
        if (c) return c;
      }
    }

    const containers = document.querySelectorAll('.select2-container');
    for (let i = 0; i < containers.length; i++) {
      const c = containers[i];
      const cid = (c.id || '').toLowerCase();
      if (marker && (cid.indexOf(marker) !== -1 || cid.indexOf(sid) !== -1)) return c;
      const prev = c.previousElementSibling;
      if (prev && prev.tagName === 'SELECT') {
        const pid = (prev.id || '').toLowerCase();
        const pname = (prev.name || '').toLowerCase();
        if (pid === sid || (marker && (pid.indexOf(marker) !== -1 || pname.indexOf(marker) !== -1))) return c;
      }
    }

    log('no se encontró contenedor select2 para', selectId);
    return null;
  }

  /** Espera a que exista contenedor Select2 o <select> por id (montaje tardío). */
  async function waitForSelect2Container(selectId, ariaMarker, timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 12000);
    while (Date.now() < deadline) {
      const c = getSelect2ContainerForSelect(selectId, ariaMarker);
      if (c) return c;
      if (document.getElementById(selectId)) return getSelect2ContainerForSelect(selectId, ariaMarker);
      await D.sleep(200);
    }
    return getSelect2ContainerForSelect(selectId, ariaMarker);
  }

  /** Si getElementById(selectId) falla, el <select> suele ser previousElementSibling del contenedor. */
  function resolveNativeSelect(selectId, container) {
    const byId = document.getElementById(selectId);
    if (byId && byId.tagName === 'SELECT') return byId;
    if (container) {
      const prev = container.previousElementSibling;
      if (prev && prev.tagName === 'SELECT') return prev;
      const parent = container.parentElement;
      if (parent) {
        const s = parent.querySelector('select');
        if (s) return s;
      }
    }
    return null;
  }

  function mouseEventOptsAt(el) {
    const r = el.getBoundingClientRect();
    const cx = Math.floor(r.left + Math.max(2, r.width) / 2);
    const cy = Math.floor(r.top + Math.max(2, r.height) / 2);
    return {
      bubbles: true,
      cancelable: true,
      view: window,
      clientX: cx,
      clientY: cy,
      button: 0,
      buttons: 1,
    };
  }

  /**
   * Select2 Bootstrap 5: coordenadas en el ratón + scroll al viewport; combo y rendered.
   */
  function openSelect2ComboLikeUser(combo) {
    if (typeof combo.scrollIntoView === 'function') {
      combo.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
    }
    const o = mouseEventOptsAt(combo);
    if (typeof combo.focus === 'function') combo.focus();
    try {
      combo.dispatchEvent(
        new PointerEvent('pointerdown', {
          bubbles: true,
          cancelable: true,
          pointerId: 1,
          pointerType: 'mouse',
          clientX: o.clientX,
          clientY: o.clientY,
        })
      );
    } catch (_) {}
    combo.dispatchEvent(new MouseEvent('mousedown', o));
    try {
      combo.dispatchEvent(
        new PointerEvent('pointerup', {
          bubbles: true,
          cancelable: true,
          pointerId: 1,
          pointerType: 'mouse',
          clientX: o.clientX,
          clientY: o.clientY,
        })
      );
    } catch (_) {}
    combo.dispatchEvent(new MouseEvent('mouseup', o));
    combo.dispatchEvent(new MouseEvent('click', o));
    combo.click();

    const rendered = combo.querySelector('.select2-selection__rendered');
    if (rendered) {
      const ro = mouseEventOptsAt(rendered);
      rendered.dispatchEvent(new MouseEvent('mousedown', ro));
      rendered.dispatchEvent(new MouseEvent('mouseup', ro));
      rendered.dispatchEvent(new MouseEvent('click', ro));
      rendered.click();
    }

    combo.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, bubbles: true, cancelable: true })
    );
    combo.dispatchEvent(
      new KeyboardEvent('keydown', { key: 'ArrowDown', code: 'ArrowDown', keyCode: 40, bubbles: true, cancelable: true })
    );
  }

  /**
   * Misma lógica en el mundo MAIN de la página (listeners de la app / Select2).
   */
  function injectPageClickOpenSelect2(nativeSelectName) {
    const selStr = 'select[name="' + String(nativeSelectName).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]';
    const script = document.createElement('script');
    script.textContent =
      '(function(){try{' +
      'var sel=document.querySelector(' +
      JSON.stringify(selStr) +
      ');' +
      'if(!sel)return;' +
      'var next=sel.nextElementSibling;' +
      'if(!next||!next.classList||!next.classList.contains("select2-container"))return;' +
      'var combo=next.querySelector(".select2-selection[role=combobox]")||next.querySelector(".select2-selection");' +
      'if(!combo)return;' +
      'if(combo.scrollIntoView)combo.scrollIntoView({block:"center",inline:"nearest"});' +
      'combo.focus();' +
      'combo.click();' +
      '}catch(e){}})();';
    const root = document.documentElement || document.head || document.body;
    if (root) {
      root.appendChild(script);
      script.remove();
    }
  }

  function clickSelect2WidgetBesideNativeSelect(nativeSelectName) {
    const esc = String(nativeSelectName).replace(/"/g, '\\"');
    const list = document.querySelectorAll('select[name="' + esc + '"]');
    for (let i = 0; i < list.length; i++) {
      const sel = list[i];
      const next = sel.nextElementSibling;
      if (!next || !next.classList || !next.classList.contains('select2-container')) continue;
      if (D.isLayoutVisible && !D.isLayoutVisible(next)) continue;
      const combo =
        next.querySelector('.select2-selection[role="combobox"]') || next.querySelector('.select2-selection');
      if (!combo) continue;
      openSelect2ComboLikeUser(combo);
      return true;
    }
    return false;
  }

  function pressEnter(el) {
    if (!el) return;
    el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', bubbles: true, cancelable: true }));
  }

  function isVisibleInput(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    return r.width > 1 && r.height > 1;
  }

  /** Cierra cualquier Select2 abierto para no escribir en el input de búsqueda de otro campo. */
  async function closeAnyOpenSelect2() {
    if (!document.querySelector('.select2-container--open')) return;
    const ev = new KeyboardEvent('keydown', {
      key: 'Escape',
      code: 'Escape',
      keyCode: 27,
      bubbles: true,
      cancelable: true,
    });
    if (document.activeElement && typeof document.activeElement.blur === 'function') document.activeElement.blur();
    document.body.dispatchEvent(ev);
    document.dispatchEvent(ev);
    await D.sleep(550);
  }

  /**
   * Solo inputs cuyo aria-controls incluye el fragmento de ESTE campo (evita mezclar con otro desplegable).
   */
  async function waitForSearchInputForField(ariaContains, timeoutMs) {
    const mark = (ariaContains || '').toLowerCase();
    if (!mark) return null;
    const t0 = Date.now();
    const deadline = t0 + (timeoutMs || 12000);
    while (Date.now() < deadline) {
      const candidates = document.querySelectorAll('input.select2-search__field');
      for (let i = 0; i < candidates.length; i++) {
        const el = candidates[i];
        const ac = (el.getAttribute('aria-controls') || '').toLowerCase();
        if (ac.indexOf(mark) !== -1) {
          if (isVisibleInput(el) || Date.now() - t0 > 3500) return el;
        }
      }
      await D.sleep(200);
    }
    return null;
  }

  function findResultsRootForField(ariaContains) {
    const mark = (ariaContains || '').toLowerCase();
    if (!mark) return null;
    const roots = document.querySelectorAll('[id$="-results"]');
    for (let i = 0; i < roots.length; i++) {
      const r = roots[i];
      if ((r.id || '').toLowerCase().indexOf(mark) !== -1) return r;
    }
    return null;
  }

  async function waitForResultsOptionsForField(ariaContains, timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 5000);
    while (Date.now() < deadline) {
      const root = findResultsRootForField(ariaContains);
      if (root && root.querySelectorAll('.select2-results__option').length > 0) return true;
      await D.sleep(200);
    }
    return false;
  }

  function clickMatchingResultOption(searchText, ariaContains) {
    const root = findResultsRootForField(ariaContains);
    if (!root) return false;
    const q = searchText.toLowerCase().trim();
    const opts = root.querySelectorAll(
      '.select2-results__option[role="option"], .select2-results__option--selectable, .select2-results li.select2-results__option'
    );
    for (let i = 0; i < opts.length; i++) {
      const o = opts[i];
      if (o.getAttribute('aria-disabled') === 'true' || o.classList.contains('select2-results__option--disabled')) continue;
      const t = (o.textContent || '').trim().toLowerCase();
      if (!t || t === 'searching…' || t === 'buscando…') continue;
      if (t === q || t.indexOf(q) !== -1 || q.indexOf(t) !== -1) {
        o.click();
        return true;
      }
    }
    return false;
  }

  /**
   * Tras escribir en el buscador: esperar filtro, Enter (keydown/keyup) y/o clic en la opción resaltada o que coincida.
   */
  async function confirmSelect2SearchSelection(searchInput, searchText, ariaContains) {
    const q = String(searchText || '').toLowerCase().trim();

    function pickOptionEl() {
      const root = findResultsRootForField(ariaContains);
      if (!root) return null;
      let opt =
        root.querySelector('.select2-results__option--highlighted') ||
        root.querySelector('.select2-results__option[aria-selected="true"]');
      if (opt) return opt;
      const opts = root.querySelectorAll('.select2-results__option:not(.select2-results__option--disabled)');
      for (let i = 0; i < opts.length; i++) {
        const o = opts[i];
        if (o.getAttribute('aria-disabled') === 'true') continue;
        const t = (o.textContent || '').trim().toLowerCase();
        if (!t || t === 'searching…' || t === 'buscando…') continue;
        if (t === q || t.indexOf(q) !== -1 || q.indexOf(t) !== -1) return o;
      }
      const first = root.querySelector('.select2-results__option:not(.select2-results__option--disabled)');
      return first || null;
    }

    function clickOptionIfAny() {
      const opt = pickOptionEl();
      if (!opt) return false;
      opt.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      opt.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
      if (typeof opt.click === 'function') opt.click();
      return true;
    }

    await D.sleep(450);

    const enterOpts = { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true };
    searchInput.dispatchEvent(new KeyboardEvent('keydown', enterOpts));
    searchInput.dispatchEvent(new KeyboardEvent('keyup', enterOpts));
    await D.sleep(120);

    if (!clickOptionIfAny()) {
      pressEnter(searchInput);
      await D.sleep(220);
      clickOptionIfAny();
    }
    await D.sleep(350);
  }

  /**
   * @param {{ selectId: string, ariaControlsContains: string, text: string, fieldLabel: string, nativeSelectName?: string }} p
   * @param {string} [p.nativeSelectName] - p.ej. `qr_TipoDocumento`: clic en `select[name=...]` para abrir Select2 (Yubiq).
   */
  async function openSelect2AndSearch(p) {
    const { selectId, ariaControlsContains, text, fieldLabel, nativeSelectName } = p;
    const searchText = String(text ?? '').trim();
    if (!searchText) {
      return { ok: false, field: fieldLabel, error: 'texto vacío' };
    }

    let container = getSelect2ContainerForSelect(selectId, ariaControlsContains);
    if (!container) {
      container = await waitForSelect2Container(selectId, ariaControlsContains, 12000);
    }

    if (!container) {
      return { ok: false, field: fieldLabel, error: `contenedor select2 no encontrado para #${selectId}` };
    }

    await closeAnyOpenSelect2();

    let openedViaNativeSelect = false;
    if (nativeSelectName && typeof nativeSelectName === 'string') {
      if (clickSelect2WidgetBesideNativeSelect(nativeSelectName)) {
        openedViaNativeSelect = true;
        await D.sleep(650);
        if (document.querySelectorAll('.select2-container--open').length === 0) {
          clickSelect2WidgetBesideNativeSelect(nativeSelectName);
          await D.sleep(500);
        }
        if (document.querySelectorAll('.select2-container--open').length === 0) {
          injectPageClickOpenSelect2(nativeSelectName);
          await D.sleep(500);
        }
      }
    }

    if (!openedViaNativeSelect) {
      const selection = container.querySelector('.select2-selection');
      if (selection) {
        openSelect2ComboLikeUser(selection);
      } else {
        container.click();
      }
      await D.sleep(500);
    }

    let searchInput = await waitForSearchInputForField(ariaControlsContains, 12000);

    if (!searchInput && openedViaNativeSelect && container) {
      const selectionEl = container.querySelector('.select2-selection');
      if (selectionEl) {
        openSelect2ComboLikeUser(selectionEl);
        await D.sleep(500);
        searchInput = await waitForSearchInputForField(ariaControlsContains, 8000);
      }
    }

    let usedResultsListOnly = false;

    if (!searchInput) {
      const hasOpts = await waitForResultsOptionsForField(ariaControlsContains, 5000);
      const clicked = hasOpts && clickMatchingResultOption(searchText, ariaControlsContains);
      if (!clicked) {
        return {
          ok: false,
          field: fieldLabel,
          error: 'Select2: no se encontró campo de búsqueda ni opción en lista para el texto indicado',
        };
      }
      usedResultsListOnly = true;
    } else {
      if (typeof searchInput.focus === 'function') searchInput.focus();
      D.setNativeValue(searchInput, searchText);
      searchInput.dispatchEvent(new Event('input', { bubbles: true }));
      try {
        searchInput.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, inputType: 'insertText', data: searchText }));
      } catch (_) {}
      await confirmSelect2SearchSelection(searchInput, searchText, ariaControlsContains);
    }

    if (usedResultsListOnly) {
      await D.sleep(450);
    }

    async function readSelectionState() {
      const cont = getSelect2ContainerForSelect(selectId, ariaControlsContains) || container;
      let selEl = resolveNativeSelect(selectId, cont);
      if (!selEl && nativeSelectName) {
        const sel = 'select[name="' + nativeSelectName.replace(/"/g, '\\"') + '"]';
        selEl = D.querySelectorPreferVisible ? D.querySelectorPreferVisible(sel) : document.querySelector(sel);
      }
      const rend = cont && cont.querySelector('.select2-selection__rendered');
      const vis = (rend && rend.textContent ? rend.textContent.trim().toLowerCase() : '') || '';
      const nat = selEl && selEl.value ? String(selEl.value) : '';
      return { vis, nat };
    }

    let { vis: visible, nat: nativeVal } = await readSelectionState();
    if (!visible && !nativeVal) {
      await D.sleep(500);
      ({ vis: visible, nat: nativeVal } = await readSelectionState());
    }

    const q = searchText.toLowerCase();
    function looksLikePlaceholder(vis) {
      const v = (vis || '').trim().toLowerCase();
      if (!v) return true;
      return /^(select\s+a\s*value|seleccione|selecciona|elija|elige|choose)/.test(v);
    }
    const ok =
      visible.includes(q)
      || nativeVal.toLowerCase().includes(q)
      || nativeVal.length > 0
      || (visible.length > 0 && !looksLikePlaceholder(visible));

    if (!ok) {
      log(fieldLabel, 'validación fallida; visible=', visible, 'native=', nativeVal);
      return { ok: false, field: fieldLabel, error: 'Selección no verificada tras Enter', detail: { visible, nativeVal } };
    }

    return { ok: true, field: fieldLabel, detail: { visible, nativeVal } };
  }

  globalThis.AvvaleYubiqSelect2 = {
    openSelect2AndSearch,
    pressEnter,
    getSelect2ContainerForSelect,
    waitForSelect2Container,
    resolveNativeSelect,
  };
})();
