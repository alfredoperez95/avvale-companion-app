/**
 * Yubiq — Flujo #addnew: abrir dropdown "Create a new case", clic en "New", espera a tablist visible.
 */
(function () {
  'use strict';

  const D = globalThis.AvvaleYubiqDom;

  /** @returns {boolean} */
  function isAddNewHash() {
    const h = location.hash || '';
    return h === '#addnew' || h.endsWith('#addnew') || (h.includes('addnew') && h.startsWith('#'));
  }

  function findNewDropdownItem() {
    const items = document.querySelectorAll('ul.dropdown-menu span.dropdown-item');
    for (let i = 0; i < items.length; i++) {
      const el = items[i];
      const t = (el.textContent || '').trim();
      if (t === 'New') return el;
    }
    return null;
  }

  /** Máx. ms esperando el tablist tras "New" (antes era sleep fijo 5000). */
  const WAIT_AFTER_ADD_MS = 28000;
  const TABLIST_FORM_READY_SELECTOR = 'ul.nav.nav-tabs.nav-icons[role="tablist"]';
  const MAX_CLICK_ATTEMPTS = 40;
  const CLICK_RETRY_MS = 250;

  /**
   * Abre el dropdown "Create a new case" (Bootstrap). Los ítems del menú no están disponibles hasta abrirlo.
   * @returns {Promise<{ ok: boolean, error?: string }>}
   */
  async function openCreateCaseDropdown() {
    let btn = document.querySelector('div.actions[aria-label="Create a new case"]');
    if (!btn) {
      try {
        btn = await D.waitForElement('div.actions[aria-label="Create a new case"]', { timeoutMs: 15000, intervalMs: 200 });
      } catch (_) {
        try {
          btn = await D.waitForElement('div.actions[data-bs-toggle="dropdown"]', { timeoutMs: 6000, intervalMs: 200 });
        } catch (e2) {
          return { ok: false, error: 'Botón Create a new case no encontrado (div.actions)' };
        }
      }
    }
    try {
      btn.click();
      D.log('[addnew] clic en div.actions (abrir dropdown Create a new case)');
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || 'click en div.actions falló' };
    }
  }

  /**
   * Clic en el ítem "New" del dropdown (reintentos).
   * @returns {Promise<{ ok: boolean, error?: string }>}
   */
  async function clickDropdownNewItem() {
    D.log('[addnew] abriendo dropdown y buscando ítem "New"...');

    const openRes = await openCreateCaseDropdown();
    if (!openRes.ok) {
      return openRes;
    }

    let el = null;
    for (let a = 0; a < MAX_CLICK_ATTEMPTS; a++) {
      el = findNewDropdownItem();
      if (el) break;
      await D.sleep(CLICK_RETRY_MS);
    }
    if (!el) {
      D.log('[addnew] menú "New" no encontrado tras reintentos');
      return { ok: false, error: 'Menú "New" no encontrado (¿login o UI distinta?)' };
    }
    try {
      el.click();
      D.log('[addnew] clic en "New" ejecutado');
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || 'click falló' };
    }
  }

  async function waitAfterAddNew() {
    D.log('[addnew] esperando tablist visible…', TABLIST_FORM_READY_SELECTOR);
    try {
      await D.waitForElementVisible(TABLIST_FORM_READY_SELECTOR, {
        timeoutMs: WAIT_AFTER_ADD_MS,
        intervalMs: 250,
      });
      D.log('[addnew] tablist visible');
    } catch (e) {
      D.log('[addnew] tablist no visible en el plazo:', e?.message || e);
    }
  }

  globalThis.AvvaleYubiqAddNew = {
    isAddNewHash,
    WAIT_AFTER_ADD_MS,
    TABLIST_FORM_READY_SELECTOR,
    clickDropdownNewItem,
    waitAfterAddNew,
  };
})();
