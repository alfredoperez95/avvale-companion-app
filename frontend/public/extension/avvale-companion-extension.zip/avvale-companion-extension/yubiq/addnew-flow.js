/**
 * Yubiq — Flujo #addnew: abrir dropdown "Create a new case", clic en "New", espera a tablist visible.
 */
(function () {
  'use strict';

  const D = globalThis.AvvaleYubiqDom;

  /** @returns {boolean} */
  function isAddNewHash() {
    const h = location.hash || '';
    return h === '#addnew' || h.endsWith('#addnew') || (h.includes('addnew') && h.startsWith('#'));
  }

  function findNewDropdownItem() {
    const items = document.querySelectorAll('ul.dropdown-menu span.dropdown-item');
    for (let i = 0; i < items.length; i++) {
      const el = items[i];
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim().toLowerCase();
      if (t === 'new' || t === 'nuevo' || t === 'nuovo') return el;
    }
    return null;
  }

  /** Máx. ms esperando el tablist tras "New" (antes era sleep fijo 5000). */
  const WAIT_AFTER_ADD_MS = 28000;
  const TABLIST_FORM_READY_SELECTOR = 'ul.nav.nav-tabs.nav-icons[role="tablist"]';
  const MAX_CLICK_ATTEMPTS = 40;
  const CLICK_RETRY_MS = 250;

  /**
   * Abre el dropdown "Create a new case" (Bootstrap). Los ítems del menú no están disponibles hasta abrirlo.
   * @returns {Promise<{ ok: boolean, error?: string }>}
   */
  async function openCreateCaseDropdown() {
    // En ES/IT el aria-label puede cambiar; evitar esperar 15s por el selector en inglés.
    const selectors = [
      'div.actions[aria-label="Create a new case"]',
      'div.actions[data-bs-toggle="dropdown"]',
    ];
    let btn = null;
    const t0 = Date.now();
    const TIMEOUT_MS = 6500;
    while (!btn && Date.now() - t0 < TIMEOUT_MS) {
      for (let i = 0; i < selectors.length; i++) {
        const cand = document.querySelector(selectors[i]);
        if (cand) {
          btn = cand;
          break;
        }
      }
      if (btn) break;
      await D.sleep(200);
    }
    if (!btn) return { ok: false, error: 'Botón Create a new case no encontrado (div.actions)' };
    try {
      btn.click();
      D.log('[addnew] clic en div.actions (abrir dropdown Create a new case)');
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || 'click en div.actions falló' };
    }
  }

  /**
   * Clic en el ítem "New" del dropdown (reintentos).
   * @returns {Promise<{ ok: boolean, error?: string }>}
   */
  async function clickDropdownNewItem() {
    D.log('[addnew] abriendo dropdown y buscando ítem "New"...');

    const openRes = await openCreateCaseDropdown();
    if (!openRes.ok) {
      return openRes;
    }

    let el = null;
    for (let a = 0; a < MAX_CLICK_ATTEMPTS; a++) {
      el = findNewDropdownItem();
      if (el) break;
      await D.sleep(CLICK_RETRY_MS);
    }
    if (!el) {
      D.log('[addnew] menú "New" no encontrado tras reintentos');
      return { ok: false, error: 'Menú "New" no encontrado (¿login o UI distinta?)' };
    }
    try {
      el.click();
      D.log('[addnew] clic en "New" ejecutado');
      return { ok: true };
    } catch (e) {
      return { ok: false, error: e?.message || 'click falló' };
    }
  }

  async function waitAfterAddNew() {
    D.log('[addnew] esperando tablist visible…', TABLIST_FORM_READY_SELECTOR);
    try {
      await D.waitForElementVisible(TABLIST_FORM_READY_SELECTOR, {
        timeoutMs: WAIT_AFTER_ADD_MS,
        intervalMs: 250,
      });
      D.log('[addnew] tablist visible');
    } catch (e) {
      D.log('[addnew] tablist no visible en el plazo:', e?.message || e);
    }
  }

  globalThis.AvvaleYubiqAddNew = {
    isAddNewHash,
    WAIT_AFTER_ADD_MS,
    TABLIST_FORM_READY_SELECTOR,
    clickDropdownNewItem,
    waitAfterAddNew,
  };
})();
