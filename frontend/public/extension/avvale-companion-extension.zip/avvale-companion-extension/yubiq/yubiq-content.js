/**
 * Yubiq — Punto de entrada: storage → #addnew → New → espera → autofill.
 */
(function () {
  'use strict';

  const C = globalThis.AvvaleYubiqConstants;
  const D = globalThis.AvvaleYubiqDom;
  const Add = globalThis.AvvaleYubiqAddNew;
  const Autofill = globalThis.AvvaleYubiqAutofill;

  let executed = false;

  function isOurPending(record) {
    return (
      record
      && record.payload
      && typeof record.payload === 'object'
      && record.payload.target === C.TARGET_YUBIQ_ADDNEW
    );
  }

  /** Metadatos opcionales del JSON de Companion (validate-yubiq-payload, buildYubiqPayload). */
  function pickCompanionMeta(payload) {
    if (!payload || typeof payload !== 'object') return undefined;
    const out = {};
    if (payload.schemaVersion != null) out.schemaVersion = payload.schemaVersion;
    if (payload.generatedAt != null) out.generatedAt = payload.generatedAt;
    if (typeof payload.isValid === 'boolean') out.isValid = payload.isValid;
    if (Array.isArray(payload.validationErrors)) out.validationErrors = payload.validationErrors;
    if (Array.isArray(payload.warnings)) out.warnings = payload.warnings;
    if (payload.prefillReview != null) out.prefillReview = payload.prefillReview;
    if (payload.document && typeof payload.document === 'object') out.document = payload.document;
    if (typeof payload.manualMargin === 'number') out.manualMargin = payload.manualMargin;
    return Object.keys(out).length ? out : undefined;
  }

  async function tryRunPipeline() {
    if (executed) return;
    const data = await new Promise((resolve) => {
      chrome.storage.local.get([C.STORAGE_PENDING], resolve);
    });
    const pending = data[C.STORAGE_PENDING];
    if (!isOurPending(pending)) return;

    if (!Add.isAddNewHash()) {
      D.log('[content] hash no es #addnew; no se ejecuta autofill');
      return;
    }

    executed = true;
    const Overlay = globalThis.AvvaleCompanionOverlay;

    try {
      Overlay?.showCompanionOverlay();
      D.log('[content] inicio pipeline addnew + autofill');

      const steps = [];
      const t0 = Date.now();

      const addRes = await Add.clickDropdownNewItem();
      steps.push({ step: 'openNewDropdown', ok: addRes.ok, ...(addRes.error ? { error: addRes.error } : {}) });

      // Espera a tablist visible (carga); luego #qr_TITLE como segunda señal antes del autofill.
      await Add.waitAfterAddNew();

      let formReady = false;
      try {
        await D.waitForElement('#qr_TITLE', { timeoutMs: 25000, intervalMs: 300 });
        formReady = true;
      } catch (e) {
        D.log('[content] #qr_TITLE no apareció:', e.message);
      }

      if (!formReady) {
        const summary = {
          ok: false,
          finishedAt: new Date().toISOString(),
          steps,
          autofill: { results: [], skipped: true, reason: 'Formulario no listo (#qr_TITLE ausente tras espera)' },
          companionMeta: pickCompanionMeta(pending.payload),
          durationMs: Date.now() - t0,
        };
        await new Promise((resolve) => {
          chrome.storage.local.set({ [C.STORAGE_LAST_RESULT]: summary }, resolve);
        });
        await new Promise((resolve) => {
          chrome.storage.local.remove(C.STORAGE_PENDING, resolve);
        });
        D.log('[content] pipeline terminado sin autofill (formulario no listo)');
        return;
      }

      let autofillBlock = { results: [], skipped: false };
      try {
        autofillBlock = await Autofill.autofillYubiqForm(pending.payload);
      } catch (e) {
        autofillBlock = { results: [{ field: 'autofill', ok: false, error: e?.message || 'error global' }], skipped: false };
      }

      const allFieldResults = [...steps.map((s) => ({ field: s.step, ok: s.ok, error: s.error })), ...autofillBlock.results];
      const allOk = allFieldResults.every((r) => r.ok);

      const summary = {
        ok: allOk,
        finishedAt: new Date().toISOString(),
        steps,
        autofill: autofillBlock,
        results: allFieldResults,
        companionMeta: pickCompanionMeta(pending.payload),
        durationMs: Date.now() - t0,
      };

      await new Promise((resolve) => {
        chrome.storage.local.set({ [C.STORAGE_LAST_RESULT]: summary }, resolve);
      });
      await new Promise((resolve) => {
        chrome.storage.local.remove(C.STORAGE_PENDING, resolve);
      });

      D.log('[content] pipeline terminado', summary);
    } finally {
      if (Overlay) await Overlay.hideCompanionOverlay();
    }
  }

  function scheduleRun() {
    if (executed) return;
    setTimeout(() => {
      tryRunPipeline().catch((e) => {
        D.log('[content] error pipeline', e);
        const Ov = globalThis.AvvaleCompanionOverlay;
        if (Ov) void Ov.hideCompanionOverlay();
        chrome.storage.local.set({
          [C.STORAGE_LAST_RESULT]: {
            ok: false,
            finishedAt: new Date().toISOString(),
            error: e?.message || String(e),
          },
        });
      });
    }, 0);
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    scheduleRun();
  } else {
    window.addEventListener('DOMContentLoaded', scheduleRun, { once: true });
  }

  window.addEventListener('hashchange', () => {
    if (!Add.isAddNewHash()) return;
    executed = false;
    scheduleRun();
  });
})();
