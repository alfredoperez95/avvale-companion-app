/**
 * Yubiq — Punto de entrada: storage → #addnew → New → espera → autofill.
 */
(function () {
  'use strict';

  const C = globalThis.AvvaleYubiqConstants;
  const D = globalThis.AvvaleYubiqDom;
  const Add = globalThis.AvvaleYubiqAddNew;
  const Autofill = globalThis.AvvaleYubiqAutofill;

  let executed = false;
  let loginRetryCount = 0;
  let loginRetryTimer = null;
  const LOGIN_RETRY_MAX = 10;
  const LOGIN_RETRY_DELAY_MS = 2000;

  function isOurPending(record) {
    return (
      record
      && record.payload
      && typeof record.payload === 'object'
      && record.payload.target === C.TARGET_YUBIQ_ADDNEW
    );
  }

  /** Metadatos opcionales del JSON de Companion (validate-yubiq-payload, buildYubiqPayload). */
  function pickCompanionMeta(payload) {
    if (!payload || typeof payload !== 'object') return undefined;
    const out = {};
    if (payload.schemaVersion != null) out.schemaVersion = payload.schemaVersion;
    if (payload.generatedAt != null) out.generatedAt = payload.generatedAt;
    if (typeof payload.isValid === 'boolean') out.isValid = payload.isValid;
    if (Array.isArray(payload.validationErrors)) out.validationErrors = payload.validationErrors;
    if (Array.isArray(payload.warnings)) out.warnings = payload.warnings;
    if (payload.prefillReview != null) out.prefillReview = payload.prefillReview;
    if (payload.document && typeof payload.document === 'object') out.document = payload.document;
    if (typeof payload.manualMargin === 'number') out.manualMargin = payload.manualMargin;
    return Object.keys(out).length ? out : undefined;
  }

  function isVisible(el) {
    try {
      if (!el) return false;
      if (D && typeof D.isLayoutVisible === 'function') return D.isLayoutVisible(el);
      const r = el.getBoundingClientRect();
      return r.width > 1 && r.height > 1;
    } catch (_) {
      return false;
    }
  }

  function detectLoginCard() {
    // Señales estables (evitar depender de clases)
    const h1 = document.querySelector('h1');
    if (h1 && isVisible(h1) && (h1.textContent || '').trim().toLowerCase() === 'simple login') return true;

    const openidBtn = document.getElementById('openidconnect');
    if (openidBtn && isVisible(openidBtn)) return true;

    const form = document.querySelector('form[action*="/Account/LoginOpenIdConnect"]');
    if (form && isVisible(form)) return true;

    // Fallback: botón con texto "Sign In" dentro de una card de login
    const btns = document.querySelectorAll('button');
    for (let i = 0; i < btns.length; i += 1) {
      const b = btns[i];
      if (!isVisible(b)) continue;
      const txt = (b.textContent || '').trim().toLowerCase();
      if (txt === 'sign in' && (b.closest('.card') || b.closest('form'))) return true;
    }
    return false;
  }

  function clickSignInIfPresent() {
    const openidBtn = document.getElementById('openidconnect');
    if (openidBtn && isVisible(openidBtn)) {
      try { openidBtn.click(); return true; } catch (_) {}
    }
    const formBtn = document.querySelector('form[action*="/Account/LoginOpenIdConnect"] button[type="submit"]');
    if (formBtn && isVisible(formBtn)) {
      try { formBtn.click(); return true; } catch (_) {}
    }
    const btns = document.querySelectorAll('button');
    for (let i = 0; i < btns.length; i += 1) {
      const b = btns[i];
      if (!isVisible(b)) continue;
      if ((b.textContent || '').trim().toLowerCase() === 'sign in') {
        try { b.click(); return true; } catch (_) {}
      }
    }
    return false;
  }

  function scheduleLoginRetry() {
    if (loginRetryTimer != null) return;
    loginRetryTimer = setTimeout(() => {
      loginRetryTimer = null;
      tryRunPipeline().catch((e) => {
        D.log('[content] error pipeline (login retry)', e);
      });
    }, LOGIN_RETRY_DELAY_MS);
  }

  async function tryRunPipeline() {
    if (executed) return;
    const data = await new Promise((resolve) => {
      chrome.storage.local.get([C.STORAGE_PENDING], resolve);
    });
    const pending = data[C.STORAGE_PENDING];
    if (!isOurPending(pending)) return;

    if (!Add.isAddNewHash()) {
      // Tras login (Yubiq o Microsoft) a veces volvemos a /YUBIK/home sin #addnew.
      // Si hay pending, forzamos #addnew para que el pipeline pueda continuar.
      try {
        if (typeof location !== 'undefined' && /\/YUBIK\/home/i.test(location.pathname || '')) {
          D.log('[content] no #addnew pero hay pending; navegando a #addnew');
          location.hash = '#addnew';
          scheduleLoginRetry();
        } else {
          D.log('[content] hash no es #addnew; no se ejecuta autofill');
        }
      } catch (_) {}
      return;
    }

    const Overlay = globalThis.AvvaleCompanionOverlay;

    try {
      // Gate: si estamos en login, no ejecutar el pipeline todavía.
      if (detectLoginCard()) {
        try { await Overlay?.hideCompanionOverlay?.(); } catch (_) {}
        const clicked = clickSignInIfPresent();
        loginRetryCount += 1;
        D.log('[content] login detectado; Sign In click:', clicked, 'retry', loginRetryCount, '/', LOGIN_RETRY_MAX);

        if (loginRetryCount > LOGIN_RETRY_MAX) {
          const summary = {
            ok: false,
            finishedAt: new Date().toISOString(),
            error: 'login_timeout',
            reason: 'Se requiere iniciar sesión en Yubiq (Simple Login).',
            retries: loginRetryCount - 1,
            companionMeta: pickCompanionMeta(pending.payload),
          };
          await new Promise((resolve) => {
            chrome.storage.local.set({ [C.STORAGE_LAST_RESULT]: summary }, resolve);
          });
          await new Promise((resolve) => {
            chrome.storage.local.remove(C.STORAGE_PENDING, resolve);
          });
          return;
        }

        scheduleLoginRetry();
        return;
      }

      // Ya no estamos en login: reiniciar estado de reintentos.
      loginRetryCount = 0;
      if (loginRetryTimer != null) {
        clearTimeout(loginRetryTimer);
        loginRetryTimer = null;
      }

      executed = true;
      Overlay?.showCompanionOverlay();
      D.log('[content] inicio pipeline addnew + autofill');

      const steps = [];
      const t0 = Date.now();

      const addRes = await Add.clickDropdownNewItem();
      steps.push({ step: 'openNewDropdown', ok: addRes.ok, ...(addRes.error ? { error: addRes.error } : {}) });

      // Espera a tablist visible (carga); luego #qr_TITLE como segunda señal antes del autofill.
      await Add.waitAfterAddNew();

      let formReady = false;
      try {
        await D.waitForElement('#qr_TITLE', { timeoutMs: 25000, intervalMs: 300 });
        formReady = true;
      } catch (e) {
        D.log('[content] #qr_TITLE no apareció:', e.message);
      }

      if (!formReady) {
        const summary = {
          ok: false,
          finishedAt: new Date().toISOString(),
          steps,
          autofill: { results: [], skipped: true, reason: 'Formulario no listo (#qr_TITLE ausente tras espera)' },
          companionMeta: pickCompanionMeta(pending.payload),
          durationMs: Date.now() - t0,
        };
        await new Promise((resolve) => {
          chrome.storage.local.set({ [C.STORAGE_LAST_RESULT]: summary }, resolve);
        });
        await new Promise((resolve) => {
          chrome.storage.local.remove(C.STORAGE_PENDING, resolve);
        });
        D.log('[content] pipeline terminado sin autofill (formulario no listo)');
        return;
      }

      let autofillBlock = { results: [], skipped: false };
      try {
        autofillBlock = await Autofill.autofillYubiqForm(pending.payload);
      } catch (e) {
        autofillBlock = { results: [{ field: 'autofill', ok: false, error: e?.message || 'error global' }], skipped: false };
      }

      const allFieldResults = [...steps.map((s) => ({ field: s.step, ok: s.ok, error: s.error })), ...autofillBlock.results];
      const allOk = allFieldResults.every((r) => r.ok);

      const summary = {
        ok: allOk,
        finishedAt: new Date().toISOString(),
        steps,
        autofill: autofillBlock,
        results: allFieldResults,
        companionMeta: pickCompanionMeta(pending.payload),
        durationMs: Date.now() - t0,
      };

      await new Promise((resolve) => {
        chrome.storage.local.set({ [C.STORAGE_LAST_RESULT]: summary }, resolve);
      });
      await new Promise((resolve) => {
        chrome.storage.local.remove(C.STORAGE_PENDING, resolve);
      });

      D.log('[content] pipeline terminado', summary);
    } finally {
      if (Overlay) await Overlay.hideCompanionOverlay();
    }
  }

  function scheduleRun() {
    if (executed) return;
    setTimeout(() => {
      tryRunPipeline().catch((e) => {
        D.log('[content] error pipeline', e);
        const Ov = globalThis.AvvaleCompanionOverlay;
        if (Ov) void Ov.hideCompanionOverlay();
        chrome.storage.local.set({
          [C.STORAGE_LAST_RESULT]: {
            ok: false,
            finishedAt: new Date().toISOString(),
            error: e?.message || String(e),
          },
        });
      });
    }, 0);
  }

  if (document.readyState === 'complete' || document.readyState === 'interactive') {
    scheduleRun();
  } else {
    window.addEventListener('DOMContentLoaded', scheduleRun, { once: true });
  }

  window.addEventListener('hashchange', () => {
    if (!Add.isAddNewHash()) return;
    executed = false;
    scheduleRun();
  });
})();
