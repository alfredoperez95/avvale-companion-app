/**
 * Yubiq — DOM helpers (wait, native value, fecha).
 */
(function () {
  'use strict';

  const C = globalThis.AvvaleYubiqConstants;
  const PREFIX = C ? C.LOG_PREFIX : '[Yubiq Autofill]';

  function log(...args) {
    console.log(PREFIX, ...args);
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * @param {string} selector
   * @param {{ timeoutMs?: number, intervalMs?: number, root?: Document | Element }} [opts]
   */
  function waitForElement(selector, opts) {
    const timeoutMs = opts?.timeoutMs ?? 20000;
    const intervalMs = opts?.intervalMs ?? 250;
    const root = opts?.root ?? document;
    const start = Date.now();
    return new Promise((resolve, reject) => {
      function tick() {
        const el = root.querySelector(selector);
        if (el) {
          resolve(el);
          return;
        }
        if (Date.now() - start >= timeoutMs) {
          reject(new Error(`waitForElement timeout: ${selector}`));
          return;
        }
        setTimeout(tick, intervalMs);
      }
      tick();
    });
  }

  /**
   * Yubiq duplica ids en el DOM (p. ej. dos #qr_TITLE). querySelector coge el primero,
   * que no es el del formulario visible. Preferimos el último nodo con layout visible.
   */
  function isLayoutVisible(el) {
    if (!el || el.nodeType !== 1) return false;
    if (el.getAttribute && String(el.getAttribute('type')).toLowerCase() === 'hidden') return false;
    const st = window.getComputedStyle(el);
    if (st.display === 'none' || st.visibility === 'hidden' || Number(st.opacity) === 0) return false;
    const r = el.getBoundingClientRect();
    return r.width >= 2 && r.height >= 2;
  }

  /**
   * Entre coincidencias del selector, devuelve la última con layout visible (misma idea que querySelectorPreferVisible).
   * @param {string} selector
   * @param {Document | Element} [root]
   * @returns {Element | null}
   */
  function pickLastVisibleMatch(selector, root) {
    const doc = root && root.querySelectorAll ? root : document;
    const list = doc.querySelectorAll(selector);
    const visible = [];
    for (let i = 0; i < list.length; i++) {
      if (isLayoutVisible(list[i])) visible.push(list[i]);
    }
    if (visible.length === 0) return null;
    return visible[visible.length - 1];
  }

  /**
   * Espera hasta que exista al menos un nodo que cumpla el selector y pase isLayoutVisible.
   * @param {string} selector
   * @param {{ timeoutMs?: number, intervalMs?: number, root?: Document | Element }} [opts]
   */
  function waitForElementVisible(selector, opts) {
    const timeoutMs = opts?.timeoutMs ?? 28000;
    const intervalMs = opts?.intervalMs ?? 250;
    const root = opts?.root ?? document;
    const start = Date.now();
    return new Promise((resolve, reject) => {
      function tick() {
        const el = pickLastVisibleMatch(selector, root);
        if (el) {
          resolve(el);
          return;
        }
        if (Date.now() - start >= timeoutMs) {
          reject(new Error(`waitForElementVisible timeout: ${selector}`));
          return;
        }
        setTimeout(tick, intervalMs);
      }
      tick();
    });
  }

  function querySelectorPreferVisible(selector, root) {
    const doc = root && root.querySelectorAll ? root : document;
    const list = doc.querySelectorAll(selector);
    if (list.length === 0) return null;
    if (list.length === 1) return list[0];
    const visible = [];
    for (let i = 0; i < list.length; i++) {
      if (isLayoutVisible(list[i])) visible.push(list[i]);
    }
    if (visible.length === 1) return visible[0];
    if (visible.length > 1) return visible[visible.length - 1];
    return list[list.length - 1];
  }

  function setNativeValue(element, value) {
    if (!element) return;
    const proto = element.constructor && element.constructor.prototype;
    const desc = proto ? Object.getOwnPropertyDescriptor(proto, 'value') : null;
    const setter = desc && typeof desc.set === 'function' ? desc.set : null;
    if (setter) {
      setter.call(element, value);
    } else {
      element.value = value;
    }
    element.dispatchEvent(new Event('input', { bubbles: true }));
    try {
      element.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true }));
    } catch (_) {
      /* InputEvent no disponible en algunos contextos */
    }
    element.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function blurElement(el) {
    if (el && typeof el.blur === 'function') el.blur();
  }

  function todayYYYY_MM_DD() {
    const d = new Date();
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /** Formato que espera Yubiq en pantalla (To be signed): DD/MM/AAAA */
  function formatDateDDMMYYYY(date) {
    const d = date instanceof Date ? date : new Date(date);
    const day = String(d.getDate()).padStart(2, '0');
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const y = d.getFullYear();
    return `${day}/${m}/${y}`;
  }

  function toYYYYMMDD(date) {
    const d = date instanceof Date ? date : new Date(date);
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  /**
   * Fecha "To be signed": visible en DD/MM/AAAA; oculto en ISO (típico datepicker).
   * El payload de Companion puede venir en ISO YYYY-MM-DD o DD/MM/AAAA.
   * @param {object} [prefill]
   * @returns {{ valueDisplay: string, valueHidden: string, source: 'payload' | 'extension_today' }}
   */
  function resolveToBeSignedDate(prefill) {
    const raw = prefill && typeof prefill.toBeSigned === 'string' ? prefill.toBeSigned.trim() : '';

    if (/^\d{2}\/\d{2}\/\d{4}$/.test(raw)) {
      const [day, month, year] = raw.split('/').map(Number);
      const dt = new Date(year, month - 1, day);
      if (dt.getFullYear() === year && dt.getMonth() === month - 1 && dt.getDate() === day) {
        log('[toBeSigned] DD/MM/AAAA del payload:', raw);
        return { valueDisplay: raw, valueHidden: toYYYYMMDD(dt), source: 'payload' };
      }
    }

    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      const [Y, M, d] = raw.split('-').map(Number);
      const dt = new Date(Y, M - 1, d);
      if (dt.getFullYear() === Y && dt.getMonth() === M - 1 && dt.getDate() === d) {
        const ddmm = formatDateDDMMYYYY(dt);
        log('[toBeSigned] ISO del payload → visible DD/MM/AAAA:', ddmm);
        return { valueDisplay: ddmm, valueHidden: raw, source: 'payload' };
      }
    }

    const today = new Date();
    const ddmm = formatDateDDMMYYYY(today);
    const iso = toYYYYMMDD(today);
    log('[toBeSigned] usando hoy — visible', ddmm, 'oculto', iso);
    return { valueDisplay: ddmm, valueHidden: iso, source: 'extension_today' };
  }

  globalThis.AvvaleYubiqDom = {
    log,
    sleep,
    waitForElement,
    waitForElementVisible,
    pickLastVisibleMatch,
    querySelectorPreferVisible,
    isLayoutVisible,
    setNativeValue,
    blurElement,
    todayYYYY_MM_DD,
    formatDateDDMMYYYY,
    resolveToBeSignedDate,
  };
})();
