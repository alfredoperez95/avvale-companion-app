/**
 * Content script en la Companion App: escucha CustomEvent y reenvía YUBIQ_START_AUTOFILL al background.
 * La página dispara: document.dispatchEvent(new CustomEvent('avvale-companion-yubiq-start', { bubbles: true, detail: { payload } }));
 *
 * Handshake ping/pong (detección de extensión, mismo document que la SPA; sin chrome.runtime en la página):
 * - La web dispara `avvale-companion-ping` (puede usar composed: true).
 * - Respondemos síncrono con `avvale-companion-pong` { bubbles: true, composed: true }.
 */
(function () {
  'use strict';

  const EVENT_START = 'avvale-companion-yubiq-start';
  const EVENT_RESULT = 'avvale-companion-yubiq-result';
  const EVENT_PING = 'avvale-companion-ping';
  const EVENT_PONG = 'avvale-companion-pong';

  document.addEventListener(EVENT_PING, () => {
    document.dispatchEvent(new CustomEvent(EVENT_PONG, { bubbles: true, composed: true }));
  });

  document.addEventListener(
    EVENT_START,
    (e) => {
      const payload = e && e.detail && e.detail.payload;
      if (!payload || typeof payload !== 'object') {
        document.dispatchEvent(
          new CustomEvent(EVENT_RESULT, {
            bubbles: true,
            detail: { ok: false, error: 'payload inválido o ausente en detail' },
          }),
        );
        return;
      }

      chrome.runtime.sendMessage(
        { type: 'YUBIQ_START_AUTOFILL', payload, source: 'companion_page' },
        (resp) => {
          const lastErr = chrome.runtime.lastError;
          if (lastErr) {
            document.dispatchEvent(
              new CustomEvent(EVENT_RESULT, {
                bubbles: true,
                detail: { ok: false, error: lastErr.message },
              }),
            );
            return;
          }
          document.dispatchEvent(
            new CustomEvent(EVENT_RESULT, {
              bubbles: true,
              detail: resp && typeof resp === 'object' ? resp : { ok: false },
            }),
          );
        },
      );
    },
    true,
  );
})();
