/**
 * Avvale Companion - PDF Analyzer (content script)
 * Modal + file picker + lectura base64 + llamada a background + relleno de Deal.
 */
(function () {
  const OVERLAY_ID = 'avvale-companion-pdf-overlay';
  const MODAL_ID = 'avvale-companion-pdf-modal';
  const INPUT_ID = 'avvale-companion-pdf-input';

  function removeExisting() {
    document.getElementById(MODAL_ID)?.remove();
    document.getElementById(OVERLAY_ID)?.remove();
  }

  function readFileAsBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('No se pudo leer el archivo.'));
      reader.onload = () => {
        const result = String(reader.result || '');
        const m = result.match(/^data:application\/pdf;base64,(.*)$/);
        if (!m) {
          reject(new Error('Formato de PDF no válido.'));
          return;
        }
        resolve(m[1]);
      };
      reader.readAsDataURL(file);
    });
  }

  function setStatus(statusEl, msg, isError) {
    if (!statusEl) return;
    statusEl.textContent = msg || '';
    statusEl.classList.toggle('is-error', !!isError);
  }

  function initPDFAnalyzer() {
    removeExisting();
    const overlay = document.createElement('div');
    overlay.id = OVERLAY_ID;
    overlay.className = 'avvale-companion-modal-overlay';

    const modal = document.createElement('div');
    modal.id = MODAL_ID;
    modal.className = 'avvale-companion-modal';
    modal.setAttribute('role', 'dialog');
    modal.setAttribute('aria-modal', 'true');
    modal.setAttribute('aria-label', 'Analizar PDF');

    const header = document.createElement('div');
    header.className = 'avvale-companion-modal__header';

    const title = document.createElement('div');
    title.className = 'avvale-companion-modal__title';
    title.textContent = 'Analizar PDF';

    const close = document.createElement('button');
    close.type = 'button';
    close.className = 'avvale-companion-modal__close';
    close.textContent = '×';
    close.setAttribute('aria-label', 'Cerrar');

    header.appendChild(title);
    header.appendChild(close);

    const body = document.createElement('div');
    body.className = 'avvale-companion-modal__body';

    const hint = document.createElement('div');
    hint.className = 'avvale-companion-modal__hint';
    hint.textContent = 'Selecciona un PDF para extraer los datos del Deal.';

    const input = document.createElement('input');
    input.id = INPUT_ID;
    input.type = 'file';
    input.accept = 'application/pdf';
    input.className = 'avvale-companion-modal__file';

    const status = document.createElement('div');
    status.className = 'avvale-companion-modal__status';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');

    const preview = document.createElement('div');
    preview.className = 'avvale-companion-modal__preview';
    preview.hidden = true;

    body.appendChild(hint);
    body.appendChild(input);
    body.appendChild(status);
    body.appendChild(preview);

    const actions = document.createElement('div');
    actions.className = 'avvale-companion-modal__actions';

    const cancelBtn = document.createElement('button');
    cancelBtn.type = 'button';
    cancelBtn.className = 'avvale-companion-modal__btn avvale-companion-modal__btn--secondary';
    cancelBtn.textContent = 'Cancelar';

    const pickBtn = document.createElement('button');
    pickBtn.type = 'button';
    pickBtn.className = 'avvale-companion-modal__btn';
    pickBtn.textContent = 'Elegir PDF';

    actions.appendChild(cancelBtn);
    actions.appendChild(pickBtn);

    modal.appendChild(header);
    modal.appendChild(body);
    modal.appendChild(actions);

    function closeModal() {
      removeExisting();
    }

    overlay.addEventListener('click', closeModal);
    close.addEventListener('click', closeModal);
    cancelBtn.addEventListener('click', closeModal);
    document.addEventListener(
      'keydown',
      (e) => {
        if (e.key === 'Escape') closeModal();
      },
      { once: true }
    );

    pickBtn.addEventListener('click', () => input.click());

    input.addEventListener('change', async () => {
      const file = input.files && input.files[0];
      if (!file) return;

      if (file.type !== 'application/pdf' && !file.name.toLowerCase().endsWith('.pdf')) {
        setStatus(status, 'El archivo debe ser un PDF.', true);
        return;
      }

      const maxBytes = 20 * 1024 * 1024;
      if (file.size > maxBytes) {
        setStatus(status, 'El PDF es demasiado grande (máx 20MB).', true);
        return;
      }

      setStatus(status, 'Leyendo PDF…');
      let pdfBase64;
      try {
        pdfBase64 = await readFileAsBase64(file);
      } catch (e) {
        setStatus(status, e.message || 'Error al leer el PDF.', true);
        return;
      }

      setStatus(status, 'Analizando con Anthropic…');
      pickBtn.disabled = true;
      cancelBtn.disabled = true;
      close.disabled = true;

      chrome.runtime.sendMessage(
        { type: 'ANALYZE_PDF', pdfBase64, fileName: file.name },
        (resp) => {
          pickBtn.disabled = false;
          cancelBtn.disabled = false;
          close.disabled = false;

          if (chrome.runtime.lastError) {
            setStatus(status, chrome.runtime.lastError.message || 'Error al analizar el PDF.', true);
            return;
          }
          if (!resp || !resp.ok) {
            const errBase = (resp && resp.error) || 'Error al analizar el PDF.';
            const tail =
              resp && typeof resp.processing_time_ms === 'number'
                ? ` — ${resp.processing_time_ms} ms`
                  + (typeof resp.anthropic_model_id === 'string' ? ` · ${resp.anthropic_model_id}` : '')
                : '';
            setStatus(status, errBase + tail, true);
            return;
          }

          const fields = (resp && resp.fields) ? resp.fields : {};
          const dealnameFinal = fields && typeof fields.dealname_final === 'string' ? fields.dealname_final.trim() : (fields?.dealname_final ?? null);
          const dealType = fields && typeof fields.deal_type === 'string' ? fields.deal_type.trim() : (fields?.deal_type ?? null);
          const valor = fields?.valor ?? null;
          const fecha = fields && typeof fields.fecha_cierre === 'string' ? fields.fecha_cierre.trim() : (fields?.fecha_cierre ?? null);

          const pref = typeof resp.anthropic_model_pref === 'string' ? resp.anthropic_model_pref : '';
          const prefLabel =
            pref === 'opus' ? 'Opus' : pref === 'haiku' ? 'Haiku' : pref === 'sonnet' ? 'Sonnet' : pref || '(n/d)';
          const modelId = typeof resp.anthropic_model_id === 'string' ? resp.anthropic_model_id : '';
          const procMs = typeof resp.processing_time_ms === 'number' ? resp.processing_time_ms : null;

          // Mostrar vista previa antes de aplicar (no modifica el Deal).
          preview.hidden = false;
          preview.innerHTML =
            `<span class="label">Modelo (ajuste):</span> ${prefLabel}${modelId ? ` — ${modelId}` : ''}\n`
            + `<span class="label">Tiempo de análisis:</span> ${procMs != null ? `${procMs} ms` : '(n/d)'}\n`
            + `\n`
            + `<span class="label">Nombre del negocio:</span> ${String(dealnameFinal ?? '(vacío)')}\n`
            + `<span class="label">Tipo de negocio:</span> ${String(dealType ?? '(vacío)')}\n`
            + `<span class="label">Valor:</span> ${String(valor ?? '(vacío)')}\n`
            + `<span class="label">Fecha de cierre:</span> ${String(fecha ?? '(vacío)')}\n`;

          // Cambiar acciones: Cancelar + Aplicar
          pickBtn.hidden = true;
          cancelBtn.textContent = 'Cancelar';
          const applyBtn = document.createElement('button');
          applyBtn.type = 'button';
          applyBtn.className = 'avvale-companion-modal__btn';
          applyBtn.textContent = 'Aplicar';
          actions.appendChild(applyBtn);

          setStatus(
            status,
            procMs != null
              ? `Vista previa lista (${procMs} ms, ${prefLabel}). Pulsa Aplicar para rellenar el Deal.`
              : 'Vista previa lista. Pulsa Aplicar para rellenar el Deal.'
          );

          applyBtn.addEventListener('click', () => {
            try {
              if (typeof window.fillDealFields === 'function') {
                window.fillDealFields(fields);
              } else {
                setStatus(status, 'No existe window.fillDealFields(). Falta implementarlo en content.js.', true);
                return;
              }
            } catch (e) {
              setStatus(status, e.message || 'No se pudieron rellenar los campos.', true);
              return;
            }
            setStatus(status, 'Campos rellenados.');
            setTimeout(closeModal, 500);
          });

          return;

          try {
            if (typeof window.fillDealFields === 'function') {
              window.fillDealFields(resp.fields || {});
            } else {
              setStatus(status, 'No existe window.fillDealFields(). Falta implementarlo en content.js.', true);
              return;
            }
          } catch (e) {
            setStatus(status, e.message || 'No se pudieron rellenar los campos.', true);
            return;
          }

          setStatus(status, 'Campos rellenados.');
          setTimeout(closeModal, 500);
        }
      );
    });

    document.documentElement.appendChild(overlay);
    document.documentElement.appendChild(modal);
  }

  globalThis.initPDFAnalyzer = initPDFAnalyzer;
})();

