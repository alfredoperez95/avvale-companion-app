/**
 * Copiar a la Companion App (Next.js), p. ej. `frontend/src/lib/yubiq/extension-bridge.ts`.
 *
 * Botón "Enviar a Yubiq" (equivalente al popup):
 * - Añadir `data-avvale-action="send-yubiq"` al botón (estable; no depender solo de CSS Modules).
 * - Tras `buildYubiqPayload()`:
 *   `dispatchYubiqToExtension(payload);`
 * - Opcional: `useEffect(() => onYubiqExtensionResult((r) => toast(r.ok ? 'Abriendo Yubiq…' : r.error)), []);`
 *
 * Payload Yubiq (raíz del JSON, además de `prefill`):
 * - `manualMargin` (opcional): entero 0–100. Si no aplica, omitir la clave (no `null` ni `""`).
 *   La extensión rellena `#qr_CFG_REVENUE_GROSS_MARGIN` (Gross margin %) cuando el valor es válido.
 */

export const AVVALE_YUBIQ_EVENT_START = 'avvale-companion-yubiq-start';
export const AVVALE_YUBIQ_EVENT_RESULT = 'avvale-companion-yubiq-result';

/**
 * Handshake de detección de la extensión en la misma pestaña que la SPA.
 * El content script `companion-yubiq-bridge.js` de la extensión escucha `COMPANION_EXTENSION_PING`
 * y responde de forma síncrona con `COMPANION_EXTENSION_PONG` (sin usar `chrome.runtime` en la página).
 *
 * En la app web, `probeCompanionExtension` (p. ej. en `frontend/src/lib/yubiq/…`) despacha el ping en
 * `document` y espera el pong antes de ~700 ms para mostrar “Extensión Avvale Companion detectada”.
 */
export const COMPANION_EXTENSION_PING = 'avvale-companion-ping';
export const COMPANION_EXTENSION_PONG = 'avvale-companion-pong';

export type YubiqExtensionResult = {
  ok: boolean;
  tabId?: number;
  error?: string;
};

export function dispatchYubiqToExtension(payload: unknown): void {
  if (typeof document === 'undefined') return;
  document.dispatchEvent(
    new CustomEvent(AVVALE_YUBIQ_EVENT_START, {
      bubbles: true,
      detail: { payload },
    }),
  );
}

export function onYubiqExtensionResult(
  handler: (detail: YubiqExtensionResult) => void,
): () => void {
  if (typeof document === 'undefined') {
    return () => {};
  }
  const listener = (e: Event) => {
    const ce = e as CustomEvent<YubiqExtensionResult>;
    if (ce.detail) handler(ce.detail);
  };
  document.addEventListener(AVVALE_YUBIQ_EVENT_RESULT, listener);
  return () => document.removeEventListener(AVVALE_YUBIQ_EVENT_RESULT, listener);
}
