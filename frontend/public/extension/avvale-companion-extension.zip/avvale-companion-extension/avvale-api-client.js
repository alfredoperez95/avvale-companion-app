/**
 * Cliente API Avvale Companion (service worker).
 * Base: https://www.avvalecompanion.app/api
 */
var AVVALE_API_BASE = 'https://www.avvalecompanion.app/api';
var STORAGE_KEY_AVVALE_ACCESS_TOKEN = 'avvaleCompanionAccessToken';
var STORAGE_KEY_AVVALE_USER = 'avvaleCompanionUser';
var STORAGE_KEY_AVVALE_CC_CONTACTS = 'avvaleCcContacts';

function avvaleClearAuthSession(callback) {
  chrome.storage.local.remove(
    [STORAGE_KEY_AVVALE_ACCESS_TOKEN, STORAGE_KEY_AVVALE_USER, STORAGE_KEY_AVVALE_CC_CONTACTS],
    () => {
      if (typeof callback === 'function') callback();
    },
  );
}

/**
 * @returns {Promise<{ ok: boolean, accessToken?: string, user?: object, error?: string, status?: number }>}
 */
function avvaleApiLogin(email, password) {
  const em = typeof email === 'string' ? email.trim() : '';
  const pw = typeof password === 'string' ? password : '';
  if (!em || !pw) {
    return Promise.resolve({ ok: false, error: 'Email y contraseña son obligatorios.' });
  }
  const loginUrl = `${AVVALE_API_BASE}/auth/login`;
  return fetch(loginUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/json', accept: 'application/json' },
    body: JSON.stringify({ email: em, password: pw }),
  })
    .then(async (res) => {
      const text = await res.text().catch(() => '');
      if (res.status === 401) {
        return { ok: false, error: 'Credenciales incorrectas o usuario deshabilitado.', status: 401 };
      }
      if (!res.ok) {
        let displayError = text || res.statusText || `Error ${res.status}`;
        try {
          const errJson = text ? JSON.parse(text) : null;
          if (res.status >= 500) {
            displayError =
              'El servidor de Avvale Companion devolvió un error interno (' +
              res.status +
              '). Si el email y la contraseña son correctos, el fallo está en el servicio (no en la extensión). Reintenta más tarde o contacta con el equipo del API.';
            if (
              errJson
              && typeof errJson.message === 'string'
              && errJson.message.trim()
              && !/^internal server error$/i.test(errJson.message.trim())
            ) {
              displayError += ' Detalle: ' + errJson.message.trim();
            }
          } else if (errJson && typeof errJson.message === 'string' && errJson.message.trim()) {
            displayError = errJson.message.trim();
          }
        } catch (_) {
          if (res.status >= 500) {
            displayError =
              'El servidor de Avvale Companion devolvió un error interno (' +
              res.status +
              '). Reintenta más tarde o contacta con el equipo del API.';
          }
        }
        return { ok: false, error: displayError, status: res.status };
      }
      let json;
      try {
        json = text ? JSON.parse(text) : {};
      } catch {
        return { ok: false, error: 'Respuesta inválida del servidor.' };
      }
      const accessToken = json && typeof json.accessToken === 'string' ? json.accessToken : '';
      const user = json && json.user && typeof json.user === 'object' ? json.user : null;
      if (!accessToken) {
        return { ok: false, error: 'No se recibió accessToken.' };
      }
      return new Promise((resolve) => {
        chrome.storage.local.set(
          {
            [STORAGE_KEY_AVVALE_ACCESS_TOKEN]: accessToken,
            [STORAGE_KEY_AVVALE_USER]: user || { email: em },
          },
          () => {
            if (chrome.runtime.lastError) {
              resolve({ ok: false, error: chrome.runtime.lastError.message });
              return;
            }
            resolve({ ok: true, accessToken, user: user || { email: em } });
          },
        );
      });
    })
    .catch((e) => ({ ok: false, error: e && e.message ? e.message : 'Error de red' }));
}

/**
 * @returns {Promise<{ ok: boolean, contacts?: Array, needsLogin?: boolean, error?: string }>}
 */
function avvaleApiFetchContacts(accessToken) {
  const token = typeof accessToken === 'string' ? accessToken.trim() : '';
  if (!token) {
    return Promise.resolve({ ok: false, needsLogin: true, error: 'No hay sesión.' });
  }
  return fetch(`${AVVALE_API_BASE}/contacts`, {
    method: 'GET',
    headers: {
      accept: 'application/json',
      authorization: `Bearer ${token}`,
    },
  })
    .then(async (res) => {
      if (res.status === 401) {
        avvaleClearAuthSession();
        return { ok: false, needsLogin: true, error: 'Sesión caducada o no válida.' };
      }
      const text = await res.text().catch(() => '');
      if (!res.ok) {
        return { ok: false, error: text || res.statusText || `Error ${res.status}` };
      }
      let data;
      try {
        data = text ? JSON.parse(text) : [];
      } catch {
        return { ok: false, error: 'Respuesta inválida del servidor.' };
      }
      if (!Array.isArray(data)) {
        return { ok: false, error: 'Formato de contactos inesperado.' };
      }
      return { ok: true, contacts: data };
    })
    .catch((e) => ({ ok: false, error: e && e.message ? e.message : 'Error de red' }));
}

/**
 * @returns {Promise<{ ok: boolean, count?: number, needsLogin?: boolean, error?: string }>}
 */
function avvaleApiSyncContacts() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [STORAGE_KEY_AVVALE_ACCESS_TOKEN]: '' }, (data) => {
      const token =
        typeof data[STORAGE_KEY_AVVALE_ACCESS_TOKEN] === 'string'
          ? data[STORAGE_KEY_AVVALE_ACCESS_TOKEN].trim()
          : '';
      if (!token) {
        resolve({ ok: false, needsLogin: true, error: 'Inicia sesión para sincronizar.' });
        return;
      }
      avvaleApiFetchContacts(token).then((r) => {
        if (!r.ok) {
          resolve(r);
          return;
        }
        chrome.storage.local.set({ [STORAGE_KEY_AVVALE_CC_CONTACTS]: r.contacts }, () => {
          if (chrome.runtime.lastError) {
            resolve({ ok: false, error: chrome.runtime.lastError.message });
            return;
          }
          resolve({ ok: true, count: r.contacts.length });
        });
      });
    });
  });
}
