/**
 * Avvale Companion - Popup
 * Botón "Recopilar" que extrae datos del tab actual (HubSpot) y los muestra en un log.
 */

const STORAGE_KEY_ACTIVATION_ENV = 'activationEnvironment';
const STORAGE_KEY_SHOW_LOG_PREVIEW = 'showRecopilateLogPreview';
const STORAGE_KEY_LAST_RECOPILATED = 'lastRecopilatedData';
const STORAGE_KEY_ANTHROPIC_API_KEY = 'anthropicApiKey';
const STORAGE_KEY_ANTHROPIC_MODEL = 'anthropicModel';
/** Solo email recordado para el formulario; la contraseña no se persiste. */
const STORAGE_KEY_AVVALE_LOGIN_EMAIL = 'avvaleCompanionLoginEmail';
/** Cache de GET /api/contacts (misma clave que avvale-api-client.js). */
const STORAGE_KEY_AVVALE_CC_CONTACTS = 'avvaleCcContacts';

const logEl = document.getElementById('log');
const errorEl = document.getElementById('error');
const sendFeedbackEl = document.getElementById('sendFeedback');
const recopilarBtn = document.getElementById('recopilarBtn');
const enviarBtn = document.getElementById('enviarBtn');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('settingsPanel');
const launcherSection = document.querySelector('.launcher-section');
const activationEnvRadios = document.querySelectorAll('input[name="activationEnv"]');
const previewLogCheckbox = document.getElementById('previewLogCheckbox');
const recopilarLoadingEl = document.getElementById('recopilarLoading');
const anthropicApiKeyInput = document.getElementById('anthropicApiKeyInput');
const anthropicModelSelect = document.getElementById('anthropicModelSelect');
const companionApiEmailInput = document.getElementById('companionApiEmailInput');
const companionApiPasswordInput = document.getElementById('companionApiPasswordInput');
const companionApiLoginBtn = document.getElementById('companionApiLoginBtn');
const companionApiLogoutBtn = document.getElementById('companionApiLogoutBtn');
const companionApiSessionStatus = document.getElementById('companionApiSessionStatus');
const companionApiSessionPill = document.getElementById('companionApiSessionPill');
const companionApiContactsMeta = document.getElementById('companionApiContactsMeta');
const companionApiSyncBtn = document.getElementById('companionApiSyncBtn');
const companionApiViewContactsBtn = document.getElementById('companionApiViewContactsBtn');
const companionApiContactsPanel = document.getElementById('companionApiContactsPanel');
const companionApiContactsList = document.getElementById('companionApiContactsList');
const companionApiContactsEmpty = document.getElementById('companionApiContactsEmpty');
const companionApiContactsCloseBtn = document.getElementById('companionApiContactsCloseBtn');
const companionApiContactsSearch = document.getElementById('companionApiContactsSearch');
const companionApiContactsNoResults = document.getElementById('companionApiContactsNoResults');
const companionApiFeedback = document.getElementById('companionApiFeedback');
const launcherSessionText = document.getElementById('launcherSessionText');
const launcherLogoutBtn = document.getElementById('launcherLogoutBtn');
const launcherLoginBtn = document.getElementById('launcherLoginBtn');

let companionSessionActive = false;
let companionContactsPanelOpen = false;
/** Copia en memoria de contactos para filtrar en el buscador. */
let companionContactsCacheFull = [];

function setRecopilarLoading(visible) {
  if (!recopilarLoadingEl) return;
  recopilarLoadingEl.hidden = !visible;
  recopilarLoadingEl.classList.toggle('is-visible', visible);
}

/** 'dev' | 'pro' */
let currentActivationEnv = 'pro';
/** Mostrar el panel de log tras Recopilar */
let showLogPreview = true;
let anthropicApiKey = '';
/** 'sonnet' | 'haiku' | 'opus' */
let anthropicModel = 'haiku';

/** Datos de la última recopilación (temporales en memoria del popup). */
let lastRecopilatedData = null;
let lastRecopilatedTabId = null;

function formatLog(data) {
  return globalThis.AvvaleFormatLog(data);
}

function hideError() {
  errorEl.classList.remove('visible');
  errorEl.textContent = '';
}

function showError(msg) {
  errorEl.textContent = msg;
  errorEl.classList.add('visible');
}

function showLog(text) {
  logEl.textContent = text;
  logEl.classList.add('visible');
  logEl.classList.remove('empty');
  logEl.classList.remove('hidden-preview');
}

function applyLogPanelVisibility() {
  if (!showLogPreview) {
    logEl.classList.remove('visible');
    logEl.classList.add('hidden-preview');
    return;
  }
  logEl.classList.remove('hidden-preview');
  if (lastRecopilatedData) {
    showLog(formatLog(lastRecopilatedData));
  } else {
    logEl.classList.remove('visible');
    logEl.classList.add('empty');
    logEl.textContent = '';
  }
}

function getActivationsUrl() {
  return globalThis.AvvaleActivation.getActivationBaseUrl(currentActivationEnv);
}

const PIPELINE_DASHBOARD_URL = 'https://pipeline-ten-taupe.vercel.app/dashboard';

function getCompanionOriginForPopup() {
  return globalThis.AvvaleActivation.getCompanionOrigin(currentActivationEnv);
}

function getProfileAiCredentialsUrl() {
  return getCompanionOriginForPopup() + '/profile#perfil-ai-credentials';
}

function resolveLauncherTileUrl(tileId) {
  const origin = getCompanionOriginForPopup();
  switch (tileId) {
    case 'activations':
      return origin + '/launcher/activations/dashboard';
    case 'pipeline':
      return PIPELINE_DASHBOARD_URL;
    case 'yubiq':
      return origin + '/launcher/yubiq/approve-seal-filler';
    case 'rfqAnalysis':
      return origin + '/launcher/rfq-analysis';
    default:
      return origin + '/launcher';
  }
}

function hasAnthropicKeyConfigured() {
  return !!(anthropicApiKey && String(anthropicApiKey).trim());
}

/** Sesión Companion + bloqueo por API IA en mosaicos (solo si hay sesión). */
function refreshLauncherTilesState() {
  const loggedIn = companionSessionActive;
  const wrap = document.querySelector('.launcher-grid-wrap');
  if (wrap) wrap.classList.toggle('launcher-grid-wrap--no-session', !loggedIn);
  const overlay = document.getElementById('launcherGridLoginOverlay');
  if (overlay) overlay.hidden = !!loggedIn;

  if (!loggedIn) {
    document.querySelectorAll('#launcherGrid .launcher-tile__cta').forEach((c) => {
      c.disabled = true;
    });
    document.querySelectorAll('#launcherGrid .launcher-tile__profile-btn').forEach((b) => {
      b.hidden = true;
      b.disabled = true;
    });
    document.querySelectorAll('#launcherGrid [data-requires-anthropic="true"]').forEach((article) => {
      article.classList.remove('launcher-tile--locked');
      const hint = article.querySelector('.launcher-tile__lock-hint');
      if (hint) hint.hidden = true;
    });
    return;
  }

  document
    .querySelectorAll(
      '#launcherGrid [data-launcher-tile="activations"] .launcher-tile__cta, #launcherGrid [data-launcher-tile="pipeline"] .launcher-tile__cta',
    )
    .forEach((c) => {
      c.disabled = false;
    });

  const lockedAnthropic = !hasAnthropicKeyConfigured();
  document.querySelectorAll('[data-requires-anthropic="true"]').forEach((article) => {
    const cta = article.querySelector('.launcher-tile__cta');
    const hint = article.querySelector('.launcher-tile__lock-hint');
    const profileBtn = article.querySelector('.launcher-tile__profile-btn');
    article.classList.toggle('launcher-tile--locked', lockedAnthropic);
    if (cta) cta.disabled = lockedAnthropic;
    if (hint) hint.hidden = !lockedAnthropic;
    if (profileBtn) profileBtn.hidden = !lockedAnthropic;
  });
}

function openCompanionLoginInSettings() {
  if (!settingsPanel || !settingsBtn) return;
  settingsPanel.classList.add('visible');
  settingsBtn.setAttribute('aria-expanded', 'true');
  if (launcherSection) launcherSection.hidden = true;

  document.querySelectorAll('.settings-accordion__trigger').forEach((btn) => {
    const isSession = btn.id === 'accordion-session-trigger';
    btn.setAttribute('aria-expanded', isSession ? 'true' : 'false');
    const panel = document.getElementById(btn.getAttribute('aria-controls'));
    if (panel) panel.hidden = !isSession;
  });

  if (companionApiEmailInput) companionApiEmailInput.focus();
}

function openLauncherUrl(url) {
  chrome.tabs.create({ url });
}

const launcherGrid = document.getElementById('launcherGrid');
if (launcherGrid) {
  launcherGrid.addEventListener('click', (e) => {
    const profileBtn = e.target.closest('.launcher-tile__profile-btn');
    if (profileBtn && !profileBtn.hidden) {
      e.preventDefault();
      openLauncherUrl(getProfileAiCredentialsUrl());
      return;
    }
    const cta = e.target.closest('.launcher-tile__cta');
    if (!cta || cta.disabled) return;
    const tile = cta.closest('[data-launcher-tile]');
    const id = tile && tile.getAttribute('data-launcher-tile');
    if (!id) return;
    openLauncherUrl(resolveLauncherTileUrl(id));
  });
}

function syncRadiosFromEnv() {
  activationEnvRadios.forEach((radio) => {
    radio.checked = radio.value === currentActivationEnv;
  });
}

const ACCORDION_DEFAULTS = {
  hubspot: false,
  activation: false,
  anthropic: false,
  session: false,
  companion: false,
};

/** Todas las secciones cerradas (no se persiste en storage: cada apertura del popup parte así). */
function applyAccordionState() {
  const s = { ...ACCORDION_DEFAULTS };
  const pairs = [
    ['accordion-hubspot-trigger', 'accordion-hubspot-panel', 'hubspot'],
    ['accordion-activation-trigger', 'accordion-activation-panel', 'activation'],
    ['accordion-anthropic-trigger', 'accordion-anthropic-panel', 'anthropic'],
    ['accordion-session-trigger', 'accordion-session-panel', 'session'],
    ['accordion-companion-trigger', 'accordion-companion-panel', 'companion'],
  ];
  pairs.forEach(([tid, pid, key]) => {
    const tr = document.getElementById(tid);
    const pan = document.getElementById(pid);
    if (!tr || !pan) return;
    const open = !!s[key];
    tr.setAttribute('aria-expanded', open ? 'true' : 'false');
    pan.hidden = !open;
  });
}

function wireAccordionTriggers() {
  const triggers = document.querySelectorAll('.settings-accordion__trigger');
  triggers.forEach((btn) => {
    btn.addEventListener('click', () => {
      const wasOpen = btn.getAttribute('aria-expanded') === 'true';
      const panelId = btn.getAttribute('aria-controls');
      const panel = panelId ? document.getElementById(panelId) : null;

      if (wasOpen) {
        btn.setAttribute('aria-expanded', 'false');
        if (panel) panel.hidden = true;
      } else {
        triggers.forEach((other) => {
          const otherPanelId = other.getAttribute('aria-controls');
          const otherPanel = otherPanelId ? document.getElementById(otherPanelId) : null;
          const isClicked = other === btn;
          other.setAttribute('aria-expanded', isClicked ? 'true' : 'false');
          if (otherPanel) otherPanel.hidden = !isClicked;
        });
      }
    });
  });
}

function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      {
        [STORAGE_KEY_ACTIVATION_ENV]: 'pro',
        [STORAGE_KEY_SHOW_LOG_PREVIEW]: true,
        [STORAGE_KEY_ANTHROPIC_API_KEY]: '',
        [STORAGE_KEY_ANTHROPIC_MODEL]: 'haiku',
        [STORAGE_KEY_AVVALE_LOGIN_EMAIL]: '',
      },
      (data) => {
        currentActivationEnv = data[STORAGE_KEY_ACTIVATION_ENV] === 'pro' ? 'pro' : 'dev';
        showLogPreview = !!data[STORAGE_KEY_SHOW_LOG_PREVIEW];
        anthropicApiKey = typeof data[STORAGE_KEY_ANTHROPIC_API_KEY] === 'string' ? data[STORAGE_KEY_ANTHROPIC_API_KEY] : '';
        anthropicModel =
          data[STORAGE_KEY_ANTHROPIC_MODEL] === 'opus'
          ? 'opus'
          : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'haiku'
            ? 'haiku'
            : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'sonnet'
              ? 'sonnet'
              : 'haiku';
        syncRadiosFromEnv();
        if (previewLogCheckbox) previewLogCheckbox.checked = showLogPreview;
        if (anthropicApiKeyInput) anthropicApiKeyInput.value = anthropicApiKey ? '••••••••' : '';
        if (anthropicModelSelect) anthropicModelSelect.value = anthropicModel;
        const savedEmail =
          typeof data[STORAGE_KEY_AVVALE_LOGIN_EMAIL] === 'string' ? data[STORAGE_KEY_AVVALE_LOGIN_EMAIL].trim() : '';
        if (companionApiEmailInput && savedEmail) companionApiEmailInput.value = savedEmail;
        applyAccordionState();
        applyLogPanelVisibility();
        refreshLauncherTilesState();
        resolve();
      }
    );
  });
}

function loadRecopilatedFromStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [STORAGE_KEY_LAST_RECOPILATED]: null }, (data) => {
      const payload = data[STORAGE_KEY_LAST_RECOPILATED];
      if (payload && typeof payload === 'object') {
        lastRecopilatedData = payload;
        enviarBtn.disabled = false;
        if (showLogPreview) {
          showLog(formatLog(payload));
        } else {
          logEl.classList.remove('visible');
          logEl.classList.add('empty');
          logEl.textContent = '';
          logEl.classList.add('hidden-preview');
        }
      }
      resolve();
    });
  });
}

function persistLastRecopilated(data) {
  chrome.storage.local.set({ [STORAGE_KEY_LAST_RECOPILATED]: data });
}

function saveActivationEnv(env) {
  currentActivationEnv = env === 'pro' ? 'pro' : 'dev';
  chrome.storage.local.set({ [STORAGE_KEY_ACTIVATION_ENV]: currentActivationEnv });
  syncRadiosFromEnv();
}

function saveLogPreview(checked) {
  showLogPreview = !!checked;
  chrome.storage.local.set({ [STORAGE_KEY_SHOW_LOG_PREVIEW]: showLogPreview });
  if (previewLogCheckbox) previewLogCheckbox.checked = showLogPreview;
  applyLogPanelVisibility();
}

function saveAnthropicApiKey(value) {
  anthropicApiKey = typeof value === 'string' ? value.trim() : '';
  chrome.storage.local.set({ [STORAGE_KEY_ANTHROPIC_API_KEY]: anthropicApiKey });
  refreshLauncherTilesState();
}

function saveAnthropicModel(value) {
  anthropicModel =
    value === 'opus' ? 'opus'
    : value === 'sonnet' ? 'sonnet'
    : 'haiku';
  chrome.storage.local.set({ [STORAGE_KEY_ANTHROPIC_MODEL]: anthropicModel });
  if (anthropicModelSelect) anthropicModelSelect.value = anthropicModel;
}

wireAccordionTriggers();

settingsBtn.addEventListener('click', () => {
  const open = !settingsPanel.classList.contains('visible');
  settingsPanel.classList.toggle('visible', open);
  settingsBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
  if (launcherSection) launcherSection.hidden = open;
});

activationEnvRadios.forEach((radio) => {
  radio.addEventListener('change', () => {
    if (radio.checked) saveActivationEnv(radio.value);
  });
});

if (previewLogCheckbox) {
  previewLogCheckbox.addEventListener('change', () => {
    saveLogPreview(previewLogCheckbox.checked);
  });
}

if (anthropicApiKeyInput) {
  anthropicApiKeyInput.addEventListener('focus', () => {
    // Al enfocar, mostramos el valor real para que pueda editarlo.
    chrome.storage.local.get({ [STORAGE_KEY_ANTHROPIC_API_KEY]: '' }, (data) => {
      const v = typeof data[STORAGE_KEY_ANTHROPIC_API_KEY] === 'string' ? data[STORAGE_KEY_ANTHROPIC_API_KEY] : '';
      anthropicApiKeyInput.value = v;
      anthropicApiKeyInput.select?.();
    });
  });
  anthropicApiKeyInput.addEventListener('blur', () => {
    saveAnthropicApiKey(anthropicApiKeyInput.value);
    anthropicApiKeyInput.value = anthropicApiKeyInput.value.trim() ? '••••••••' : '';
  });
}

if (anthropicModelSelect) {
  anthropicModelSelect.addEventListener('change', () => {
    saveAnthropicModel(anthropicModelSelect.value);
  });
}

function setCompanionApiFeedback(msg, isError) {
  if (!companionApiFeedback) return;
  companionApiFeedback.textContent = msg || '';
  companionApiFeedback.style.color = isError ? '#c62828' : '#757575';
}

function updateCompanionApiSessionUI(resp) {
  const loggedIn = !!(resp && resp.ok && resp.loggedIn);
  companionSessionActive = loggedIn;
  const u = resp && typeof resp.userEmail === 'string' ? resp.userEmail.trim() : '';
  if (companionApiSessionStatus) {
    companionApiSessionStatus.textContent = loggedIn
      ? `Sesión activa${u ? `: ${u}` : ''}`
      : 'Sin sesión';
  }
  if (companionApiSessionPill) {
    companionApiSessionPill.classList.toggle('session-pill--ok', loggedIn);
    companionApiSessionPill.classList.toggle('session-pill--off', !loggedIn);
  }
  if (companionApiLogoutBtn) companionApiLogoutBtn.hidden = !loggedIn;
  if (companionApiSyncBtn) companionApiSyncBtn.disabled = !loggedIn;
  if (launcherSessionText) {
    launcherSessionText.textContent = loggedIn
      ? (u ? `Sesión activa: ${u}` : 'Sesión activa')
      : 'Sin sesión activa';
  }
  if (launcherLogoutBtn) launcherLogoutBtn.hidden = !loggedIn;
  refreshLauncherTilesState();
}

function renderContactsListFromCache() {
  if (!companionApiContactsList || !companionApiContactsEmpty || !companionApiContactsNoResults) return;
  companionApiContactsList.innerHTML = '';
  const q =
    companionApiContactsSearch && companionApiContactsSearch.value
      ? companionApiContactsSearch.value.trim().toLowerCase()
      : '';
  const total = companionContactsCacheFull.length;
  if (total === 0) {
    companionApiContactsEmpty.hidden = false;
    companionApiContactsNoResults.hidden = true;
    return;
  }
  companionApiContactsEmpty.hidden = true;
  let list = companionContactsCacheFull.slice();
  if (q) {
    list = list.filter((c) => {
      const name = c && c.name ? String(c.name).toLowerCase() : '';
      const email = c && c.email ? String(c.email).toLowerCase() : '';
      return name.includes(q) || email.includes(q);
    });
  }
  if (list.length === 0) {
    companionApiContactsNoResults.hidden = false;
    return;
  }
  companionApiContactsNoResults.hidden = true;
  const sorted = list.sort((a, b) => {
    const an = (a && a.name ? String(a.name) : '') || (a && a.email ? String(a.email) : '');
    const bn = (b && b.name ? String(b.name) : '') || (b && b.email ? String(b.email) : '');
    return an.localeCompare(bn, 'es');
  });
  sorted.forEach((c) => {
    const row = document.createElement('div');
    row.className = 'contact-row';
    row.setAttribute('role', 'listitem');
    const main = document.createElement('div');
    const nameEl = document.createElement('div');
    nameEl.className = 'contact-row__name';
    const name = c && typeof c.name === 'string' ? c.name.trim() : '';
    nameEl.textContent = name || '—';
    const emailEl = document.createElement('div');
    emailEl.className = 'contact-row__email';
    emailEl.textContent = c && typeof c.email === 'string' ? c.email.trim() : '';
    main.appendChild(nameEl);
    main.appendChild(emailEl);
    row.appendChild(main);
    const aside = document.createElement('div');
    if (c && c.isProjectJp) {
      const badge = document.createElement('span');
      badge.className = 'contact-badge';
      badge.textContent = 'JP';
      badge.title = 'Proyecto JP';
      aside.appendChild(badge);
    }
    row.appendChild(aside);
    companionApiContactsList.appendChild(row);
  });
}

function refreshContactsMeta() {
  chrome.storage.local.get({ [STORAGE_KEY_AVVALE_CC_CONTACTS]: null }, (data) => {
    const raw = data[STORAGE_KEY_AVVALE_CC_CONTACTS];
    companionContactsCacheFull = Array.isArray(raw) ? raw : [];
    const n = companionContactsCacheFull.length;
    if (companionApiContactsMeta) {
      companionApiContactsMeta.textContent =
        n === 0
          ? 'Ningún contacto en caché. Sincroniza tras iniciar sesión.'
          : `${n} contacto${n === 1 ? '' : 's'} en caché (local).`;
    }
    if (companionContactsPanelOpen) {
      renderContactsListFromCache();
    }
  });
}

function setContactsPanelOpen(open) {
  companionContactsPanelOpen = !!open;
  if (!companionApiContactsPanel || !companionApiViewContactsBtn) return;
  companionApiContactsPanel.hidden = !companionContactsPanelOpen;
  companionApiViewContactsBtn.setAttribute('aria-expanded', companionContactsPanelOpen ? 'true' : 'false');
  companionApiViewContactsBtn.textContent = companionContactsPanelOpen ? 'Ocultar lista' : 'Ver contactos';
  if (companionContactsPanelOpen) {
    chrome.storage.local.get({ [STORAGE_KEY_AVVALE_CC_CONTACTS]: null }, (data) => {
      const raw = data[STORAGE_KEY_AVVALE_CC_CONTACTS];
      companionContactsCacheFull = Array.isArray(raw) ? raw : [];
      renderContactsListFromCache();
    });
  } else if (companionApiContactsSearch) {
    companionApiContactsSearch.value = '';
  }
}

try {
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName !== 'local' || !changes[STORAGE_KEY_AVVALE_CC_CONTACTS]) return;
    refreshContactsMeta();
  });
} catch (_) {}

function refreshCompanionSession() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: 'AVVALE_API_GET_SESSION' }, (resp) => {
      if (chrome.runtime.lastError) {
        updateCompanionApiSessionUI({ ok: false, loggedIn: false, userEmail: '' });
        resolve();
        return;
      }
      updateCompanionApiSessionUI(resp);
      resolve();
    });
  });
}

if (companionApiEmailInput) {
  companionApiEmailInput.addEventListener('blur', () => {
    const v = companionApiEmailInput.value.trim();
    chrome.storage.local.set({ [STORAGE_KEY_AVVALE_LOGIN_EMAIL]: v });
  });
}

if (companionApiLoginBtn) {
  companionApiLoginBtn.addEventListener('click', () => {
    setCompanionApiFeedback('');
    const email = companionApiEmailInput ? companionApiEmailInput.value.trim() : '';
    const password = companionApiPasswordInput ? companionApiPasswordInput.value : '';
    if (!email || !password) {
      setCompanionApiFeedback('Introduce email y contraseña.', true);
      return;
    }
    companionApiLoginBtn.disabled = true;
    chrome.storage.local.set({ [STORAGE_KEY_AVVALE_LOGIN_EMAIL]: email }, () => {
      chrome.runtime.sendMessage({ type: 'AVVALE_API_LOGIN', email, password }, (resp) => {
        companionApiLoginBtn.disabled = false;
        if (companionApiPasswordInput) companionApiPasswordInput.value = '';
        if (chrome.runtime.lastError) {
          setCompanionApiFeedback(chrome.runtime.lastError.message, true);
          return;
        }
        if (resp && resp.ok) {
          setCompanionApiFeedback('Sesión iniciada correctamente.');
          refreshCompanionSession();
          return;
        }
        setCompanionApiFeedback((resp && resp.error) || 'No se pudo iniciar sesión.', true);
      });
    });
  });
}

function handleCompanionLogout() {
  setCompanionApiFeedback('');
  if (companionApiLogoutBtn) companionApiLogoutBtn.disabled = true;
  if (launcherLogoutBtn) launcherLogoutBtn.disabled = true;
  chrome.runtime.sendMessage({ type: 'AVVALE_API_LOGOUT' }, () => {
    if (companionApiLogoutBtn) companionApiLogoutBtn.disabled = false;
    if (launcherLogoutBtn) launcherLogoutBtn.disabled = false;
    refreshCompanionSession();
    setCompanionApiFeedback('Sesión cerrada.');
  });
}

if (companionApiLogoutBtn) {
  companionApiLogoutBtn.addEventListener('click', handleCompanionLogout);
}
if (launcherLogoutBtn) {
  launcherLogoutBtn.addEventListener('click', handleCompanionLogout);
}
if (launcherLoginBtn) {
  launcherLoginBtn.addEventListener('click', () => openCompanionLoginInSettings());
}

if (companionApiViewContactsBtn) {
  companionApiViewContactsBtn.addEventListener('click', () => {
    setContactsPanelOpen(!companionContactsPanelOpen);
  });
}

if (companionApiContactsCloseBtn) {
  companionApiContactsCloseBtn.addEventListener('click', () => {
    setContactsPanelOpen(false);
  });
}

if (companionApiContactsSearch) {
  companionApiContactsSearch.addEventListener('input', () => {
    renderContactsListFromCache();
  });
}

if (companionApiSyncBtn) {
  companionApiSyncBtn.addEventListener('click', () => {
    setCompanionApiFeedback('');
    if (!companionSessionActive) {
      setCompanionApiFeedback('Inicia sesión primero.', true);
      return;
    }
    companionApiSyncBtn.disabled = true;
    chrome.runtime.sendMessage({ type: 'AVVALE_API_SYNC_CONTACTS' }, (resp) => {
      const finish = () => {
        if (companionApiSyncBtn) companionApiSyncBtn.disabled = !companionSessionActive;
      };
      if (chrome.runtime.lastError) {
        setCompanionApiFeedback(chrome.runtime.lastError.message, true);
        finish();
        return;
      }
      if (resp && resp.needsLogin) {
        setCompanionApiFeedback((resp && resp.error) || 'Vuelve a iniciar sesión.', true);
        refreshCompanionSession().then(finish);
        return;
      }
      if (resp && resp.ok && typeof resp.count === 'number') {
        setCompanionApiFeedback(`${resp.count} contactos guardados.`);
        refreshContactsMeta();
        finish();
        return;
      }
      setCompanionApiFeedback((resp && resp.error) || 'Error al sincronizar.', true);
      finish();
    });
  });
}

loadSettings()
  .then(() => loadRecopilatedFromStorage())
  .then(() => refreshCompanionSession())
  .then(() => {
    refreshContactsMeta();
  });

recopilarBtn.addEventListener('click', async () => {
  hideError();
  hideSendFeedback();
  recopilarBtn.disabled = true;
  setRecopilarLoading(true);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showError('No se pudo obtener la pestaña actual.');
      return;
    }
    if (!tab.url || !tab.url.startsWith('https://app.hubspot.com/')) {
      showError('Abre una página de HubSpot (app.hubspot.com) y vuelve a pulsar Recopilar.');
      return;
    }

    // Recordar la pestaña de HubSpot sobre la que se ha hecho la recopilación
    lastRecopilatedTabId = tab.id;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['extract.js'],
    });

    if (chrome.runtime.lastError) {
      showError(chrome.runtime.lastError.message || 'Error al ejecutar el script.');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () =>
        typeof globalThis.extractInPageAfterSidebarPrep === 'function'
          ? globalThis.extractInPageAfterSidebarPrep()
          : Promise.resolve(
              typeof globalThis.extractInPage === 'function' ? globalThis.extractInPage() : null
            ),
    });

    if (chrome.runtime.lastError) {
      showError(chrome.runtime.lastError.message || 'Error al ejecutar el script.');
      return;
    }

    const data = results?.[0]?.result;
    if (!data) {
      showError('No se obtuvieron datos.');
      return;
    }

    lastRecopilatedData = data;
    persistLastRecopilated(data);
    if (showLogPreview) {
      showLog(formatLog(data));
    } else {
      logEl.classList.remove('visible');
      logEl.classList.add('empty');
      logEl.textContent = '';
      logEl.classList.add('hidden-preview');
    }
    enviarBtn.disabled = false;
    showSendFeedback('Recopilado.');
  } catch (e) {
    showError(e.message || 'Error inesperado.');
  } finally {
    setRecopilarLoading(false);
    recopilarBtn.disabled = false;
  }
});

function hideSendFeedback() {
  sendFeedbackEl.textContent = '';
  sendFeedbackEl.className = '';
  sendFeedbackEl.classList.remove('visible', 'success', 'error');
}

function showSendFeedback(msg, isError) {
  sendFeedbackEl.textContent = msg;
  sendFeedbackEl.className = isError ? 'error' : 'success';
  sendFeedbackEl.classList.add('visible');
}

enviarBtn.addEventListener('click', () => {
  hideError();
  hideSendFeedback();

  if (!lastRecopilatedData) {
    showSendFeedback('Primero pulsa Recopilar para obtener los datos.', true);
    return;
  }

  try {
    const url =
      getActivationsUrl() + '#' + globalThis.AvvaleActivation.toBase64Url(lastRecopilatedData);
    chrome.tabs.create({ url });
    showSendFeedback(`Pestaña abierta (${currentActivationEnv === 'pro' ? 'PRO' : 'DEV'}).`);

    if (typeof lastRecopilatedTabId === 'number') {
      setTimeout(() => {
        chrome.tabs.reload(lastRecopilatedTabId, () => {
          // Si el usuario cerró o cambió la pestaña, ignorar.
        });
      }, 2000);
    }
  } catch (e) {
    showSendFeedback(e.message || 'Error al abrir la pestaña.', true);
  }
});

// Yubiq — autofill (JSON) eliminado del popup por simplicidad.

