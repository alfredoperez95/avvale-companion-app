/**
 * Avvale Companion - Popup
 * Botón "Recopilar" que extrae datos del tab actual (HubSpot) y los muestra en un log.
 */

const STORAGE_KEY_ACTIVATION_ENV = 'activationEnvironment';
const STORAGE_KEY_SHOW_LOG_PREVIEW = 'showRecopilateLogPreview';
const STORAGE_KEY_LAST_RECOPILATED = 'lastRecopilatedData';
const STORAGE_KEY_ANTHROPIC_API_KEY = 'anthropicApiKey';
const STORAGE_KEY_ANTHROPIC_MODEL = 'anthropicModel';

const logEl = document.getElementById('log');
const errorEl = document.getElementById('error');
const sendFeedbackEl = document.getElementById('sendFeedback');
const recopilarBtn = document.getElementById('recopilarBtn');
const enviarBtn = document.getElementById('enviarBtn');
const settingsBtn = document.getElementById('settingsBtn');
const settingsPanel = document.getElementById('settingsPanel');
const activationEnvRadios = document.querySelectorAll('input[name="activationEnv"]');
const previewLogCheckbox = document.getElementById('previewLogCheckbox');
const recopilarLoadingEl = document.getElementById('recopilarLoading');
const anthropicApiKeyInput = document.getElementById('anthropicApiKeyInput');
const anthropicModelSelect = document.getElementById('anthropicModelSelect');

function setRecopilarLoading(visible) {
  if (!recopilarLoadingEl) return;
  recopilarLoadingEl.hidden = !visible;
  recopilarLoadingEl.classList.toggle('is-visible', visible);
}

/** 'dev' | 'pro' */
let currentActivationEnv = 'pro';
/** Mostrar el panel de log tras Recopilar */
let showLogPreview = true;
let anthropicApiKey = '';
/** 'sonnet' | 'haiku' | 'opus' */
let anthropicModel = 'haiku';

/** Datos de la última recopilación (temporales en memoria del popup). */
let lastRecopilatedData = null;
let lastRecopilatedTabId = null;

function formatLog(data) {
  return globalThis.AvvaleFormatLog(data);
}

function hideError() {
  errorEl.classList.remove('visible');
  errorEl.textContent = '';
}

function showError(msg) {
  errorEl.textContent = msg;
  errorEl.classList.add('visible');
}

function showLog(text) {
  logEl.textContent = text;
  logEl.classList.add('visible');
  logEl.classList.remove('empty');
  logEl.classList.remove('hidden-preview');
}

function applyLogPanelVisibility() {
  if (!showLogPreview) {
    logEl.classList.remove('visible');
    logEl.classList.add('hidden-preview');
    return;
  }
  logEl.classList.remove('hidden-preview');
  if (lastRecopilatedData) {
    showLog(formatLog(lastRecopilatedData));
  } else {
    logEl.classList.remove('visible');
    logEl.classList.add('empty');
    logEl.textContent = '';
  }
}

function getActivationsUrl() {
  return globalThis.AvvaleActivation.getActivationBaseUrl(currentActivationEnv);
}

function syncRadiosFromEnv() {
  activationEnvRadios.forEach((radio) => {
    radio.checked = radio.value === currentActivationEnv;
  });
}

function loadSettings() {
  return new Promise((resolve) => {
    chrome.storage.local.get(
      {
        [STORAGE_KEY_ACTIVATION_ENV]: 'pro',
        [STORAGE_KEY_SHOW_LOG_PREVIEW]: true,
        [STORAGE_KEY_ANTHROPIC_API_KEY]: '',
        [STORAGE_KEY_ANTHROPIC_MODEL]: 'haiku',
      },
      (data) => {
        currentActivationEnv = data[STORAGE_KEY_ACTIVATION_ENV] === 'pro' ? 'pro' : 'dev';
        showLogPreview = !!data[STORAGE_KEY_SHOW_LOG_PREVIEW];
        anthropicApiKey = typeof data[STORAGE_KEY_ANTHROPIC_API_KEY] === 'string' ? data[STORAGE_KEY_ANTHROPIC_API_KEY] : '';
        anthropicModel =
          data[STORAGE_KEY_ANTHROPIC_MODEL] === 'opus'
          ? 'opus'
          : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'haiku'
            ? 'haiku'
            : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'sonnet'
              ? 'sonnet'
              : 'haiku';
        syncRadiosFromEnv();
        if (previewLogCheckbox) previewLogCheckbox.checked = showLogPreview;
        if (anthropicApiKeyInput) anthropicApiKeyInput.value = anthropicApiKey ? '••••••••' : '';
        if (anthropicModelSelect) anthropicModelSelect.value = anthropicModel;
        applyLogPanelVisibility();
        resolve();
      }
    );
  });
}

function loadRecopilatedFromStorage() {
  return new Promise((resolve) => {
    chrome.storage.local.get({ [STORAGE_KEY_LAST_RECOPILATED]: null }, (data) => {
      const payload = data[STORAGE_KEY_LAST_RECOPILATED];
      if (payload && typeof payload === 'object') {
        lastRecopilatedData = payload;
        enviarBtn.disabled = false;
        if (showLogPreview) {
          showLog(formatLog(payload));
        } else {
          logEl.classList.remove('visible');
          logEl.classList.add('empty');
          logEl.textContent = '';
          logEl.classList.add('hidden-preview');
        }
      }
      resolve();
    });
  });
}

function persistLastRecopilated(data) {
  chrome.storage.local.set({ [STORAGE_KEY_LAST_RECOPILATED]: data });
}

function saveActivationEnv(env) {
  currentActivationEnv = env === 'pro' ? 'pro' : 'dev';
  chrome.storage.local.set({ [STORAGE_KEY_ACTIVATION_ENV]: currentActivationEnv });
  syncRadiosFromEnv();
}

function saveLogPreview(checked) {
  showLogPreview = !!checked;
  chrome.storage.local.set({ [STORAGE_KEY_SHOW_LOG_PREVIEW]: showLogPreview });
  if (previewLogCheckbox) previewLogCheckbox.checked = showLogPreview;
  applyLogPanelVisibility();
}

function saveAnthropicApiKey(value) {
  anthropicApiKey = typeof value === 'string' ? value.trim() : '';
  chrome.storage.local.set({ [STORAGE_KEY_ANTHROPIC_API_KEY]: anthropicApiKey });
}

function saveAnthropicModel(value) {
  anthropicModel =
    value === 'opus' ? 'opus'
    : value === 'sonnet' ? 'sonnet'
    : 'haiku';
  chrome.storage.local.set({ [STORAGE_KEY_ANTHROPIC_MODEL]: anthropicModel });
  if (anthropicModelSelect) anthropicModelSelect.value = anthropicModel;
}

settingsBtn.addEventListener('click', () => {
  const open = !settingsPanel.classList.contains('visible');
  settingsPanel.classList.toggle('visible', open);
  settingsBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
});

activationEnvRadios.forEach((radio) => {
  radio.addEventListener('change', () => {
    if (radio.checked) saveActivationEnv(radio.value);
  });
});

if (previewLogCheckbox) {
  previewLogCheckbox.addEventListener('change', () => {
    saveLogPreview(previewLogCheckbox.checked);
  });
}

if (anthropicApiKeyInput) {
  anthropicApiKeyInput.addEventListener('focus', () => {
    // Al enfocar, mostramos el valor real para que pueda editarlo.
    chrome.storage.local.get({ [STORAGE_KEY_ANTHROPIC_API_KEY]: '' }, (data) => {
      const v = typeof data[STORAGE_KEY_ANTHROPIC_API_KEY] === 'string' ? data[STORAGE_KEY_ANTHROPIC_API_KEY] : '';
      anthropicApiKeyInput.value = v;
      anthropicApiKeyInput.select?.();
    });
  });
  anthropicApiKeyInput.addEventListener('blur', () => {
    saveAnthropicApiKey(anthropicApiKeyInput.value);
    anthropicApiKeyInput.value = anthropicApiKeyInput.value.trim() ? '••••••••' : '';
  });
}

if (anthropicModelSelect) {
  anthropicModelSelect.addEventListener('change', () => {
    saveAnthropicModel(anthropicModelSelect.value);
  });
}

loadSettings().then(() => loadRecopilatedFromStorage());

recopilarBtn.addEventListener('click', async () => {
  hideError();
  hideSendFeedback();
  recopilarBtn.disabled = true;
  setRecopilarLoading(true);

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) {
      showError('No se pudo obtener la pestaña actual.');
      return;
    }
    if (!tab.url || !tab.url.startsWith('https://app.hubspot.com/')) {
      showError('Abre una página de HubSpot (app.hubspot.com) y vuelve a pulsar Recopilar.');
      return;
    }

    // Recordar la pestaña de HubSpot sobre la que se ha hecho la recopilación
    lastRecopilatedTabId = tab.id;

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['extract.js'],
    });

    if (chrome.runtime.lastError) {
      showError(chrome.runtime.lastError.message || 'Error al ejecutar el script.');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () =>
        typeof globalThis.extractInPageAfterSidebarPrep === 'function'
          ? globalThis.extractInPageAfterSidebarPrep()
          : Promise.resolve(
              typeof globalThis.extractInPage === 'function' ? globalThis.extractInPage() : null
            ),
    });

    if (chrome.runtime.lastError) {
      showError(chrome.runtime.lastError.message || 'Error al ejecutar el script.');
      return;
    }

    const data = results?.[0]?.result;
    if (!data) {
      showError('No se obtuvieron datos.');
      return;
    }

    lastRecopilatedData = data;
    persistLastRecopilated(data);
    if (showLogPreview) {
      showLog(formatLog(data));
    } else {
      logEl.classList.remove('visible');
      logEl.classList.add('empty');
      logEl.textContent = '';
      logEl.classList.add('hidden-preview');
    }
    enviarBtn.disabled = false;
    showSendFeedback('Recopilado.');
  } catch (e) {
    showError(e.message || 'Error inesperado.');
  } finally {
    setRecopilarLoading(false);
    recopilarBtn.disabled = false;
  }
});

function hideSendFeedback() {
  sendFeedbackEl.textContent = '';
  sendFeedbackEl.className = '';
  sendFeedbackEl.classList.remove('visible', 'success', 'error');
}

function showSendFeedback(msg, isError) {
  sendFeedbackEl.textContent = msg;
  sendFeedbackEl.className = isError ? 'error' : 'success';
  sendFeedbackEl.classList.add('visible');
}

enviarBtn.addEventListener('click', () => {
  hideError();
  hideSendFeedback();

  if (!lastRecopilatedData) {
    showSendFeedback('Primero pulsa Recopilar para obtener los datos.', true);
    return;
  }

  try {
    const url =
      getActivationsUrl() + '#' + globalThis.AvvaleActivation.toBase64Url(lastRecopilatedData);
    chrome.tabs.create({ url });
    showSendFeedback(`Pestaña abierta (${currentActivationEnv === 'pro' ? 'PRO' : 'DEV'}).`);

    if (typeof lastRecopilatedTabId === 'number') {
      setTimeout(() => {
        chrome.tabs.reload(lastRecopilatedTabId, () => {
          // Si el usuario cerró o cambió la pestaña, ignorar.
        });
      }, 2000);
    }
  } catch (e) {
    showSendFeedback(e.message || 'Error al abrir la pestaña.', true);
  }
});

/** Yubiq: payload JSON → background guarda en storage y abre pestaña (sin HubSpot). */
const yubiqStartBtn = document.getElementById('yubiqStartBtn');
const yubiqPayloadJson = document.getElementById('yubiqPayloadJson');
const yubiqFeedback = document.getElementById('yubiqFeedback');

const DEFAULT_YUBIQ_PAYLOAD = {
  schemaVersion: '1.0.0',
  target: 'yubiq_addnew',
  targetUrl: 'https://avvale-aes-y5ui.yubiq.app/YUBIK/home#addnew',
  generatedAt: new Date().toISOString(),
  document: {
    fileName: '',
    title: '',
    client: '',
    summary: '',
    amount: '',
    currency: '',
    regulatedArea: '',
  },
  prefill: {
    title: 'Ejemplo título',
    description: 'Ejemplo descripción',
    toBeSigned: '',
    documentType: 'offer',
    customerName: 'Cliente demo',
    company: 'espana',
    segment: 'YUBIQ',
    revenue: '1000',
  },
};

function setYubiqFeedback(msg, isError) {
  if (!yubiqFeedback) return;
  yubiqFeedback.textContent = msg;
  yubiqFeedback.className = isError ? 'visible err' : 'visible ok';
}

if (yubiqPayloadJson && !yubiqPayloadJson.value.trim()) {
  yubiqPayloadJson.value = JSON.stringify(DEFAULT_YUBIQ_PAYLOAD, null, 2);
}

yubiqStartBtn?.addEventListener('click', () => {
  if (!yubiqPayloadJson) return;
  let payload;
  try {
    payload = JSON.parse(yubiqPayloadJson.value);
  } catch (e) {
    setYubiqFeedback(`JSON inválido: ${e.message}`, true);
    return;
  }
  chrome.runtime.sendMessage({ type: 'YUBIQ_START_AUTOFILL', payload }, (resp) => {
    if (chrome.runtime.lastError) {
      setYubiqFeedback(chrome.runtime.lastError.message, true);
      return;
    }
    if (resp && resp.ok) {
      setYubiqFeedback(`Pestaña abierta (tab ${resp.tabId ?? '?' }). Revisa Yubiq y la consola de la página.`, false);
    } else {
      setYubiqFeedback(resp?.error || 'Error desconocido', true);
    }
  });
});

