/**
 * Extrae datos del record HubSpot actual (DOM).
 * Expuesto en globalThis para popup (executeScript) y content script.
 */
globalThis.extractInPage = function extractInPage() {
  const getText = (selector, useValue = false) => {
    const el = document.querySelector(selector);
    if (!el) return '';
    return (useValue ? el.value : (el.innerText || '')).trim();
  };

  const projectName = getText('[data-test-id="highlight-property-display-dealname"]');
  const offerCode = getText('textarea[data-selenium-test="property-input-offer_code__c"]', true);
  const projectManagerEmail = getText('textarea[data-selenium-test="property-input-project_manager_email"]', true);
  const hubspotUrl = window.location.href;

  let client = getText('[data-selenium-test="company-chicklet-title-link"]')
    || getText('[data-test-id="company-chicklet-title-link"]')
    || getText('[data-test-id="property-input-name"]');

  const amount = getText('[data-test-id="line-items-card-line-item-name-price"]')
    || getText('[data-test-id="currency-component"]');

  const serviceType = getText('[data-test-id="table-cell-wrapper-2-0"]');

  const attachmentLinks = document.querySelectorAll('a[data-test-id="attachments-card-file-attachment-link"]');
  const baseOrigin = window.location.origin;
  const attachmentUrls = [];
  const attachmentNames = [];
  const re = /\/file-preview\/(\d+)\/file\/(\d+)\/?/;

  attachmentLinks.forEach(function (a) {
    const href = (a.getAttribute('href') || '').trim();
    if (!href) return;
    const fullHref = href.startsWith('http') ? href : baseOrigin + (href.startsWith('/') ? href : '/' + href);
    const m = fullHref.match(re);

    if (m) {
      const portalId = m[1];
      const fileId = m[2];
      attachmentUrls.push(
        baseOrigin + '/api/filemanager/api/v2/files/' + fileId + '/signed-url-redirect?portalId=' + portalId + '&response-content-disposition=attachment'
      );
      const name = (a.innerText || a.textContent || '').trim();
      attachmentNames.push(name || '');
    }
  });

  return {
    projectName,
    offerCode,
    projectManagerEmail,
    hubspotUrl,
    client,
    amount,
    serviceType,
    attachmentUrls,
    attachmentNames,
  };
};

/** Panel derecho CRM y contenedores internos con scroll. */
var AVVALE_SIDEBAR_SELECTOR = '[data-scroll-trackable-container="right-sidebar"]';
var AVVALE_SIDEBAR_PREP_DELAY_MS = 3000;
/** Card de adjuntos dentro del sidebar derecho. */
var AVVALE_ATTACHMENTS_CARD_WRAPPER_SEL =
  '[data-test-id="card-wrapper-SINGLETON/0-3/ATTACHMENTS"], #card-wrapper-SINGLETON\\/0-3\\/ATTACHMENTS';

function isElementVisible(el) {
  if (!el || !el.isConnected) return false;
  var style = window.getComputedStyle(el);
  if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) return false;
  var rect = el.getBoundingClientRect();
  if (rect.width === 0 && rect.height === 0) return false;
  return true;
}

/**
 * Intenta expandir el listado de adjuntos pulsando "Mostrar más" en la tarjeta de adjuntos.
 * HubSpot puede renderizar esta acción como i18n-string (recordAttachmentsCard.showMore).
 */
function tryClickAttachmentsShowMore() {
  var wrap = document.querySelector(AVVALE_ATTACHMENTS_CARD_WRAPPER_SEL);
  if (!wrap) return false;
  var btn = wrap.querySelector('button:has(i18n-string[data-key="recordAttachmentsCard.showMore"])');
  if (!btn) {
    // Fallback: buscar por texto (ES) si el selector :has no está disponible.
    var buttons = wrap.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i++) {
      var b = buttons[i];
      var t = (b.innerText || b.textContent || '').replace(/\s+/g, ' ').trim();
      if (/^mostrar\s+m[aá]s$/i.test(t)) {
        btn = b;
        break;
      }
    }
  }
  if (!btn) return false;
  if (btn.getAttribute('aria-disabled') === 'true' || btn.disabled) return false;
  if (!isElementVisible(btn)) return false;
  try {
    btn.click();
    return true;
  } catch (_) {
    return false;
  }
}

function scrollElementToBottom(el) {
  if (!el || !el.scrollHeight) return;
  el.scrollTop = el.scrollHeight;
  try {
    el.scrollTo({ top: el.scrollHeight, behavior: 'auto' });
  } catch (_) {}
}

/**
 * Scroll profundo: panel principal + [data-scroll-container] + nodos con overflow scroll.
 */
function scrollRightSidebarDeep(sidebar) {
  if (!sidebar) return;
  scrollElementToBottom(sidebar);
  sidebar.querySelectorAll('[data-scroll-container="true"]').forEach(scrollElementToBottom);
  sidebar.querySelectorAll('[data-crm-location="CRM_RECORD_RIGHT"]').forEach(scrollElementToBottom);
  var nodes = sidebar.querySelectorAll('*');
  for (var i = 0; i < nodes.length; i++) {
    var node = nodes[i];
    if (node === sidebar) continue;
    var st = window.getComputedStyle(node);
    var oy = st.overflowY;
    if (
      (oy === 'auto' || oy === 'scroll' || oy === 'overlay')
      && node.scrollHeight > node.clientHeight + 2
    ) {
      scrollElementToBottom(node);
    }
  }
}

globalThis.extractInPageAfterSidebarPrep = function extractInPageAfterSidebarPrep() {
  return new Promise(function (resolve) {
    var sidebar = document.querySelector(AVVALE_SIDEBAR_SELECTOR);

    function runScroll() {
      // Antes de scrollear profundo, intenta expandir adjuntos (si existe el botón).
      tryClickAttachmentsShowMore();
      scrollRightSidebarDeep(sidebar);
    }

    runScroll();
    requestAnimationFrame(function () {
      runScroll();
      requestAnimationFrame(function () {
        runScroll();
      });
    });
    setTimeout(runScroll, 100);
    setTimeout(runScroll, 350);
    setTimeout(runScroll, 600);

    setTimeout(function () {
      runScroll();
      setTimeout(function () {
        if (typeof globalThis.extractInPage !== 'function') {
          resolve(null);
          return;
        }
        resolve(globalThis.extractInPage());
      }, AVVALE_SIDEBAR_PREP_DELAY_MS);
    }, 650);
  });
};
