/**
 * HubSpot: enlace «Solicitar» a la derecha del label «Offer Code».
 */
(function () {
  const OFFER_REQUEST_URL = 'https://portal.avvale.com/offer-request';
  const STORAGE_DESCRIPTION_KEY = 'avvaleOfferRequestDescription';
  /** Nombre del negocio (deal) completo → portal «nombre del proyecto». */
  const STORAGE_PROJECT_NAME_KEY = 'avvaleOfferRequestProjectName';
  /** Email del PM de negocio (HubSpot) → portal offer-request Project Manager. */
  const STORAGE_PM_EMAIL_KEY = 'avvaleOfferRequestPmEmail';
  /** Nombre de empresa asociada al negocio → portal Final Client / Billing Client. */
  const STORAGE_COMPANY_NAME_KEY = 'avvaleOfferRequestCompanyName';
  /** Etiqueta del portal: "Product" | "Services" → combo Activity type. */
  const STORAGE_ACTIVITY_TYPE_KEY = 'avvaleOfferRequestActivityType';
  const DEALNAME_TEXTAREA_SELECTOR =
    'textarea[data-selenium-test="property-input-dealname"]';
  const PM_EMAIL_TEXTAREA_SELECTOR =
    'textarea[data-selenium-test="property-input-project_manager_email"]';
  /** Texto del chicklet de compañía en la ficha de negocio (evita otros `property-input-name`). */
  const COMPANY_NAME_IN_CHICKLET_SEL =
    '[data-selenium-test="company-chicklet-title"] [data-selenium-test="property-input-name"]';
  /** Celda de tabla HubSpot: "Consulting" → Services, "Software / Product" → Product en el portal. */
  const DEAL_TYPE_TABLE_CELL_SEL = 'td span[data-test-id="table-cell-wrapper-2-0"]';
  const INJECTED_ATTR = 'data-avvale-offer-code-link';
  const LABEL_ROW_ATTR = 'data-avvale-offer-label-row';

  const SOLICITAR_LINK_STYLES = [
    'display:inline-flex',
    'align-items:center',
    'gap:4px',
    'font-size:14px',
    'font-weight:700',
    'color:rgb(0, 145, 174)',
    'white-space:nowrap',
    'vertical-align:baseline',
    'cursor:pointer',
    'text-decoration:none',
    'margin-left:0',
    'flex-shrink:0',
    'background:#ffffff',
    'z-index:9999999',
  ].join(';');

  /**
   * Tras el primer " - TAG - " con TAG ∈ RUN, WISE, GROW, AXAZURE, SAIBORG, YUBIQ.
   * Ej.: "Cliente - SAIBORG - Soporte" → "Soporte".
   */
  const DEAL_NAME_SEGMENT =
    /\s*-\s*(RUN|WISE|GROW|AXAZURE|SAIBORG|YUBIQ)\s*-\s*/i;

  const DEALNAME_WAIT_MS = 15000;
  const DEALNAME_POLL_MS = 80;

  function isElementVisible(el) {
    if (!el || !el.isConnected) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden') return false;
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    return true;
  }

  /**
   * Espera a que el nombre del negocio esté en el DOM y listo (visible, no deshabilitado).
   */
  function waitForDealNameTextarea() {
    return new Promise((resolve) => {
      const t0 = Date.now();
      function tick() {
        const ta = document.querySelector(DEALNAME_TEXTAREA_SELECTOR);
        if (ta && !ta.disabled && !ta.readOnly && isElementVisible(ta)) {
          resolve(ta);
          return;
        }
        if (Date.now() - t0 >= DEALNAME_WAIT_MS) {
          resolve(ta || null);
          return;
        }
        setTimeout(tick, DEALNAME_POLL_MS);
      }
      tick();
    });
  }

  function extractDescriptionFromDealName(dealName) {
    if (!dealName || typeof dealName !== 'string') return '';
    const m = DEAL_NAME_SEGMENT.exec(dealName);
    if (!m) return dealName.trim();
    return dealName.slice(m.index + m[0].length).trim();
  }

  function readAssociatedCompanyName() {
    const inChicklet = document.querySelector(COMPANY_NAME_IN_CHICKLET_SEL);
    if (inChicklet && inChicklet.textContent) {
      return inChicklet.textContent.replace(/\s+/g, ' ').trim();
    }
    return '';
  }

  function readDealTypeTableCellText() {
    const nodes = document.querySelectorAll(DEAL_TYPE_TABLE_CELL_SEL);
    for (let i = 0; i < nodes.length; i++) {
      const el = nodes[i];
      if (!el.textContent || !isElementVisible(el)) continue;
      return el.textContent.replace(/\s+/g, ' ').trim();
    }
    return '';
  }

  /**
   * Mapeo HubSpot (celda) → texto de opción en portal.avvale offer-request.
   * @returns {''|'Product'|'Services'}
   */
  function mapDealTypeCellToPortalActivityType(cellText) {
    const n = String(cellText || '')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
    if (!n) return '';
    if (n === 'consulting' || n.includes('consulting')) return 'Services';
    const softwareProduct =
      n === 'software / product' ||
      n === 'software/product' ||
      (n.includes('software') && n.includes('product'));
    if (softwareProduct) return 'Product';
    return '';
  }

  async function openOfferRequestWithDescription(e) {
    e.preventDefault();
    const ta = await waitForDealNameTextarea();
    const raw = ta?.value?.trim() ?? '';
    const description = extractDescriptionFromDealName(raw);
    const pmTa = document.querySelector(PM_EMAIL_TEXTAREA_SELECTOR);
    const pmEmail = pmTa?.value?.trim() ?? '';
    const companyName = readAssociatedCompanyName();
    const activityType = mapDealTypeCellToPortalActivityType(readDealTypeTableCellText());
    chrome.storage.local.set(
      {
        [STORAGE_DESCRIPTION_KEY]: description,
        [STORAGE_PROJECT_NAME_KEY]: raw,
        [STORAGE_PM_EMAIL_KEY]: pmEmail,
        [STORAGE_COMPANY_NAME_KEY]: companyName,
        [STORAGE_ACTIVITY_TYPE_KEY]: activityType,
      },
      () => {
        window.open(OFFER_REQUEST_URL, '_blank', 'noopener,noreferrer');
      },
    );
  }

  function layoutOfferCodeRow(container, linkEl) {
    const parent = container.parentElement;
    if (!parent || parent.getAttribute(LABEL_ROW_ATTR) === '1') return;
    parent.setAttribute(LABEL_ROW_ATTR, '1');
    parent.style.display = 'flex';
    parent.style.flexDirection = 'row';
    parent.style.alignItems = 'center';
    parent.style.justifyContent = 'space-between';
    parent.style.flexWrap = 'nowrap';
    parent.style.width = '100%';
    parent.style.boxSizing = 'border-box';
    parent.style.gap = '8px';
    parent.style.minWidth = '0';
    container.style.flex = '1';
    container.style.minWidth = '0';
    linkEl.style.cssText = SOLICITAR_LINK_STYLES;
  }

  function isOfferCodeLabel(container) {
    if (!container || container.getAttribute('data-content') !== 'true') return false;
    const inner = container.querySelector(':scope > span > span');
    if (inner && inner.textContent.trim() === 'Offer Code') return true;
    const t = container.textContent.replace(/\s+/g, ' ').trim();
    return t === 'Offer Code' || /^Offer Code(\s|\*|$)/.test(t);
  }

  function injectLink(container) {
    if (container.getAttribute(INJECTED_ATTR) === '1') return;
    const existing = container.nextElementSibling;
    if (existing?.getAttribute('data-avvale-offer-solicitar') === '1') {
      existing.style.cssText = SOLICITAR_LINK_STYLES;
      layoutOfferCodeRow(container, existing);
      if (!existing.hasAttribute('data-avvale-offer-click-bound')) {
        existing.setAttribute('data-avvale-offer-click-bound', '1');
        existing.addEventListener('click', (ev) => {
          void openOfferRequestWithDescription(ev);
        });
      }
      container.setAttribute(INJECTED_ATTR, '1');
      return;
    }

    const a = document.createElement('a');
    a.href = OFFER_REQUEST_URL;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    a.setAttribute('data-avvale-offer-solicitar', '1');
    a.setAttribute('aria-label', 'Solicitar código de oferta en el portal Avvale');
    a.style.cssText = SOLICITAR_LINK_STYLES;

    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('xmlns', 'http://www.w3.org/2000/svg');
    svg.setAttribute('viewBox', '0 0 32 32');
    svg.setAttribute('focusable', 'false');
    svg.setAttribute('data-icon-name', 'Add');
    svg.style.cssText = 'width:14px;height:14px;flex-shrink:0;fill:currentColor';
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute(
      'd',
      'M3.85 17.79h10.33v10.38c0 1.01.82 1.82 1.82 1.82s1.82-.82 1.82-1.82V17.84h10.33c1.01 0 1.82-.82 1.82-1.82s-.82-1.82-1.82-1.82H17.82V3.82C17.82 2.81 17 2 16 2s-1.82.82-1.82 1.82v10.33H3.85c-1.01 0-1.82.82-1.82 1.82s.82 1.82 1.82 1.82'
    );
    svg.appendChild(path);

    const label = document.createElement('span');
    label.textContent = 'Solicitar';

    a.appendChild(svg);
    a.appendChild(label);

    a.addEventListener('click', (ev) => {
      void openOfferRequestWithDescription(ev);
    });

    container.insertAdjacentElement('afterend', a);
    layoutOfferCodeRow(container, a);
    container.setAttribute(INJECTED_ATTR, '1');
  }

  function scan() {
    document.querySelectorAll('span[data-content="true"]').forEach((el) => {
      if (!isOfferCodeLabel(el)) return;
      injectLink(el);
    });
  }

  const observer = new MutationObserver(() => {
    scan();
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });
  scan();
})();
