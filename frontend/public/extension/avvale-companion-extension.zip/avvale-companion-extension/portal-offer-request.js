/**
 * portal.avvale.com/offer-request — rellena Description, opcionalmente nombre de proyecto,
 * Project Manager, Final Client, Billing Client y Activity type (datos desde HubSpot).
 * No usar `prj_suffix` (Project Code Suffix, máx. 5 caracteres): no es el nombre del negocio.
 */
(function () {
  if (!/\/offer-request/.test(location.pathname)) return;

  const STORAGE_KEY = 'avvaleOfferRequestDescription';
  const STORAGE_PROJECT_NAME_KEY = 'avvaleOfferRequestProjectName';
  const STORAGE_PM_EMAIL_KEY = 'avvaleOfferRequestPmEmail';
  const STORAGE_COMPANY_NAME_KEY = 'avvaleOfferRequestCompanyName';
  const STORAGE_ACTIVITY_TYPE_KEY = 'avvaleOfferRequestActivityType';
  const CC_CONTACTS_KEY = 'avvaleCcContacts';
  const FILL_TIMEOUT_MS = 45000;
  const POLL_MS = 120;
  const PROJECT_NAME_POLL_MS = 120;
  const PROJECT_NAME_OBS_MAX_MS = 12000;
  const PM_MAX_ATTEMPTS = 120;
  const PM_RETRY_MS = 150;
  const CLIENT_MAX_ATTEMPTS = 120;
  const CLIENT_RETRY_MS = 150;
  const ACTIVITY_MAX_ATTEMPTS = 120;
  const ACTIVITY_RETRY_MS = 150;
  /** Tras rellenar descripción con éxito: breve pausa antes de proyecto + PM (no usar ~FILL_TIMEOUT_MS). */
  const PROJECT_CHAIN_DELAY_MS = 500;
  /**
   * Espera fija antes de autocompletar (formulario SPA aún montando). Sustituir por detección de evento cuando exista.
   */
  const FORM_READY_DELAY_SEC = 10;

  const PM_DROPDOWN_CANDIDATES = [
    'div[name="project_manager"]',
    'div[name="bid_manager"]',
    'div[role="combobox"][name="project_manager"]',
    'div[role="combobox"][name="bid_manager"]',
  ];

  let pmSearchFilterApplied = false;
  let finalClientSearchApplied = false;
  let billingClientSearchApplied = false;
  /** Cadena secuencial: al terminar Final Client se rellena Billing Client. */
  let pendingCompanyForClientChain = '';

  let activitySearchApplied = false;

  const clientAutofillTerminal = { final: false, billing: false };

  function findPmDropdownRoot() {
    for (let i = 0; i < PM_DROPDOWN_CANDIDATES.length; i++) {
      const el = document.querySelector(PM_DROPDOWN_CANDIDATES[i]);
      if (el) return el;
    }
    return null;
  }

  function findClientDropdownRoot(nameAttr) {
    const byName = document.querySelector('div[name="' + nameAttr + '"]');
    if (byName) return byName;
    return document.querySelector('div[role="combobox"][name="' + nameAttr + '"]');
  }

  function normalizeCompanyLabel(s) {
    return String(s || '')
      .trim()
      .toLowerCase()
      .replace(/\s+/g, ' ');
  }

  function getOptionLabelText(opt) {
    if (!opt) return '';
    const t = opt.querySelector('.text');
    const raw = t ? t.textContent : opt.textContent;
    return raw ? raw.replace(/\s+/g, ' ').trim() : '';
  }

  function findClientOptionByCompany(root, companyNorm) {
    if (!root || !companyNorm) return null;
    const opts = root.querySelectorAll('[role="option"]');
    let best = null;
    let bestLen = -1;
    for (let i = 0; i < opts.length; i++) {
      const opt = opts[i];
      const label = normalizeCompanyLabel(getOptionLabelText(opt));
      if (!label) continue;
      if (label === companyNorm) return opt;
      if (label.includes(companyNorm) || companyNorm.includes(label)) {
        if (label.length > bestLen) {
          best = opt;
          bestLen = label.length;
        }
      }
    }
    return best;
  }

  function openClientDropdownIfNeeded(root) {
    if (!root) return false;
    if (root.getAttribute('aria-expanded') !== 'true') {
      root.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }
    return true;
  }

  function markClientFieldTerminal(which) {
    if (clientAutofillTerminal[which]) return;
    clientAutofillTerminal[which] = true;
    if (which === 'final' && pendingCompanyForClientChain) {
      trySelectClientDropdown(
        'billing',
        'billing_client_type',
        pendingCompanyForClientChain,
        0,
      );
    }
    if (clientAutofillTerminal.final && clientAutofillTerminal.billing) {
      chrome.storage.local.remove(STORAGE_COMPANY_NAME_KEY);
      pendingCompanyForClientChain = '';
    }
  }

  /**
   * @param {'final'|'billing'} which
   * @param {string} nameAttr final_client_type | billing_client_type
   */
  function trySelectClientDropdown(which, nameAttr, companyRaw, attempt) {
    const companyNorm = normalizeCompanyLabel(companyRaw);
    if (!companyNorm) {
      markClientFieldTerminal(which);
      return;
    }

    const searchAlreadyApplied =
      which === 'final' ? finalClientSearchApplied : billingClientSearchApplied;

    const root = findClientDropdownRoot(nameAttr);

    if (!root || !isElementVisible(root)) {
      if (attempt >= CLIENT_MAX_ATTEMPTS) {
        markClientFieldTerminal(which);
        return;
      }
      setTimeout(function () {
        trySelectClientDropdown(which, nameAttr, companyRaw, attempt + 1);
      }, CLIENT_RETRY_MS);
      return;
    }

    openClientDropdownIfNeeded(root);

    let opt = findClientOptionByCompany(root, companyNorm);

    const searchInput = root.querySelector('input.search');
    if (
      !opt &&
      !searchAlreadyApplied &&
      searchInput &&
      attempt >= 4 &&
      companyRaw
    ) {
      if (which === 'final') finalClientSearchApplied = true;
      else billingClientSearchApplied = true;
      const q = String(companyRaw).trim().slice(0, 80);
      if (q) {
        searchInput.focus();
        setInputValueReactFriendly(searchInput, q);
      }
    }

    opt = findClientOptionByCompany(root, companyNorm);
    if (opt) {
      opt.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      opt.click();
      markClientFieldTerminal(which);
      return;
    }

    if (attempt >= CLIENT_MAX_ATTEMPTS) {
      markClientFieldTerminal(which);
      return;
    }
    setTimeout(function () {
      trySelectClientDropdown(which, nameAttr, companyRaw, attempt + 1);
    }, CLIENT_RETRY_MS);
  }

  function beginClientDropdownsIfNeeded(companyRaw) {
    finalClientSearchApplied = false;
    billingClientSearchApplied = false;
    clientAutofillTerminal.final = false;
    clientAutofillTerminal.billing = false;

    const s = companyRaw != null ? String(companyRaw).trim() : '';
    if (!s) {
      chrome.storage.local.remove(STORAGE_COMPANY_NAME_KEY);
      return;
    }

    pendingCompanyForClientChain = s;
    trySelectClientDropdown('final', 'final_client_type', s, 0);
  }

  function findActivityOptionByPortalLabel(root, portalLabelNorm) {
    if (!root || !portalLabelNorm) return null;
    const opts = root.querySelectorAll('[role="option"]');
    for (let i = 0; i < opts.length; i++) {
      const label = normalizeCompanyLabel(getOptionLabelText(opts[i]));
      if (label === portalLabelNorm) return opts[i];
    }
    return null;
  }

  function openActivityDropdownIfNeeded(root) {
    if (!root) return false;
    if (root.getAttribute('aria-expanded') !== 'true') {
      root.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }
    return true;
  }

  function trySelectActivityType(portalLabelRaw, attempt) {
    const portalNorm = normalizeCompanyLabel(portalLabelRaw);
    if (!portalNorm) {
      chrome.storage.local.remove(STORAGE_ACTIVITY_TYPE_KEY);
      return;
    }

    const root = findClientDropdownRoot('activity_type');
    if (!root || !isElementVisible(root)) {
      if (attempt >= ACTIVITY_MAX_ATTEMPTS) {
        chrome.storage.local.remove(STORAGE_ACTIVITY_TYPE_KEY);
        return;
      }
      setTimeout(function () {
        trySelectActivityType(portalLabelRaw, attempt + 1);
      }, ACTIVITY_RETRY_MS);
      return;
    }

    openActivityDropdownIfNeeded(root);

    let opt = findActivityOptionByPortalLabel(root, portalNorm);

    const searchInput = root.querySelector('input.search');
    if (
      !opt &&
      !activitySearchApplied &&
      searchInput &&
      attempt >= 4 &&
      portalLabelRaw
    ) {
      activitySearchApplied = true;
      const q = String(portalLabelRaw).trim().slice(0, 40);
      if (q) {
        searchInput.focus();
        setInputValueReactFriendly(searchInput, q);
      }
    }

    opt = findActivityOptionByPortalLabel(root, portalNorm);
    if (opt) {
      opt.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      opt.click();
      chrome.storage.local.remove(STORAGE_ACTIVITY_TYPE_KEY);
      return;
    }

    if (attempt >= ACTIVITY_MAX_ATTEMPTS) {
      chrome.storage.local.remove(STORAGE_ACTIVITY_TYPE_KEY);
      return;
    }
    setTimeout(function () {
      trySelectActivityType(portalLabelRaw, attempt + 1);
    }, ACTIVITY_RETRY_MS);
  }

  function beginActivityTypeIfNeeded(portalLabelRaw) {
    activitySearchApplied = false;
    const s = portalLabelRaw != null ? String(portalLabelRaw).trim() : '';
    if (!s) {
      chrome.storage.local.remove(STORAGE_ACTIVITY_TYPE_KEY);
      return;
    }
    trySelectActivityType(s, 0);
  }

  function isElementVisible(el) {
    if (!el || !el.isConnected) return false;
    if (typeof el.checkVisibility === 'function') {
      return el.checkVisibility({
        checkOpacity: true,
        checkVisibilityCSS: true,
      });
    }
    const style = window.getComputedStyle(el);
    if (
      style.display === 'none' ||
      style.visibility === 'hidden' ||
      Number.parseFloat(style.opacity) === 0
    ) {
      return false;
    }
    const rect = el.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0) return false;
    let p = el.parentElement;
    while (p) {
      const ps = window.getComputedStyle(p);
      if (ps.display === 'none' || ps.visibility === 'hidden') return false;
      p = p.parentElement;
    }
    return true;
  }

  function isDescriptionControlReady(el) {
    if (!el || !el.isConnected) return false;
    if (el.tagName === 'TEXTAREA') {
      if (el.disabled || el.readOnly) return false;
      return isElementVisible(el);
    }
    if (el.tagName === 'INPUT') {
      if (el.type === 'hidden') return false;
      if (el.disabled || el.readOnly) return false;
      return isElementVisible(el);
    }
    return false;
  }

  function setInputValueReactFriendly(input, value) {
    try {
      const proto = window.HTMLInputElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      desc?.set?.call(input, value);
    } catch (_) {
      input.value = value;
    }
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setTextAreaValueReactFriendly(textarea, value) {
    try {
      const proto = window.HTMLTextAreaElement.prototype;
      const desc = Object.getOwnPropertyDescriptor(proto, 'value');
      desc?.set?.call(textarea, value);
    } catch (_) {
      textarea.value = value;
    }
    textarea.dispatchEvent(new Event('input', { bubbles: true }));
    textarea.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function setControlValueReactFriendly(el, value) {
    if (!el) return;
    if (el.tagName === 'TEXTAREA') setTextAreaValueReactFriendly(el, value);
    else setInputValueReactFriendly(el, value);
  }

  function findDescriptionInput() {
    return document.querySelector(
      [
        '.required.eight.wide.field input[name="description"]',
        '.required.eight.wide.field textarea[name="description"]',
        'input[name="description"]',
        'textarea[name="description"]',
      ].join(', '),
    );
  }

  function tryFillDescription(value) {
    const input = findDescriptionInput();
    if (!isDescriptionControlReady(input)) return false;
    setControlValueReactFriendly(input, value);
    return true;
  }

  function isProjectNameControlReady(el) {
    if (!el || (el.tagName !== 'INPUT' && el.tagName !== 'TEXTAREA') || !el.isConnected)
      return false;
    if (el.disabled || el.readOnly) return false;
    return isElementVisible(el);
  }

  function findProjectNameInput() {
    return (
      document.querySelector('input[name="project_name"], textarea[name="project_name"]') ||
      document.querySelector(
        'input[placeholder*="project name" i], input[placeholder*="nombre del proyecto" i], input[placeholder*="nombre proyecto" i]',
      )
    );
  }

  function tryFillProjectName(value) {
    const el = findProjectNameInput();
    if (!isProjectNameControlReady(el)) return false;
    setControlValueReactFriendly(el, value);
    return true;
  }

  function normalizeEmail(s) {
    return String(s || '')
      .trim()
      .toLowerCase();
  }

  function findContactByEmail(contacts, pmEmail) {
    const n = normalizeEmail(pmEmail);
    if (!n || !Array.isArray(contacts)) return null;
    for (let i = 0; i < contacts.length; i++) {
      const c = contacts[i];
      const e = c && typeof c.email === 'string' ? c.email : '';
      if (normalizeEmail(e) === n) return c;
    }
    return null;
  }

  function findPmOption(pmEmailNorm, contact) {
    const root = findPmDropdownRoot();
    if (!root) return null;
    const opts = root.querySelectorAll('[role="option"]');
    for (let i = 0; i < opts.length; i++) {
      const opt = opts[i];
      const em = opt.getAttribute('email');
      if (em && normalizeEmail(em) === pmEmailNorm) return opt;
    }
    if (contact && typeof contact.name === 'string') {
      const nameLow = contact.name.trim().toLowerCase();
      for (let j = 0; j < opts.length; j++) {
        const opt = opts[j];
        const t = opt.querySelector('.text');
        const tx = t ? t.textContent.trim().toLowerCase() : '';
        if (tx && (tx === nameLow || tx.includes(nameLow) || nameLow.includes(tx))) return opt;
      }
    }
    return null;
  }

  function openPmDropdownIfNeeded() {
    const root = findPmDropdownRoot();
    if (!root) return false;
    if (root.getAttribute('aria-expanded') !== 'true') {
      root.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
    }
    return true;
  }

  function trySelectProjectManager(pmEmailRaw, contacts, attempt) {
    const pmNorm = normalizeEmail(pmEmailRaw);
    if (!pmNorm) {
      chrome.storage.local.remove(STORAGE_PM_EMAIL_KEY);
      return;
    }

    const contact = findContactByEmail(contacts, pmEmailRaw);
    const root = findPmDropdownRoot();
    if (!root || !isElementVisible(root)) {
      if (attempt >= PM_MAX_ATTEMPTS) {
        chrome.storage.local.remove(STORAGE_PM_EMAIL_KEY);
        return;
      }
      setTimeout(() => trySelectProjectManager(pmEmailRaw, contacts, attempt + 1), PM_RETRY_MS);
      return;
    }

    openPmDropdownIfNeeded();

    let opt = findPmOption(pmNorm, contact);

    const searchInput = root.querySelector('input.search');
    if (!opt && !pmSearchFilterApplied && searchInput && attempt >= 4 && (contact?.name || pmNorm)) {
      pmSearchFilterApplied = true;
      const q =
        (contact && typeof contact.name === 'string' && contact.name.trim().slice(0, 40)) ||
        pmNorm.split('@')[0] ||
        '';
      if (q) {
        searchInput.focus();
        setInputValueReactFriendly(searchInput, q);
      }
    }

    opt = findPmOption(pmNorm, contact);
    if (opt) {
      opt.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
      opt.click();
      chrome.storage.local.remove(STORAGE_PM_EMAIL_KEY);
      return;
    }

    if (attempt >= PM_MAX_ATTEMPTS) {
      chrome.storage.local.remove(STORAGE_PM_EMAIL_KEY);
      return;
    }
    setTimeout(() => trySelectProjectManager(pmEmailRaw, contacts, attempt + 1), PM_RETRY_MS);
  }

  function beginProjectManagerIfNeeded(pmEmailRaw, contacts) {
    const s = pmEmailRaw != null ? String(pmEmailRaw).trim() : '';
    if (!s) {
      chrome.storage.local.remove(STORAGE_PM_EMAIL_KEY);
      return;
    }
    trySelectProjectManager(s, Array.isArray(contacts) ? contacts : [], 0);
  }

  /**
   * Tras descripción: breve pausa (PROJECT_CHAIN_DELAY_MS). Si el poll de descripción
   * agota FILL_TIMEOUT_MS, encadenar sin espera extra (el formulario ya tuvo tiempo).
   */
  function scheduleProjectNameThenPm(projectNameRaw, pmEmail, contacts, chainOpts) {
    const pn = projectNameRaw != null ? String(projectNameRaw).trim() : '';
    const fromPollTimeout = chainOpts && chainOpts.fromDescriptionPollTimeout;
    const companyName = chainOpts && chainOpts.companyName;
    const activityTypeLabel = chainOpts && chainOpts.activityTypeLabel;
    const waitMs = fromPollTimeout ? 0 : PROJECT_CHAIN_DELAY_MS;
    setTimeout(() => {
      function finishProjectNameAndPm() {
        chrome.storage.local.remove(STORAGE_PROJECT_NAME_KEY);
        beginProjectManagerIfNeeded(pmEmail, contacts);
        beginClientDropdownsIfNeeded(companyName);
        beginActivityTypeIfNeeded(activityTypeLabel);
      }

      if (!pn) {
        finishProjectNameAndPm();
        return;
      }

      const nameFieldPresent = !!findProjectNameInput();
      if (!nameFieldPresent) {
        finishProjectNameAndPm();
        return;
      }

      if (tryFillProjectName(pn)) {
        finishProjectNameAndPm();
        return;
      }

      let poll2 = null;
      let tid2 = null;
      const obs2 = new MutationObserver(() => {
        if (tryFillProjectName(pn)) {
          obs2.disconnect();
          if (poll2 != null) clearInterval(poll2);
          if (tid2 != null) clearTimeout(tid2);
          finishProjectNameAndPm();
        }
      });
      obs2.observe(document.documentElement, { childList: true, subtree: true });
      poll2 = setInterval(() => {
        if (tryFillProjectName(pn)) {
          obs2.disconnect();
          if (poll2 != null) clearInterval(poll2);
          if (tid2 != null) clearTimeout(tid2);
          finishProjectNameAndPm();
        }
      }, PROJECT_NAME_POLL_MS);
      tid2 = setTimeout(() => {
        obs2.disconnect();
        if (poll2 != null) clearInterval(poll2);
        finishProjectNameAndPm();
      }, PROJECT_NAME_OBS_MAX_MS);
    }, waitMs);
  }

  /** Espera a load + un frame para frameworks (React, etc.). */
  function whenPageFullyLoaded(done) {
    function schedule() {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          setTimeout(done, 0);
        });
      });
    }
    if (document.readyState === 'complete') {
      schedule();
    } else {
      window.addEventListener('load', schedule, { once: true });
    }
  }

  /**
   * Cuenta atrás flotante; al terminar ejecuta onDone (relleno de descripción + cadena PM).
   */
  function showFormReadyCountdown(secondsTotal, onDone) {
    const existing = document.getElementById('avvale-offer-request-countdown');
    if (existing) existing.remove();

    const wrap = document.createElement('div');
    wrap.id = 'avvale-offer-request-countdown';
    wrap.setAttribute('data-avvale-offer-countdown', '1');
    wrap.style.cssText = [
      'position:fixed',
      'bottom:24px',
      'right:24px',
      'z-index:2147483647',
      'font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif',
      'font-size:14px',
      'line-height:1.35',
      'padding:14px 18px',
      'background:#1a1a2e',
      'color:#eee',
      'border-radius:12px',
      'box-shadow:0 10px 28px rgba(0,0,0,.4)',
      'max-width:300px',
      'pointer-events:none',
    ].join(';');

    const brand = document.createElement('div');
    brand.textContent = 'Avvale Companion';
    brand.style.cssText =
      'font-weight:700;margin-bottom:8px;color:#7dd3fc;font-size:12px;letter-spacing:.04em;text-transform:uppercase;';

    const line = document.createElement('div');
    line.style.cssText = 'color:#f8fafc;';

    function updateLabel(remaining) {
      line.textContent =
        'Esperando a que el formulario cargue… ' + remaining + ' s';
    }

    wrap.appendChild(brand);
    wrap.appendChild(line);

    function appendWhenBody() {
      if (document.body) {
        document.body.appendChild(wrap);
        return true;
      }
      return false;
    }
    if (!appendWhenBody()) {
      const obs = new MutationObserver(() => {
        if (appendWhenBody()) obs.disconnect();
      });
      obs.observe(document.documentElement, { childList: true, subtree: true });
    }

    let left = secondsTotal;
    updateLabel(left);

    const timer = window.setInterval(function () {
      left -= 1;
      updateLabel(left);
      if (left <= 0) {
        window.clearInterval(timer);
        if (wrap.parentNode) wrap.parentNode.removeChild(wrap);
        onDone();
      }
    }, 1000);
  }

  function runAfterReady() {
    chrome.storage.local.get(
      [
        STORAGE_KEY,
        STORAGE_PROJECT_NAME_KEY,
        STORAGE_PM_EMAIL_KEY,
        STORAGE_COMPANY_NAME_KEY,
        STORAGE_ACTIVITY_TYPE_KEY,
        CC_CONTACTS_KEY,
      ],
      (data) => {
        const raw = data[STORAGE_KEY];
        const projectName = data[STORAGE_PROJECT_NAME_KEY];
        const pmEmail = data[STORAGE_PM_EMAIL_KEY];
        const companyName = data[STORAGE_COMPANY_NAME_KEY];
        const activityTypeLabel = data[STORAGE_ACTIVITY_TYPE_KEY];
        const contacts = data[CC_CONTACTS_KEY];

        if (raw == null || String(raw).trim() === '') return;

        const v = String(raw).trim();

        const chainBase = { companyName, activityTypeLabel };

        function onDescriptionDone() {
          chrome.storage.local.remove(STORAGE_KEY);
          scheduleProjectNameThenPm(projectName, pmEmail, contacts, chainBase);
        }

        if (tryFillDescription(v)) {
          onDescriptionDone();
          return;
        }

        const obs = new MutationObserver(() => {
          if (tryFillDescription(v)) {
            obs.disconnect();
            clearInterval(pollId);
            clearTimeout(timeoutId);
            onDescriptionDone();
          }
        });
        obs.observe(document.documentElement, { childList: true, subtree: true });

        const pollId = setInterval(() => {
          if (tryFillDescription(v)) {
            obs.disconnect();
            clearInterval(pollId);
            clearTimeout(timeoutId);
            onDescriptionDone();
          }
        }, POLL_MS);

        const timeoutId = setTimeout(() => {
          obs.disconnect();
          clearInterval(pollId);
          scheduleProjectNameThenPm(projectName, pmEmail, contacts, {
            fromDescriptionPollTimeout: true,
            companyName,
            activityTypeLabel,
          });
        }, FILL_TIMEOUT_MS);
      },
    );
  }

  function run() {
    whenPageFullyLoaded(function () {
      showFormReadyCountdown(FORM_READY_DELAY_SEC, runAfterReady);
    });
  }

  run();
})();
