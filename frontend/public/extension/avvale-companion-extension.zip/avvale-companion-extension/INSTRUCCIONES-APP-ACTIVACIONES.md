# Cómo preparar tu app de activaciones para recibir el JSON de la extensión

La extensión, al pulsar **"Enviar activación"**, abre una **nueva pestaña** con esta URL:

```
http://localhost:3000/activations/new#<payload>
```

El `<payload>` es el JSON de la recopilación codificado en **base64url** (el mismo objeto que antes: `projectName`, `offerCode`, `hubspotUrl`, `client`, `amount`, `attachmentUrls`).

Tu aplicación en `http://localhost:3000/activations/new` debe:

1. **Al cargar la página**, leer el hash (`window.location.hash`).
2. **Decodificar** el base64url y parsear el JSON.
3. **Rellenar el formulario** con esos valores.

---

## 1. Decodificar el payload (JavaScript)

Añade un script en la página `/activations/new` (o en tu bundle) con una función como esta:

```javascript
/**
 * Lee el payload enviado por la extensión Avvale Companion desde el hash de la URL.
 * Devuelve el objeto o null si no hay hash o hay error.
 */
function getActivationPayloadFromHash() {
  const hash = window.location.hash.slice(1); // quita el #
  if (!hash) return null;
  try {
    // base64url -> base64 estándar
    let base64 = hash.replace(/-/g, '+').replace(/_/g, '/');
    const pad = base64.length % 4;
    if (pad) base64 += '===='.slice(0, 4 - pad);
    const json = decodeURIComponent(escape(atob(base64)));
    return JSON.parse(json);
  } catch (e) {
    console.warn('Avvale Companion: no se pudo decodificar el payload del hash', e);
    return null;
  }
}
```

---

## 2. Autocompletar el formulario al cargar

Cuando cargue la página del formulario (por ejemplo en `DOMContentLoaded` o en el `useEffect` de React si es SPA):

```javascript
const payload = getActivationPayloadFromHash();
if (payload) {
  // Asigna cada campo a su input/textarea por id, name o como tengas el form
  setValue('projectName', payload.projectName);      // Nombre del proyecto
  setValue('offerCode', payload.offerCode);            // Código de oferta
  setValue('hubspotUrl', payload.hubspotUrl);          // URL HubSpot
  setValue('client', payload.client);                  // Cliente
  setValue('amount', payload.amount);                  // Importe
  // attachmentUrls es un array de strings (URLs de descarga)
  setValue('attachmentUrls', payload.attachmentUrls || []); // o el campo que uses para adjuntos
}
```

Si usas **HTML puro** con `<input id="projectName">`, etc.:

```javascript
function fillFormFromPayload(payload) {
  if (!payload) return;
  const set = (id, value) => {
    const el = document.getElementById(id);
    if (el && value != null) el.value = value;
  };
  set('projectName', payload.projectName);
  set('offerCode', payload.offerCode);
  set('hubspotUrl', payload.hubspotUrl);
  set('client', payload.client);
  set('amount', payload.amount);
  // Si tienes un textarea para las URLs de adjuntos (una por línea):
  if (payload.attachmentUrls && payload.attachmentUrls.length) {
    const el = document.getElementById('attachmentUrls');
    if (el) el.value = payload.attachmentUrls.join('\n');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  fillFormFromPayload(getActivationPayloadFromHash());
});
```

Si usas **React** (formulario controlado):

```javascript
useEffect(() => {
  const payload = getActivationPayloadFromHash();
  if (!payload) return;
  setProjectName(payload.projectName ?? '');
  setOfferCode(payload.offerCode ?? '');
  setHubspotUrl(payload.hubspotUrl ?? '');
  setClient(payload.client ?? '');
  setAmount(payload.amount ?? '');
  setAttachmentUrls(payload.attachmentUrls ?? []);
}, []);
```

---

## 3. Estructura del JSON que recibes

El objeto que obtienes al decodificar el hash tiene esta forma:

```json
{
  "projectName": "REFRIVAL - SAIBORG - SOPORTE EXPERTO - AMS ORION",
  "offerCode": "ESP_24_0812 - Soporte Experto - AMS ORION.",
  "hubspotUrl": "https://app.hubspot.com/contacts/...",
  "client": "REFRIVAL",
  "amount": "1.725.600 €",
  "serviceType": "Consulting",
  "attachmentUrls": [
    "https://app.hubspot.com/api/filemanager/api/v2/files/201161753653/signed-url-redirect?portalId=500261&response-content-disposition=attachment"
  ]
}
```

- **serviceType**: texto de la celda de tabla (p. ej. `"Consulting"` o `"Software"`). Úsalo para el campo Consultoría/Software.

Solo tienes que mapear cada clave al campo correspondiente de tu formulario.

---

## 4. (Opcional) Limpiar el hash después de rellenar

Para que la URL no muestre el payload largo en la barra de direcciones una vez rellenado:

```javascript
if (payload) {
  fillFormFromPayload(payload);
  window.history.replaceState(null, '', window.location.pathname + window.location.search);
}
```

Así el formulario queda rellenado y la URL vuelve a ser solo `http://localhost:3000/activations/new`.
