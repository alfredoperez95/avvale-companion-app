/**
 * Pipeline Dashboard (Vercel): inyección en el panel lateral de detalle de deal.
 */
(function () {
  const DIALOG_SELECTOR = 'div[role="dialog"][aria-label^="Detalle:"]';
  const INJECTED_ATTR = 'data-avvale-hubspot-btn';
  const WRAP_ID = 'avvale-pipeline-hubspot-btn-wrap';
  /** Portal HubSpot (segmento /search/{id}/search en la URL global). */
  const HUBSPOT_PORTAL_ID = '500261';
  const QUERY_SUFFIX = ' Companion';
  /** Poner en `true` para volver a mostrar el botón «Ver en HubSpot». */
  const SHOW_VER_EN_HUBSPOT_BUTTON = false;

  function getDealTitleFromDialog(dialog) {
    const closeBtn = dialog.querySelector('button[aria-label="Cerrar panel"]');
    const header = closeBtn?.parentElement;
    if (header) {
      const leftCol = header.firstElementChild;
      const titleEl = leftCol?.firstElementChild;
      const fromDom = titleEl?.textContent?.trim();
      if (fromDom) return fromDom;
    }
    const label = dialog.getAttribute('aria-label') || '';
    const m = /^Detalle:\s*(.+)$/i.exec(label);
    return m ? m[1].trim() : '';
  }

  function buildHubSpotSearchUrl(dealTitle) {
    const base = `https://app.hubspot.com/search/${HUBSPOT_PORTAL_ID}/search`;
    const query = `${dealTitle.trim()}${QUERY_SUFFIX}`.replace(/\s+/g, ' ');
    return `${base}?${new URLSearchParams({ query }).toString()}`;
  }

  function openHubSpotSearchForDialog(dialog) {
    const title = getDealTitleFromDialog(dialog);
    if (!title) return;
    const url = buildHubSpotSearchUrl(title);
    const a = document.createElement('a');
    a.href = url;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function injectVerEnHubspot(dialog) {
    if (!SHOW_VER_EN_HUBSPOT_BUTTON) return;
    if (!dialog || dialog.getAttribute(INJECTED_ATTR) === '1') return;

    const closeBtn = dialog.querySelector('button[aria-label="Cerrar panel"]');
    const header = closeBtn && closeBtn.parentElement;
    if (!header || !header.parentElement) return;

    const wrap = document.createElement('div');
    wrap.id = WRAP_ID;
    wrap.style.cssText =
      'margin-bottom:16px;width:100%;box-sizing:border-box;';

    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Ver en HubSpot';
    btn.setAttribute('aria-label', 'Ver en HubSpot');
    btn.style.cssText = [
      'width:100%',
      'padding:10px 16px',
      'border:none',
      'border-radius:10px',
      'background:#ea580c',
      'color:#fff',
      'font-weight:600',
      'font-size:13px',
      'cursor:pointer',
      'font-family:var(--font-body,system-ui,sans-serif)',
      'transition:background 0.15s',
    ].join(';');

    btn.addEventListener('mouseenter', () => {
      btn.style.background = '#c2410c';
    });
    btn.addEventListener('mouseleave', () => {
      btn.style.background = '#ea580c';
    });
    btn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      openHubSpotSearchForDialog(dialog);
    });

    wrap.appendChild(btn);
    header.insertAdjacentElement('afterend', wrap);
    dialog.setAttribute(INJECTED_ATTR, '1');
  }

  function scanNode(root) {
    if (!root || root.nodeType !== Node.ELEMENT_NODE) return;
    if (root.matches(DIALOG_SELECTOR)) injectVerEnHubspot(root);
    root.querySelectorAll(DIALOG_SELECTOR).forEach(injectVerEnHubspot);
  }

  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const node of m.addedNodes) {
        if (node.nodeType === Node.ELEMENT_NODE) scanNode(node);
      }
    }
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
  scanNode(document.body);
})();
