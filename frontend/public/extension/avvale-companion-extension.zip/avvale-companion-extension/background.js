/**
 * Avvale Companion - Background Service Worker (Manifest V3)
 * Punto central para mensajes (futuro: auth, etc.).
 */

const PREFIX = '[Avvale Companion]';
const STORAGE_KEY_LAST_RECOPILATED = 'lastRecopilatedData';
const STORAGE_KEY_ANTHROPIC_API_KEY = 'anthropicApiKey';
const STORAGE_KEY_ANTHROPIC_MODEL = 'anthropicModel';
const STORAGE_KEY_YUBIQ_PENDING = 'yubiqPendingAutofill';
const DEFAULT_YUBIQ_URL = 'https://avvale-aes-y5ui.yubiq.app/YUBIK/home#addnew';

function isValidManualMargin(m) {
  return typeof m === 'number' && Number.isInteger(m) && m >= 0 && m <= 100;
}

function validateYubiqPayload(payload) {
  if (!payload || typeof payload !== 'object') return { ok: false, error: 'Payload inválido' };
  if (payload.target !== 'yubiq_addnew') return { ok: false, error: 'target debe ser yubiq_addnew' };
  const rawUrl = typeof payload.targetUrl === 'string' && payload.targetUrl.trim() ? payload.targetUrl.trim() : DEFAULT_YUBIQ_URL;
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    return { ok: false, error: 'targetUrl inválida' };
  }
  if (!u.hash.includes('addnew')) return { ok: false, error: 'targetUrl debe incluir #addnew' };
  if (!payload.prefill || typeof payload.prefill !== 'object') return { ok: false, error: 'prefill requerido' };
  if (Object.prototype.hasOwnProperty.call(payload, 'manualMargin')) {
    if (!isValidManualMargin(payload.manualMargin)) {
      return { ok: false, error: 'manualMargin debe ser un entero entre 0 y 100' };
    }
  }
  return { ok: true, url: rawUrl };
}

function pad2(n) {
  return String(n).padStart(2, '0');
}

function formatDateDDMMYYYY(d) {
  return `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;
}

function addOneMonth(date) {
  const d = new Date(date.getTime());
  const day = d.getDate();
  d.setMonth(d.getMonth() + 1);
  // Si el mes resultante no tiene ese día (p.ej. 31), JS “salta” al mes siguiente.
  // Ajustamos al último día del mes correcto.
  if (d.getDate() !== day) {
    d.setDate(0);
  }
  return d;
}

function extractFirstJsonObject(text) {
  if (!text) return null;
  const s = String(text).trim();
  // Intento 1: parse directo
  try {
    const direct = JSON.parse(s);
    if (direct && typeof direct === 'object') return direct;
  } catch (_) {}

  // Intento 2: buscar el primer bloque { ... } razonable
  const start = s.indexOf('{');
  if (start === -1) return null;
  for (let end = s.length - 1; end > start; end--) {
    if (s[end] !== '}') continue;
    const candidate = s.slice(start, end + 1);
    try {
      const obj = JSON.parse(candidate);
      if (obj && typeof obj === 'object') return obj;
    } catch (_) {}
  }
  return null;
}

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'update') {
    chrome.storage.local.remove(STORAGE_KEY_LAST_RECOPILATED);
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log(`${PREFIX} Mensaje recibido:`, message?.type, sender?.tab?.id);

  if (message?.type === 'PING') {
    sendResponse({ ok: true });
    return true;
  }

  if (message?.type === 'OPEN_URL' && typeof message.url === 'string') {
    chrome.tabs.create({ url: message.url }, () => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
      } else {
        sendResponse({ ok: true });
      }
    });

    const senderTabId = sender?.tab?.id;
    if (typeof senderTabId === 'number') {
      setTimeout(() => {
        chrome.tabs.reload(senderTabId, () => {
          if (chrome.runtime.lastError) {
            console.log(`${PREFIX} No se pudo recargar la pestaña origen:`, chrome.runtime.lastError.message);
          }
        });
      }, 2000);
    }

    return true;
  }

  if (message?.type === 'ANALYZE_PDF' && typeof message.pdfBase64 === 'string') {
    chrome.storage.local.get({ [STORAGE_KEY_ANTHROPIC_API_KEY]: '', [STORAGE_KEY_ANTHROPIC_MODEL]: 'haiku' }, async (data) => {
      const tStart = performance.now();
      const elapsedMs = () => Math.round(performance.now() - tStart);

      try {
        const apiKey = typeof data[STORAGE_KEY_ANTHROPIC_API_KEY] === 'string' ? data[STORAGE_KEY_ANTHROPIC_API_KEY].trim() : '';
        if (!apiKey) {
          sendResponse({ ok: false, error: 'Falta la API key de Anthropic. Configúrala en el popup.' });
          return;
        }
        const modelPref =
          data[STORAGE_KEY_ANTHROPIC_MODEL] === 'opus'
          ? 'opus'
          : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'haiku'
            ? 'haiku'
            : data[STORAGE_KEY_ANTHROPIC_MODEL] === 'sonnet'
              ? 'sonnet'
              : 'haiku';
        // IDs según documentación Anthropic (Haiku va por 4.5, no 4.6).
        const modelId =
          modelPref === 'opus'
            ? 'claude-opus-4-6'
            : modelPref === 'haiku'
              ? 'claude-haiku-4-5'
              : 'claude-sonnet-4-6';

        const today = new Date();
        const closeDate = formatDateDDMMYYYY(addOneMonth(today));

        const fileName = typeof message.fileName === 'string' ? message.fileName : '';

        const prompt = [
          'Eres un extractor de datos de ofertas comerciales en español.',
          '',
          'Analiza el PDF y devuelve ÚNICAMENTE un JSON válido (sin texto adicional, sin markdown).',
          '',
          'Devuelve EXACTAMENTE esta estructura:',
          '{',
          '  "nombre_cliente": string | null,',
          '  "area_avvale": "RUN" | "GROW" | "SAIBORG" | "WISE" | "YUBIQ",',
          '  "deal_type": "New Opportunity" | "Renovación" | "Upsell",',
          '  "nombre_proyecto": string | null,',
          '  "valor": number | null',
          '}',
          '',
          'Contexto adicional:',
          `- Nombre del archivo del PDF (referencia): ${fileName}`,
          '',
          'REGLAS:',
          '',
          '1) nombre_cliente',
          '- Debe ser el CLIENTE (empresa a la que se oferta), no el proveedor/emisor.',
          '- Prioriza textos cerca de: "Cliente", "Destinatario", "A la atención de", "Para:", "Comprador", "CIF/NIF del cliente".',
          '- Si no puedes distinguir cliente vs proveedor con alta confianza, devuelve null.',
          '',
          '2) nombre_proyecto',
          '- Si encuentras un nombre de proyecto/servicio claro dentro del PDF, úsalo.',
          '- Si NO es claro, usa el NOMBRE DEL ARCHIVO como referencia principal (sin la extensión .pdf).',
          '- Limpieza del nombre del archivo: reemplaza guiones bajos por espacios, quita IDs/fechas obvias si estorban, colapsa espacios, y deja un título legible.',
          '- Puede incluir siglas (p. ej. “RISE T&M”, “SAP”, “Basis Specialist”) si están en el PDF o en el nombre del archivo.',
          '- Si incluso el nombre del archivo es demasiado genérico (p. ej. “Oferta”, “Propuesta”), devuelve null.',
          '',
          '3) area_avvale (SIEMPRE escoger 1)',
          'Devuelve SOLO una de estas: RUN, GROW, SAIBORG, WISE, YUBIQ.',
          'Elige la mejor según intención/palabras clave (si dudas, elige la más probable por el tema dominante):',
          '',
          '- RUN: infraestructura, comunicaciones, operación, monitorización, upgrades, instalaciones técnicas, Basis, administración cloud/on-prem, soporte técnico, AMS funcional, operación SAP/NO SAP.',
          '- GROW: implementación funcional, procesos, consultoría funcional, T&M funcional, desarrollo ABAP, assessments funcionales.',
          '- SAIBORG: integración (Mulesoft, SAP Integration Suite, Boomi), sustitución integrador, Data (PowerBI, Tableau, Qlik, Datasphere, DWC, SAC), federación de dato, IA, OpenPlatform/Aurora, Fiori, BTP, CAP.',
          '- WISE: EPM, ESG, presupuestación, consolidación financiera, CFO, planning.',
          '- YUBIQ: productos Avvale (B+), compliance, o menciones explícitas a YUBIQ.',
          '',
          '4) deal_type (SIEMPRE escoger 1)',
          'Devuelve SOLO una de estas: "New Opportunity", "Renovación", "Upsell".',
          'Reglas:',
          '- Default: "New Opportunity" si no está claro.',
          '- Si el PDF indica explícitamente una renovación (palabras como "renovación", "renewal", "prórroga", "extensión", "continuidad"), elige "Renovación".',
          '- Si el PDF indica explícitamente upsell/ampliación (palabras como "upsell", "ampliación", "add-on", "licencias adicionales", "upgrade de alcance"), elige "Upsell".',
          '- Si hay señales mixtas, prioriza "Renovación" sobre "Upsell".',
          '',
          '5) valor',
          '- Devuelve el IMPORTE TOTAL OFERTADO como número (sin símbolo moneda, sin separadores).',
          '- Si es decimal, redondea al entero más cercano.',
          '- Prioriza "TOTAL", "Importe total", "Total oferta", "Total presupuesto".',
          '- Si solo hay rangos o no está claro, devuelve null.',
          '',
          'SALIDA:',
          '- Devuelve solo el JSON.',
        ].join('\n');

        const payload = {
          model: modelId,
          max_tokens: 400,
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'document',
                  source: {
                    type: 'base64',
                    media_type: 'application/pdf',
                    data: message.pdfBase64,
                  },
                },
                { type: 'text', text: prompt },
              ],
            },
          ],
        };

        const url = 'https://api.anthropic.com/v1/messages';
        const headers = {
          'content-type': 'application/json',
          'accept': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01',
          // Requerido por Anthropic para acceso directo desde contextos tipo navegador.
          'anthropic-dangerous-direct-browser-access': 'true',
          // Si tu tenant requiere aún el beta de PDFs, descomenta:
          // 'anthropic-beta': 'pdfs-2024-09-25',
        };

        const res = await fetch(url, { method: 'POST', headers, body: JSON.stringify(payload) });
        const contentType = res.headers.get('content-type') || '';
        const retryAfter = res.headers.get('retry-after') || '';
        const requestIdHeader =
          res.headers.get('request-id')
          || res.headers.get('x-request-id')
          || res.headers.get('cf-ray')
          || '';
        const errText = res.ok ? '' : await res.text().catch(() => '');

        if (!res.ok) {
          // Mejorar feedback para 529 (overloaded) sin “arreglar” con delays.
          if (res.status === 529) {
            sendResponse({
              ok: false,
              error: 'Anthropic está sobrecargado (529). Reintenta en unos segundos.',
              retryAfter: retryAfter || null,
              anthropic_model_pref: modelPref,
              anthropic_model_id: modelId,
              processing_time_ms: elapsedMs(),
            });
            return;
          }
          sendResponse({
            ok: false,
            error: `Anthropic error (${res.status}): ${errText || res.statusText}`,
            anthropic_model_pref: modelPref,
            anthropic_model_id: modelId,
            processing_time_ms: elapsedMs(),
          });
          return;
        }

        const json = await res.json();
        const parts = Array.isArray(json?.content) ? json.content : [];
        const text = parts
          .filter((p) => p && p.type === 'text' && typeof p.text === 'string')
          .map((p) => p.text)
          .join('\n')
          .trim();

        const obj = extractFirstJsonObject(text);
        if (!obj) {
          sendResponse({
            ok: false,
            error: 'No se pudo parsear el JSON devuelto por Anthropic.',
            anthropic_model_pref: modelPref,
            anthropic_model_id: modelId,
            processing_time_ms: elapsedMs(),
          });
          return;
        }

        const nombreCliente = obj.nombre_cliente ?? null;
        const areaAvvale = obj.area_avvale ?? null;
        const dealType = obj.deal_type ?? null;
        const nombreProyecto = obj.nombre_proyecto ?? null;
        const valor = obj.valor ?? null;

        const partsName = [];
        if (typeof nombreCliente === 'string' && nombreCliente.trim()) partsName.push(nombreCliente.trim());
        if (typeof areaAvvale === 'string' && areaAvvale.trim()) partsName.push(areaAvvale.trim());
        if (typeof nombreProyecto === 'string' && nombreProyecto.trim()) partsName.push(nombreProyecto.trim());
        const dealnameFinal = partsName.length ? partsName.join(' - ') : null;

        sendResponse({
          ok: true,
          anthropic_model_pref: modelPref,
          anthropic_model_id: modelId,
          processing_time_ms: elapsedMs(),
          fields: {
            nombre_cliente: typeof nombreCliente === 'string' ? nombreCliente.trim() : nombreCliente,
            area_avvale: typeof areaAvvale === 'string' ? areaAvvale.trim() : areaAvvale,
            deal_type: typeof dealType === 'string' ? dealType.trim() : dealType,
            nombre_proyecto: typeof nombreProyecto === 'string' ? nombreProyecto.trim() : nombreProyecto,
            dealname_final: dealnameFinal,
            valor: valor,
            fecha_cierre: closeDate,
          },
          raw: obj,
        });
      } catch (e) {
        sendResponse({ ok: false, error: e?.message || 'Error inesperado al analizar el PDF.', processing_time_ms: elapsedMs() });
      }
    });

    return true;
  }

  if (message?.type === 'YUBIQ_START_AUTOFILL' && message.payload && typeof message.payload === 'object') {
    const v = validateYubiqPayload(message.payload);
    if (!v.ok) {
      sendResponse({ ok: false, error: v.error });
      return true;
    }
    const record = { payload: message.payload, queuedAt: Date.now() };
    chrome.storage.local.set({ [STORAGE_KEY_YUBIQ_PENDING]: record }, () => {
      if (chrome.runtime.lastError) {
        sendResponse({ ok: false, error: chrome.runtime.lastError.message });
        return;
      }
      chrome.tabs.create({ url: v.url }, (tab) => {
        if (chrome.runtime.lastError) {
          sendResponse({ ok: false, error: chrome.runtime.lastError.message });
          return;
        }
        sendResponse({ ok: true, tabId: tab?.id });
      });
    });
    return true;
  }

  return true;
});
